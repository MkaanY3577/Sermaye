# SERMAYE — Kişisel Kasa, Fon ve Sermaye Yönetim Uygulaması Planı

**SERMAYE**, kullanıcının tüm nakit akışını sıfır başlangıç verisiyle üç ana kasada (**Mağaza**, **Fon**, **Kendine**) toplayan, bileşik faizle çalışan yatırım fonlarını takip eden, geleceğe dönük birikim simülasyonu sunan ve gerçek finansal verilere dayalı deterministik + Gemini AI destekli danışmanlık sağlayan %100 Türkçe, yüksek kontrastlı bir Android (Jetpack Compose) uygulamasıdır.

---

### User Review & Critical Decisions

> [!IMPORTANT] İlk aşamada onayladığınız kararlar doğrultusunda planın temel sütunları aşağıdaki şekilde kesinleştirilmiştir:

- **Platform (Yerel Android - Jetpack Compose)**: Tek HTML dosyası yerine, Android cihazda akıcı çalışan, dokunma hedefleri en az 48dp olan, sistem geri tuşu ve güvenli alan (edge-to-edge) uyumlu yerel Material 3 Compose uygulaması geliştirilecektir.
- **Veri Kalıcılığı (Tamamen Cihazda Yerel & Çevrimdışı)**: Tüm işlemler, kasalar, fon yatırımları, piyasa etiketleri ve kurulum bilgileri cihaz içinde **Room (SQLite)** ve **DataStore** üzerinde saklanacaktır. Uygulama açılışta tamamen `0,00 TL` ve boş verilerle başlar; internet olmadan da eksiksiz çalışır.
- **AI Fon Danışmanı (Hibrit: Kesin Matematik + Canlı Gemini AI)**: İlk katmanda kullanıcının gerçek verilerine bakan deterministik finans kuralları (çevrimdışı) çalışır. İkinci katmanda ise **Firebase AI Logic (`gemini-3.8-flash`)** ve **App Check** üzerinden, kullanıcının gerçek bakiye ve fon metriklerini bağlam olarak alan canlı Gemini AI yorum akışı sunulur. *(Not: İnşaya geçildiğinde Firebase AI Logic ve App Check etkinleştirme onayı istenecektir.)*
- **Tema Varsayılanı (Açık Tema + Üstten Karanlık Mod Geçişi)**: Uygulama varsayılan olarak keskin beyaz (`#FFFFFF`) kartlar, %100 siyah (`#000000`) metinler ve 1dp net siyah kenarlıklarla açılır; ana sayfa üst çubuğundaki Güneş/Ay ikonu ile yüksek kontrastlı Karanlık Mod (`#000000` zemin / `#FFFFFF` metin) anında değiştirilebilir.

---

### 1. Genel Bakış ve Temel Konsept

- **Ne Yapar?**: Gelirleri kullanıcının belirlediği oranlara göre üç kasaya otomatik dağıtır, harcamalarda kasa bakiyesinin eksiye düşmesini kesin olarak engeller, fonları bileşik faiz formülüyle gün/ay bazında güncel tutar, 12 aylık büyüme ve gelecek simülasyonu çizer ve hedefe kalan süreyi hesaplar.
- **Hedef Kitle**: Karmaşık finans terimlerinden uzak, 70 yaşındaki bir kullanıcının bile 5 saniyede anlayabileceği netlikte; tek bakışta ne kadar parası olduğunu, nereden geldiğini ve mağaza/yatırım hedefine kaç ay kaldığını görmek isteyen bireysel kullanıcılar.
- **Temel Değer**: Sıfır görsel karmaşa ("para kasası" ciddiyeti), şeffaf bileşik getiri hesabı, hatasız bakiye koruması ve gerçek rakamlara dayanan finansal rehberlik.

---

### 2. Kullanıcı Deneyimi ve Görsel Tasarım

#### Temel Kullanıcı Akışları

1. **İlk Açılış Kurulumu (Tek Sayfa, 6 Soru — Atla Butonu Yok)**
   - İlk açılışta (`isSetupDone == false`) yalnızca bir kez gösterilir:
     1. *Adın ne?* (Zorunlu)
     2. *E-postan ne?* (Opsiyonel, girilirse format kontrolü)
     3. *Şu an elinde ne kadar paran var?* (Mağaza, Fon, Kendine kasaları ayrı ayrı; negatif giriş engelli)
     4. *Her ay eline ne kadar para geçiyor?*
     5. *Paranı nasıl bölüştürelim?* (Varsayılan %50 / %40 / %10, birbirini %100'e dengeleyen 3 kaydırıcı ve aylık kazanca göre canlı TL önizleme)
     6. *(Opsiyonel) Mağaza açmak için hedefin ne kadar?* (Hedef Tutar + Takvimden Hedef Tarih)
   - Altta 56dp yeşil **"BAŞLA - SERMAYEMİ KUR"** butonu ile veriler kaydedilir ve Ana Sayfa'ya geçilir.
2. **Ana Sayfa (5 Çekirdek Bileşen + Hızlı Erişim)**
   - **Üst Çubuk**: `"Merhaba [Ad], 👋"`, Tema değiştirme (Güneş/Ay) ve Ayarlar ikonu. (Haftalık hatırlatma aktifse uygulama içi hatırlatma kartı.)
   - **Toplam Servet Kartı**: `"TOPLAM SERVETİN"`, 36sp kalın rakam (`0,00 TL`), bu aydaki net değişim.
   - **3 Kasa Kartı**: Tıklanabilir; `🏪 MAĞAZA KASASI` (Canlı Mavi), `📈 FON KASASI` (Canlı Turuncu), `💚 KENDİNE KASASI` (Canlı Yeşil).
   - **12 Aylık Büyüme Grafiği**: Veri yoksa net boş durum metni; veri varsa işlem geçmişinden hesaplanan aylık servet çizgi grafiği (3dp kalın çizgi, büyük noktalar).
   - **AI Özeti Kartı (`#FEF9C3`)**: Gerçek verilere dayanan 2 cümlelik özet + istenirse canlı Gemini AI yorumu.
   - **2 Dev Buton & Alt Bağlantılar**: 56dp yeşil `[+ PARA EKLE]` ve kırmızı `[- PARA ÇIKAR]` butonları; altında `"Transfer Yap →"` ve `"Tüm İşlemleri Gör →"` bağlantıları, en altta son 10 işlem (çöp ikonuyla onaylı silme ve kasa bakiyesi geri alma).
3. **Alttan Açılan İşlem Pencereleri (Modal Bottom Sheet)**
   - **Para Ekle**: Tutar, 4 zorunlu kaynak (`Maaş`, `Mağaza Satışı`, `Ek İş`, `Diğer`), maks 50 karakter açıklama, tarih seçici, %100 dengeli 3 bölüştürme kaydırıcısı ve sarı canlı dağılım önizleme kutusu. Başarıda 3 saniyelik yeşil üst bildirim.
   - **Para Çıkar**: Bakiyeleri gösteren 3 kasa seçimi, tutar, 4 harcama türü (`Mal Alımı`, `Kira`, `Kendine Harcama`, `Diğer`). Yetersiz bakiyede kırmızı uyarı verir, kasayı kesinlikle eksiye düşürmez.
   - **Transfer Yap**: Kaynak ve hedef kasa seçimi (aynı kasa seçilirse engeller), tutar ve bakiye kontrolü.
4. **Alt Gezinme Çubuğu (5 Sekme)**
   - `[Ana Sayfa]` · `[Fonlar]` · `[AI Danışman]` · `[Simülasyon]` · `[Piyasa/Ayarlar]`
   - *Fonlar*: Boştaki Fon Parası, Kilitli Para, Toplam Fon Kasası; 6 fon türüyle yatırım; `Değeri Güncelle` & `Fon'dan Çık`; aynı ayda çift eklemeyi engelleyen `"BU AYIN FON GETİRİSİNİ EKLE"` butonu.
   - *AI Danışman*: Gerçek verilere bağlı kural uyarıları, 3 Risk Modu (`Düşük Riskli`, `Dengeli`, `Agresif`) için pasta grafik + TL dağılım önerisi + `"BU ÖNERİYİ UYGULA"` aksiyonu, haftalık performans kartı ve canlı **Gemini AI (`gemini-3.8-flash`)** analiz kartı.
   - *Simülasyon*: 3 kaydırıcı (`Aylık Kazanç`, `Fon Getirisi %1–%10`, `Süre 6–36 Ay`), anlık bileşik faiz grafiği, mağaza hedefine kalan ay hesabı ve 100 kombinasyonu tarayan `"AI EN İYİ SENARYOYU BUL"` düğmesi.
   - *Piyasa/Ayarlar*: Üstte iki net bölüm geçişi (`Piyasa Takibi` | `Ayarlar`). Piyasa tarafında `#etiket` ekleme, günlük fiyat girişiyle mini çizgi grafik ve tarihli piyasa notları; Ayarlar tarafında tüm kurulum bilgilerini düzenleme, `mailto:` ile tam aylık rapor gönderme, haftalık hatırlatma anahtarı ve 2 aşamalı onaylı `"Verilerimi Sil"` butonu.

#### Görsel Kimlik ve Tasarım Dili

- **Estetik Yaklaşım**: "Para Kasası" ciddiyeti — bulanıklık (`blur`), cam efekti (`glassmorphism`), yarı saydamlık (`alpha`), pastel veya soluk ara griler kesinlikle kullanılmaz (tek istisna AI sayfası altındaki 12sp eğitim notu).
- **Renk Tokenları**:
  - Zemin & Kartlar (Açık / Karanlık): `#FFFFFF` / `#000000`, Ana Metin & 1dp Kenarlık: `#000000` / `#FFFFFF`
  - Mağaza: `#2563EB` · Fon: `#F97316` · Kendine / Ekle: `#16A34A` · Çıkar / Uyarı: `#DC2626` · Özet Vurgusu: `#FEF9C3`
- **Tipografi**: Yerel olarak paketlenen **Inter** ve **Poppins** (`FontWeight.SemiBold` 600 ve `FontWeight.Bold` 700; en küçük içerik yazısı 14sp, Toplam Servet 36sp).

---

### 3. Temel Ürün Kararları ve Ödünleşimler

- **Karar 1 — Özel Compose Canvas Grafikleri (Çizgi & Pasta)**:
  - *Seçilen Yaklaşım*: 12 Aylık Büyüme, Simülasyon, Piyasa Tag mini grafikleri ve AI Risk Dağılım pasta grafiği doğrudan Compose `Canvas` (`DrawScope`) ile çizilecektir.
  - *Neden*: 3dp kalın çizgi, büyük veri noktaları, %100 siyah/beyaz keskin eksen etiketleri ve kaydırıcı oynatıldığında gecikmesiz 60fps güncelleme için tam kontrol sağlar; harici webview veya ağır grafik kütüphanelerine bağımlılığı ortadan kaldırır.
- **Karar 2 — Yerel Veri Mimarisi (Room + DataStore)**:
  - *Seçilen Yaklaşım*: Finansal hareketler, fon pozisyonları, portföy geçmişi anlık görüntüleri (haftalık fark hesabı için), piyasa etiketleri ve notlar Room veritabanında; kullanıcı profili, oranlar, tema tercihi ve aylık fon getirisi son eklenme ayı DataStore'da tutulacaktır.
  - *Neden*: Uygulama kapatılıp açılsa veya internet kesilse bile veri kaybı yaşanmaz; kasa bakiyeleri işlem silindiğinde veya transfer edildiğinde atomik veritabanı işlemleriyle tutarlı kalır.
- **Karar 3 — Hibrit AI Mimarisi (Deterministik Motor + Firebase AI Logic)**:
  - *Seçilen Yaklaşım*: Prompt'taki tüm kesin matematiksel kurallar saf Kotlin finans motorunda anında ve hatasız hesaplanır. Buna ek olarak kullanıcı dilediğinde canlı **Gemini (`gemini-3.8-flash`)** butonuna basarak gerçek rakamları içeren yapılandırılmış Türkçe yorum alabilir.
  - *Neden*: Kuralların asla halüsinasyon görmemesi ve çevrimdışı çalışabilmesi korunurken, kullanıcının talep ettiği canlı Gemini AI deneyimi de App Check güvenliğiyle sağlanır.

---

### 4. Teknik Mimari ve Veri Stratejisi

#### Sistem Mimarisi Diyagramı

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        MainActivity (Edge-to-Edge)                      │
│              configureAppCheck(this, intent) -> SermayeTheme            │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
         ┌──────────────────────────┴──────────────────────────┐
         ▼ (isSetupDone == false)                              ▼ (true)
┌──────────────────────┐                          ┌───────────────────────┐
│   Kurulum Ekranı     │                          │   Ana İskelet         │
│   (6 Soru Tek Sayfa) │                          │   (5 Sekme + Modaller)│
└──────────┬───────────┘                          └───────────┬───────────┘
           │                                                  │
           └────────────────────────┬─────────────────────────┘
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        SermayeViewModel (StateFlow)                     │
│  • Bakiye & Bölüştürme Motoru     • Bileşik Faiz Fon Hesaplayıcı        │
│  • Deterministik AI Kural Motoru  • 100-Senaryo Simülasyon Optimizasyonu│
│  • Canlı Gemini AI Akışı (Firebase.ai + App Check)                      │
└──────────────┬────────────────────────────────────┬─────────────────────┘
               ▼                                    ▼
┌──────────────────────────────┐     ┌────────────────────────────────────┐
│  SermayeRepository (Offline) │     │   FirebaseAiAdvisorRepository      │
│  • Room DB (İşlemler, Fonlar,│     │   • gemini-3.8-flash (Streaming)   │
│    Değer Anlıkları, Tagler)  │     │   • 60sn Timeout + Hata Durumları  │
│  • DataStore (Profil, Tema)  │     └────────────────────────────────────┘
└──────────────────────────────┘
```

#### Veri Modeli ve Durum Yönetimi

- **Kullanıcı Profili & Ayarlar (DataStore)**: `userName`, `email`, `monthlyIncome`, `storeRatio` (50), `fundRatio` (40), `selfRatio` (10), `storeTargetAmount`, `storeTargetDateMillis`, `isSetupDone`, `isDarkMode`, `weeklyReminderEnabled`, `lastReminderShownEpochDay`, `lastMonthlyYieldAddedYm` (`YYYY-MM`).
- **Kasa Bakiyeleri & İşlem Kaydı (Room — `transactions`)**: `id`, `dateMillis`, `amount`, `sourceOrCategory`, `note`, `storeDelta`, `fundDelta`, `selfDelta`, `type` (`INPUT`, `EXPENSE`, `TRANSFER`, `FUND_BUY`, `FUND_SELL`, `FUND_YIELD`).
  - *Bakiye Tutarlılığı*: Boştaki kasa bakiyeleri ve toplam servet, tek bir doğruluk kaynağından türetilir; işlem silindiğinde `storeDelta`, `fundDelta`, `selfDelta` değerleri ters çevrilerek kasa bakiyeleri otomatik düzeltilir (negatif bakiye oluşturacak durumlar engellenir).
- **Fon Pozisyonları (Room — `funds` & `fund_snapshots`)**:
  - `FundEntity`: `id`, `fundType`, `riskLabel`, `investedAmount`, `monthlyReturnRate`, `purchaseDateMillis`, `manualOverrideValue`, `manualOverrideDateMillis`.
  - *Bileşik Faiz Hesabı*: $\text{Güncel Değer} = \text{Baz Tutar} \times (1 + r)^{\text{Geçen Tam Ay}}$, burada $\text{Geçen Tam Ay} = \max(0, \lfloor (\text{Bugün} - \text{Baz Tarih}) / 30\text{ gün} \rfloor)$. `manualOverrideValue` girilmişse bir sonraki hesaplamada baz değer ve baz tarih olarak bu değer kullanılır.
  - `FundSnapshotEntity`: Haftalık fon değişimi (`Bugünkü Toplam Fon Değeri - 7 Gün Önceki Toplam Fon Değeri`) hesabı için günlük/işlem bazlı toplam fon değeri kaydı.
- **Piyasa Takibi (Room — `market_tags`, `tag_prices`, `market_notes`)**: Etiket adı, tarihli fiyat serisi (mini grafik verisi) ve tarihli piyasa notları.

#### Etkileşimli Bileşen ve Durum Eşleşmesi

- **Kaydırıcı Dengeleme**: 3 kasa oranından biri değiştiğinde kalan iki oran toplamı `%100`'e tamamlanacak şekilde orantılı/kalan payla otomatik dengelenir; negatif veya `> 100` değer oluşmaz.
- **Kasa Silme / Çıkarma Koruması**: Para Çıkar ve Transfer işlemlerinde `amount > selectedVaultBalance` ise işlem reddedilir ve net kırmızı hata metni gösterilir.
- **AI Danışman Risk Uygulama**: `"BU ÖNERİYİ UYGULA"` basıldığında mevcut aktif fonlar varsa kullanıcıya `"Mevcut fonların var, önce onları satmak ister misin?"` onay penceresi açılır; onaylanırsa mevcut fonlar güncel değerinden boştaki fon kasasına satılır ve seçilen risk modunun yüzdelerine göre yeni fonlar oluşturulur.
- **E-posta Raporu**: `ACTION_SENDTO` (`mailto:`) Android Intent'i ile konu (`"SERMAYE - Aylık Raporum"`) ve güncel bakiye/fon/AI özeti/işlem sayısı gövdesi doldurulur; e-posta uygulaması yoksa kullanıcıya bilgilendirme gösterilir.
- **Uygulama İkonu ve Başlık**: `strings.xml` ve `metadata.json` üzerinde uygulama adı `"SERMAYE"` olarak senkronize edilir ve özel uyarlanabilir başlatıcı ikonu (`ic_launcher`) üretilir.
