package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        VaultBalancesEntity::class,
        TransactionEntity::class,
        FundEntity::class,
        FundSnapshotEntity::class,
        MarketTagEntity::class,
        TagPriceEntity::class,
        MarketNoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SermayeDatabase : RoomDatabase() {
    abstract fun vaultBalancesDao(): VaultBalancesDao
    abstract fun transactionDao(): TransactionDao
    abstract fun fundDao(): FundDao
    abstract fun marketDao(): MarketDao

    companion object {
        @Volatile
        private var INSTANCE: SermayeDatabase? = null

        fun getInstance(context: Context): SermayeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SermayeDatabase::class.java,
                    "sermaye_vault.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
