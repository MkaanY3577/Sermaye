package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.sermayeDataStore by preferencesDataStore(name = "sermaye_prefs")

data class AssetPriceAlertRule(
    val assetId: String,
    val assetName: String,
    val symbol: String,
    val currency: String = "TL",
    val thresholdPercent: Double,
    val baselinePrice: Double,
    val enabled: Boolean = true
)

data class UserProfile(
    val isSetupDone: Boolean = false,
    val userName: String = "",
    val email: String = "",
    val monthlyIncome: Double = 0.0,
    val storeRatio: Int = 50,
    val fundRatio: Int = 40,
    val selfRatio: Int = 10,
    val storeTargetAmount: Double = 0.0,
    val storeTargetDateMillis: Long? = null,
    val isDarkMode: Boolean = false,
    val weeklyReminderEnabled: Boolean = true,
    val lastReminderDismissedEpochDay: Long = 0L,
    val lastMonthlyYieldAddedYm: String = "",
    val marketAlertsEnabled: Boolean = false,
    val alertThresholdPercent: Double = 1.0,
    val lastAlertGoldPrice: Double = 0.0,
    val lastAlertBtcPrice: Double = 0.0,
    val lastAlertTopFundPrice: Double = 0.0,
    val favoriteAssetIds: Set<String> = emptySet(),
    val assetAlerts: Map<String, AssetPriceAlertRule> = emptyMap()
)

class UserPreferencesDataStore(private val context: Context) {

    private object Keys {
        val IS_SETUP_DONE = booleanPreferencesKey("is_setup_done")
        val USER_NAME = stringPreferencesKey("user_name")
        val EMAIL = stringPreferencesKey("email")
        val MONTHLY_INCOME = doublePreferencesKey("monthly_income")
        val STORE_RATIO = intPreferencesKey("store_ratio")
        val FUND_RATIO = intPreferencesKey("fund_ratio")
        val SELF_RATIO = intPreferencesKey("self_ratio")
        val STORE_TARGET_AMOUNT = doublePreferencesKey("store_target_amount")
        val STORE_TARGET_DATE_MILLIS = longPreferencesKey("store_target_date_millis")
        val HAS_STORE_TARGET_DATE = booleanPreferencesKey("has_store_target_date")
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val WEEKLY_REMINDER_ENABLED = booleanPreferencesKey("weekly_reminder_enabled")
        val LAST_REMINDER_DISMISSED_EPOCH_DAY = longPreferencesKey("last_reminder_dismissed_epoch_day")
        val LAST_MONTHLY_YIELD_YM = stringPreferencesKey("last_monthly_yield_ym")
        val MARKET_ALERTS_ENABLED = booleanPreferencesKey("market_alerts_enabled")
        val ALERT_THRESHOLD_PERCENT = doublePreferencesKey("alert_threshold_percent")
        val LAST_ALERT_GOLD_PRICE = doublePreferencesKey("last_alert_gold_price")
        val LAST_ALERT_BTC_PRICE = doublePreferencesKey("last_alert_btc_price")
        val LAST_ALERT_TOP_FUND_PRICE = doublePreferencesKey("last_alert_top_fund_price")
        val FAVORITE_ASSET_IDS = stringSetPreferencesKey("favorite_asset_ids")
        val ASSET_ALERTS_JSON = stringPreferencesKey("asset_alerts_json")
    }

    val userProfileFlow: Flow<UserProfile> = context.sermayeDataStore.data.map { prefs ->
        val hasTargetDate = prefs[Keys.HAS_STORE_TARGET_DATE] ?: false
        UserProfile(
            isSetupDone = prefs[Keys.IS_SETUP_DONE] ?: false,
            userName = prefs[Keys.USER_NAME] ?: "",
            email = prefs[Keys.EMAIL] ?: "",
            monthlyIncome = prefs[Keys.MONTHLY_INCOME] ?: 0.0,
            storeRatio = prefs[Keys.STORE_RATIO] ?: 50,
            fundRatio = prefs[Keys.FUND_RATIO] ?: 40,
            selfRatio = prefs[Keys.SELF_RATIO] ?: 10,
            storeTargetAmount = prefs[Keys.STORE_TARGET_AMOUNT] ?: 0.0,
            storeTargetDateMillis = if (hasTargetDate) prefs[Keys.STORE_TARGET_DATE_MILLIS] else null,
            isDarkMode = prefs[Keys.IS_DARK_MODE] ?: false,
            weeklyReminderEnabled = prefs[Keys.WEEKLY_REMINDER_ENABLED] ?: true,
            lastReminderDismissedEpochDay = prefs[Keys.LAST_REMINDER_DISMISSED_EPOCH_DAY] ?: 0L,
            lastMonthlyYieldAddedYm = prefs[Keys.LAST_MONTHLY_YIELD_YM] ?: "",
            marketAlertsEnabled = prefs[Keys.MARKET_ALERTS_ENABLED] ?: false,
            alertThresholdPercent = prefs[Keys.ALERT_THRESHOLD_PERCENT] ?: 1.0,
            lastAlertGoldPrice = prefs[Keys.LAST_ALERT_GOLD_PRICE] ?: 0.0,
            lastAlertBtcPrice = prefs[Keys.LAST_ALERT_BTC_PRICE] ?: 0.0,
            lastAlertTopFundPrice = prefs[Keys.LAST_ALERT_TOP_FUND_PRICE] ?: 0.0,
            favoriteAssetIds = prefs[Keys.FAVORITE_ASSET_IDS] ?: emptySet(),
            assetAlerts = decodeAssetAlerts(prefs[Keys.ASSET_ALERTS_JSON])
        )
    }

    suspend fun saveSetupProfile(
        userName: String,
        email: String,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.IS_SETUP_DONE] = true
            prefs[Keys.USER_NAME] = userName.trim()
            prefs[Keys.EMAIL] = email.trim()
            prefs[Keys.MONTHLY_INCOME] = monthlyIncome
            prefs[Keys.STORE_RATIO] = storeRatio
            prefs[Keys.FUND_RATIO] = fundRatio
            prefs[Keys.SELF_RATIO] = selfRatio
            prefs[Keys.STORE_TARGET_AMOUNT] = storeTargetAmount
            if (storeTargetDateMillis != null) {
                prefs[Keys.HAS_STORE_TARGET_DATE] = true
                prefs[Keys.STORE_TARGET_DATE_MILLIS] = storeTargetDateMillis
            } else {
                prefs[Keys.HAS_STORE_TARGET_DATE] = false
                prefs.remove(Keys.STORE_TARGET_DATE_MILLIS)
            }
        }
    }

    suspend fun setDarkMode(isDark: Boolean) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.IS_DARK_MODE] = isDark
        }
    }

    suspend fun setWeeklyReminderEnabled(enabled: Boolean) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.WEEKLY_REMINDER_ENABLED] = enabled
        }
    }

    suspend fun dismissWeeklyReminder(epochDay: Long) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.LAST_REMINDER_DISMISSED_EPOCH_DAY] = epochDay
        }
    }

    suspend fun setLastMonthlyYieldYm(ym: String) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.LAST_MONTHLY_YIELD_YM] = ym
        }
    }

    suspend fun setMarketAlertsEnabled(enabled: Boolean) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.MARKET_ALERTS_ENABLED] = enabled
        }
    }

    suspend fun setAlertThresholdPercent(threshold: Double) {
        context.sermayeDataStore.edit { prefs ->
            prefs[Keys.ALERT_THRESHOLD_PERCENT] = threshold
        }
    }

    suspend fun saveLastAlertPrices(goldPrice: Double, btcPrice: Double, topFundPrice: Double) {
        context.sermayeDataStore.edit { prefs ->
            if (goldPrice > 0.0) prefs[Keys.LAST_ALERT_GOLD_PRICE] = goldPrice
            if (btcPrice > 0.0) prefs[Keys.LAST_ALERT_BTC_PRICE] = btcPrice
            if (topFundPrice > 0.0) prefs[Keys.LAST_ALERT_TOP_FUND_PRICE] = topFundPrice
        }
    }

    suspend fun toggleFavoriteAsset(assetId: String): Boolean {
        var added = false
        context.sermayeDataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITE_ASSET_IDS]?.toMutableSet() ?: mutableSetOf()
            added = if (assetId in current) {
                current.remove(assetId)
                false
            } else {
                current.add(assetId)
                true
            }
            prefs[Keys.FAVORITE_ASSET_IDS] = current
        }
        return added
    }

    suspend fun saveAssetAlert(rule: AssetPriceAlertRule) {
        context.sermayeDataStore.edit { prefs ->
            val current = decodeAssetAlerts(prefs[Keys.ASSET_ALERTS_JSON]).toMutableMap()
            current[rule.assetId] = rule
            prefs[Keys.ASSET_ALERTS_JSON] = encodeAssetAlerts(current)
        }
    }

    suspend fun removeAssetAlert(assetId: String) {
        context.sermayeDataStore.edit { prefs ->
            val current = decodeAssetAlerts(prefs[Keys.ASSET_ALERTS_JSON]).toMutableMap()
            current.remove(assetId)
            prefs[Keys.ASSET_ALERTS_JSON] = encodeAssetAlerts(current)
        }
    }

    suspend fun updateAssetAlertBaselines(updatedPrices: Map<String, Double>) {
        if (updatedPrices.isEmpty()) return
        context.sermayeDataStore.edit { prefs ->
            val current = decodeAssetAlerts(prefs[Keys.ASSET_ALERTS_JSON]).toMutableMap()
            var changed = false
            updatedPrices.forEach { (id, newPrice) ->
                val existing = current[id]
                if (existing != null && newPrice > 0.0) {
                    current[id] = existing.copy(baselinePrice = newPrice)
                    changed = true
                }
            }
            if (changed) {
                prefs[Keys.ASSET_ALERTS_JSON] = encodeAssetAlerts(current)
            }
        }
    }

    suspend fun clearAll() {
        context.sermayeDataStore.edit { it.clear() }
    }

    private fun decodeAssetAlerts(raw: String?): Map<String, AssetPriceAlertRule> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val arr = JSONArray(raw)
            val map = linkedMapOf<String, AssetPriceAlertRule>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("assetId").takeIf { it.isNotBlank() } ?: continue
                val rule = AssetPriceAlertRule(
                    assetId = id,
                    assetName = obj.optString("assetName", id),
                    symbol = obj.optString("symbol", id),
                    currency = obj.optString("currency", "TL"),
                    thresholdPercent = obj.optDouble("thresholdPercent", 1.0),
                    baselinePrice = obj.optDouble("baselinePrice", 0.0),
                    enabled = obj.optBoolean("enabled", true)
                )
                map[id] = rule
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun encodeAssetAlerts(map: Map<String, AssetPriceAlertRule>): String {
        val arr = JSONArray()
        map.values.forEach { rule ->
            arr.put(
                JSONObject().apply {
                    put("assetId", rule.assetId)
                    put("assetName", rule.assetName)
                    put("symbol", rule.symbol)
                    put("currency", rule.currency)
                    put("thresholdPercent", rule.thresholdPercent)
                    put("baselinePrice", rule.baselinePrice)
                    put("enabled", rule.enabled)
                }
            )
        }
        return arr.toString()
    }
}
