package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultBalancesDao {
    @Query("SELECT * FROM vault_balances WHERE id = 1")
    fun observeBalances(): Flow<VaultBalancesEntity?>

    @Query("SELECT * FROM vault_balances WHERE id = 1")
    suspend fun getBalancesOnce(): VaultBalancesEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBalances(balances: VaultBalancesEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC, createdAtMillis DESC, id DESC")
    fun observeAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY dateMillis ASC, createdAtMillis ASC")
    suspend fun getAllTransactionsOnce(): List<TransactionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: TransactionEntity): Long

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface FundDao {
    @Query("SELECT * FROM funds ORDER BY purchaseDateMillis DESC, id DESC")
    fun observeAllFunds(): Flow<List<FundEntity>>

    @Query("SELECT * FROM funds")
    suspend fun getAllFundsOnce(): List<FundEntity>

    @Query("SELECT * FROM funds WHERE id = :id")
    suspend fun getFundById(id: Long): FundEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFund(fund: FundEntity): Long

    @Update
    suspend fun updateFund(fund: FundEntity)

    @Query("DELETE FROM funds WHERE id = :id")
    suspend fun deleteFundById(id: Long)

    @Query("DELETE FROM funds")
    suspend fun deleteAllFunds()

    @Query("SELECT * FROM fund_snapshots ORDER BY epochDay ASC")
    fun observeSnapshots(): Flow<List<FundSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSnapshot(snapshot: FundSnapshotEntity)
}

@Dao
interface MarketDao {
    @Query("SELECT * FROM market_tags ORDER BY createdAtMillis DESC")
    fun observeTags(): Flow<List<MarketTagEntity>>

    @Query("SELECT * FROM tag_prices ORDER BY dateMillis ASC, id ASC")
    fun observeAllTagPrices(): Flow<List<TagPriceEntity>>

    @Query("SELECT * FROM market_notes ORDER BY dateMillis DESC, id DESC")
    fun observeNotes(): Flow<List<MarketNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTag(tag: MarketTagEntity): Long

    @Query("DELETE FROM market_tags WHERE id = :id")
    suspend fun deleteTagById(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTagPrice(price: TagPriceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: MarketNoteEntity): Long

    @Query("DELETE FROM market_notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)
}
