package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class VaultType(val label: String) {
    STORE("Mağaza Kasası"),
    FUND("Fon Kasası"),
    SELF("Kendine Kasası")
}

enum class TransactionType(val label: String) {
    INPUT("Girdi"),
    EXPENSE("Çıktı"),
    TRANSFER("Transfer"),
    FUND_BUY("Fon Alımı"),
    FUND_SELL("Fon Satışı"),
    FUND_YIELD("Fon Getirisi")
}

@Entity(tableName = "vault_balances")
data class VaultBalancesEntity(
    @PrimaryKey val id: Int = 1,
    val storeBalance: Double = 0.0,
    val idleFundCash: Double = 0.0,
    val selfBalance: Double = 0.0
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long,
    val amount: Double,
    val sourceOrCategory: String,
    val note: String,
    val storeDelta: Double,
    val fundDelta: Double,
    val selfDelta: Double,
    val type: String,
    val linkedFundId: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "funds")
data class FundEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fundType: String,
    val riskLabel: String,
    val investedAmount: Double,
    val monthlyReturnPercent: Double,
    val purchaseDateMillis: Long,
    val manualOverrideValue: Double? = null,
    val manualOverrideDateMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "fund_snapshots")
data class FundSnapshotEntity(
    @PrimaryKey val epochDay: Long,
    val totalFundValue: Double
)

@Entity(tableName = "market_tags")
data class MarketTagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tagName: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tag_prices",
    foreignKeys = [
        ForeignKey(
            entity = MarketTagEntity::class,
            parentColumns = ["id"],
            childColumns = ["tagId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tagId")]
)
data class TagPriceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tagId: Long,
    val dateMillis: Long,
    val price: Double
)

@Entity(tableName = "market_notes")
data class MarketNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateMillis: Long,
    val content: String
)
