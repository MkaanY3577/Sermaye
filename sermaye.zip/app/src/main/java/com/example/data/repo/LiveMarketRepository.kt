package com.example.data.repo

import android.util.Log
import android.util.Xml
import com.example.domain.PricePoint
import com.example.util.CurrencyUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.OutputStreamWriter
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val MARKET_TAG = "LiveMarketRepo"

object MarketCategory {
    const val FUND = "Fon"
    const val METAL = "Maden & Emtia"
    const val CRYPTO = "Kripto"
    const val FX = "Döviz"
}

enum class ImpactDirection(val label: String) {
    POSITIVE("Yükseliş Destekli ▲"),
    NEGATIVE("Düşüş Baskısı ▼"),
    MIXED("Karışık / İzle ●")
}

data class FundImpactAssessment(
    val affectedFunds: List<String>,
    val direction: ImpactDirection,
    val rationale: String
)

data class FundMarketSignal(
    val fundName: String,
    val positiveCount: Int,
    val negativeCount: Int,
    val mixedCount: Int
) {
    val netScore: Int get() = positiveCount - negativeCount
}

data class LiveAssetQuote(
    val id: String,
    val name: String,
    val symbol: String,
    val price: Double,
    val currency: String,
    val changePercent24h: Double?,
    val category: String,
    val sourceName: String,
    val sparklinePrices: List<Double> = emptyList(),
    val historyKey: String = ""
)

data class LiveMarketSnapshot(
    val fetchedAtMillis: Long,
    val assets: List<LiveAssetQuote>,
    val topFunds: List<LiveAssetQuote>
)

data class MarketNewsItem(
    val title: String,
    val summary: String,
    val source: String,
    val publishedAt: String,
    val publishedAtMillis: Long,
    val link: String,
    val fundImpact: FundImpactAssessment,
    val imageUrl: String? = null
)

sealed interface LiveMarketUiState {
    data object Idle : LiveMarketUiState
    data object Loading : LiveMarketUiState
    data class Ready(val snapshot: LiveMarketSnapshot) : LiveMarketUiState
    data class Error(val message: String) : LiveMarketUiState
}

sealed interface MarketNewsUiState {
    data object Idle : MarketNewsUiState
    data object Loading : MarketNewsUiState
    data class Ready(val items: List<MarketNewsItem>) : MarketNewsUiState
    data class Error(val message: String) : MarketNewsUiState
}

class LiveMarketRepository {

    private data class YahooTickerSpec(
        val symbol: String,
        val name: String,
        val description: String,
        val category: String,
        val fixedId: String? = null
    )

    // Kapsamlı Borsa Yatırım Fonları (BIST BYF + Küresel Dev ETF + Endeksler)
    private val marketFundsSpecs = listOf(
        // Türkiye BIST Endeksleri ve Borsa Yatırım Fonları (BYF)
        YahooTickerSpec("XU100.IS", "BIST 100 Endeksi", "Borsa İstanbul Ana Endeks", MarketCategory.FUND),
        YahooTickerSpec("XU030.IS", "BIST 30 Endeksi", "Büyük Ölçekli Şirketler", MarketCategory.FUND),
        YahooTickerSpec("XBANK.IS", "BIST Bankacılık Endeksi", "Bankacılık Sektörü", MarketCategory.FUND),
        YahooTickerSpec("XUSIN.IS", "BIST Sınai Endeksi", "Sanayi Şirketleri", MarketCategory.FUND),
        YahooTickerSpec("ZGOLD.IS", "Ziraat Portföy Altın BYF", "BIST Altın Borsa Fonu", MarketCategory.FUND),
        YahooTickerSpec("GLDTR.IS", "QNB Finans Altın BYF", "BIST Fiziki Altın Fonu", MarketCategory.FUND),
        YahooTickerSpec("GMSTR.IS", "QNB Finans Gümüş BYF", "BIST Gümüş Borsa Fonu", MarketCategory.FUND),
        YahooTickerSpec("USDTR.IS", "QNB Finans Dolar BYF", "BIST Döviz Likit Fonu", MarketCategory.FUND),
        YahooTickerSpec("DJIST.IS", "Dow Jones İstanbul 20 BYF", "BIST 20 Hisse Fonu", MarketCategory.FUND),
        YahooTickerSpec("ZPX30.IS", "Ziraat BIST 30 Katılım BYF", "BIST 30 Hisse Fonu", MarketCategory.FUND),
        YahooTickerSpec("ZRE20.IS", "Ziraat Katılım 20 BYF", "Katılım Endeksi Fonu", MarketCategory.FUND),
        YahooTickerSpec("ZTM25.IS", "Ziraat Temettü 25 BYF", "Temettü Hisseleri Fonu", MarketCategory.FUND),
        YahooTickerSpec("ZPT10.IS", "Ziraat Teknoloji & Piyasa BYF", "Teknoloji Hisse Fonu", MarketCategory.FUND),
        YahooTickerSpec("ZPBDL.IS", "Ziraat Kira Sertifikası BYF", "Katılım Sukuk Fonu", MarketCategory.FUND),
        YahooTickerSpec("TUR", "iShares MSCI Turkey ETF", "Küresel Türkiye Borsa Fonu", MarketCategory.FUND),

        // Dünyanın En Büyük Hisse, Teknoloji, Tahvil, Para Piyasası & Kripto ETF'leri
        YahooTickerSpec("SPY", "SPDR S&P 500 ETF", "ABD Büyük 500 Şirket Fonu", MarketCategory.FUND),
        YahooTickerSpec("VOO", "Vanguard S&P 500 ETF", "Düşük Maliyetli S&P 500", MarketCategory.FUND),
        YahooTickerSpec("IVV", "iShares Core S&P 500 ETF", "BlackRock S&P 500 Fonu", MarketCategory.FUND),
        YahooTickerSpec("QQQ", "Invesco QQQ Trust", "Nasdaq 100 Teknoloji Fonu", MarketCategory.FUND),
        YahooTickerSpec("QQQM", "Invesco NASDAQ 100 ETF", "Uzun Vade Teknoloji Fonu", MarketCategory.FUND),
        YahooTickerSpec("VTI", "Vanguard Total Stock ETF", "Tüm ABD Borsası Fonu", MarketCategory.FUND),
        YahooTickerSpec("VT", "Vanguard Total World ETF", "Tüm Dünya Borsaları Fonu", MarketCategory.FUND),
        YahooTickerSpec("VXUS", "Vanguard Total Int'l ETF", "ABD Dışı Küresel Fon", MarketCategory.FUND),
        YahooTickerSpec("EEM", "iShares Emerging Markets", "Gelişen Ülkeler Fonu", MarketCategory.FUND),
        YahooTickerSpec("DIA", "SPDR Dow Jones ETF", "Dow Jones 30 Sanayi Fonu", MarketCategory.FUND),
        YahooTickerSpec("IWM", "iShares Russell 2000 ETF", "Küçük Ölçekli Şirket Fonu", MarketCategory.FUND),
        YahooTickerSpec("SCHD", "Schwab US Dividend ETF", "Yüksek Temettü Fonu", MarketCategory.FUND),
        YahooTickerSpec("JEPI", "JPMorgan Equity Income ETF", "Aylık Temettü Gelir Fonu", MarketCategory.FUND),
        YahooTickerSpec("SOXX", "iShares Semiconductor ETF", "Yarı İletken & Çip Fonu", MarketCategory.FUND),
        YahooTickerSpec("SMH", "VanEck Semiconductor ETF", "Küresel Çip & AI Fonu", MarketCategory.FUND),
        YahooTickerSpec("XLK", "Technology Select Sector", "Teknoloji Sektör Fonu", MarketCategory.FUND),
        YahooTickerSpec("XLF", "Financial Select Sector", "Finans & Banka Fonu", MarketCategory.FUND),
        YahooTickerSpec("XLE", "Energy Select Sector", "Enerji Sektör Fonu", MarketCategory.FUND),
        YahooTickerSpec("XLV", "Health Care Select Sector", "Sağlık Sektör Fonu", MarketCategory.FUND),
        YahooTickerSpec("ARKK", "ARK Innovation ETF", "Yüksek Riskli İnovasyon Fonu", MarketCategory.FUND),
        YahooTickerSpec("VNQ", "Vanguard Real Estate ETF", "Küresel GYO Emlak Fonu", MarketCategory.FUND),
        YahooTickerSpec("IBIT", "iShares Bitcoin Trust ETF", "BlackRock Spot Bitcoin Fonu", MarketCategory.FUND),
        YahooTickerSpec("FBTC", "Fidelity Bitcoin Fund ETF", "Fidelity Spot Bitcoin Fonu", MarketCategory.FUND),
        YahooTickerSpec("ETHA", "iShares Ethereum Trust ETF", "BlackRock Ethereum Fonu", MarketCategory.FUND),
        YahooTickerSpec("EMB", "iShares USD EM Bond ETF", "Gelişen Ülke Eurobond Fonu", MarketCategory.FUND),
        YahooTickerSpec("TLT", "iShares 20+ Yr Treasury ETF", "ABD Uzun Vadeli Tahvil Fonu", MarketCategory.FUND),
        YahooTickerSpec("HYG", "iShares High Yield Bond ETF", "Yüksek Getirili Tahvil Fonu", MarketCategory.FUND),
        YahooTickerSpec("SGOV", "iShares 0-3 Month Treasury", "ABD Para Piyasası Likit Fon", MarketCategory.FUND),
        YahooTickerSpec("BIL", "SPDR 1-3 Month T-Bill ETF", "Kısa Vadeli Hazine Bonosu", MarketCategory.FUND)
    )

    // Küresel Madenler, Değerli Metaller, Endüstriyel Madenler & Maden ETF'leri
    private val metalsAndCommoditiesSpecs = listOf(
        YahooTickerSpec("GC=F", "Ons Altın (Vadeli)", "Küresel Altın Ons Fiyatı", MarketCategory.METAL),
        YahooTickerSpec("SI=F", "Ons Gümüş (Vadeli)", "Küresel Gümüş Ons Fiyatı", MarketCategory.METAL),
        YahooTickerSpec("PL=F", "Ons Platin (Vadeli)", "Değerli Metal Platin", MarketCategory.METAL),
        YahooTickerSpec("PA=F", "Ons Paladyum (Vadeli)", "Değerli Metal Paladyum", MarketCategory.METAL),
        YahooTickerSpec("HG=F", "Bakır (Vadeli)", "Sanayi & Elektrik Madeni Bakır", MarketCategory.METAL),
        YahooTickerSpec("ALI=F", "Alüminyum (Vadeli)", "Sanayi Madeni Alüminyum", MarketCategory.METAL),
        YahooTickerSpec("CL=F", "Ham Petrol (WTI)", "Küresel Petrol Varil", MarketCategory.METAL),
        YahooTickerSpec("BZ=F", "Brent Petrol", "Avrupa / Türkiye Petrol Bazı", MarketCategory.METAL),
        YahooTickerSpec("NG=F", "Doğalgaz (Vadeli)", "Enerji Emtiası Doğalgaz", MarketCategory.METAL),
        YahooTickerSpec("GLD", "SPDR Gold Shares", "Dünyanın En Büyük Altın Fonu", MarketCategory.METAL),
        YahooTickerSpec("IAU", "iShares Gold Trust", "Fiziki Altın ETF'i", MarketCategory.METAL),
        YahooTickerSpec("SLV", "iShares Silver Trust", "Dünyanın En Büyük Gümüş Fonu", MarketCategory.METAL),
        YahooTickerSpec("PPLT", "abrdn Physical Platinum", "Fiziki Platin ETF'i", MarketCategory.METAL),
        YahooTickerSpec("PALL", "abrdn Physical Palladium", "Fiziki Paladyum ETF'i", MarketCategory.METAL),
        YahooTickerSpec("GDX", "VanEck Gold Miners ETF", "Altın Madencileri Fonu", MarketCategory.METAL),
        YahooTickerSpec("SIL", "Global X Silver Miners ETF", "Gümüş Madencileri Fonu", MarketCategory.METAL),
        YahooTickerSpec("COPX", "Global X Copper Miners ETF", "Bakır Madencileri Fonu", MarketCategory.METAL),
        YahooTickerSpec("LIT", "Global X Lithium & Battery", "Lityum & Batarya Madeni Fonu", MarketCategory.METAL),
        YahooTickerSpec("URA", "Global X Uranium ETF", "Uranyum & Nükleer Maden Fonu", MarketCategory.METAL),
        YahooTickerSpec("REMX", "VanEck Rare Earth Metals", "Nadir Toprak Elementleri Fonu", MarketCategory.METAL),
        YahooTickerSpec("SLX", "VanEck Steel ETF", "Demir & Çelik Maden Fonu", MarketCategory.METAL)
    )

    private val extraCurrencies = listOf(
        "GBP" to "İngiliz Sterlini",
        "CHF" to "İsviçre Frangı",
        "JPY" to "Japon Yeni",
        "CAD" to "Kanada Doları",
        "AUD" to "Avustralya Doları",
        "SAR" to "Suudi Riyali",
        "AED" to "BAE Dirhemi",
        "NOK" to "Norveç Kronu",
        "SEK" to "İsveç Kronu",
        "CNY" to "Çin Yuanı"
    )

    suspend fun fetchLiveMarket(): Result<LiveMarketSnapshot> = withContext(Dispatchers.IO) {
        try {
            coroutineScope {
                val truncgilDeferred = async { fetchTruncgilQuotes() }
                val cryptoDeferred = async { fetchAllCryptosTry() }
                val fxRatesDeferred = async { fetchOpenErRates() }
                val yahooFundsDeferred = async { fetchYahooQuotesBatched(marketFundsSpecs, batchSize = 8) }
                val yahooMetalsDeferred = async { fetchYahooQuotesBatched(metalsAndCommoditiesSpecs, batchSize = 8) }
                val tefasDeferred = async { fetchTefasMarketFunds() }
                val goldSparkDeferred = async { fetchBinanceKlinesPrices("PAXGTRY", limit = 30) }
                val fxSparkDeferred = async { fetchFxSparklineMap() }

                val truncgil = truncgilDeferred.await()
                val cryptos = cryptoDeferred.await()
                val fxRates = fxRatesDeferred.await()
                val yahooFunds = yahooFundsDeferred.await()
                val yahooMetals = yahooMetalsDeferred.await()
                val tefasFunds = tefasDeferred.await()
                val fxSparkMap = fxSparkDeferred.await()
                val goldSpark = goldSparkDeferred.await()
                    .takeIf { it.size >= 2 }
                    ?: yahooFunds.firstOrNull { it.symbol == "ZGOLD.IS" }?.sparklinePrices?.takeIf { it.size >= 2 }
                    ?: yahooMetals.firstOrNull { it.symbol == "GC=F" }?.sparklinePrices.orEmpty()

                val usdTryPrice = truncgil["usd"]?.price ?: fxRates["usd"]?.price ?: 0.0

                val combinedAssets = mutableListOf<LiveAssetQuote>()

                // 1. Türkiye Fiziki Altın ve Gümüş (Truncgil tüm altın türleri + PAXG fallback)
                val goldKeysOrder = listOf(
                    "gram_altin", "ceyrek_altin", "yarim_altin", "tam_altin",
                    "cumhuriyet_altini", "ata_altin", "resat_altin", "gremse_altin",
                    "bilezik_22", "altin_18", "altin_14", "has_altin", "ons_altin"
                )
                val paxgTry = cryptos.firstOrNull { it.symbol.startsWith("PAXG") }
                var addedGramGold = false
                goldKeysOrder.forEach { k ->
                    val q = truncgil[k]
                    if (q != null) {
                        if (k == "gram_altin") addedGramGold = true
                        combinedAssets.add(q.copy(sparklinePrices = goldSpark))
                    }
                }
                if (!addedGramGold && paxgTry != null) {
                    combinedAssets.add(
                        0,
                        LiveAssetQuote(
                            id = "gram_altin",
                            name = "Gram Altın (Ons Bazlı)",
                            symbol = "GAU/TRY",
                            price = paxgTry.price / 31.1034768,
                            currency = "TL",
                            changePercent24h = paxgTry.changePercent24h,
                            category = MarketCategory.METAL,
                            sourceName = paxgTry.sourceName,
                            sparklinePrices = goldSpark,
                            historyKey = "PAXGTRY"
                        )
                    )
                }

                val silverSpark = yahooFunds.firstOrNull { it.symbol == "GMSTR.IS" }?.sparklinePrices?.takeIf { it.size >= 2 }
                    ?: yahooMetals.firstOrNull { it.symbol == "SI=F" }?.sparklinePrices.orEmpty()
                truncgil["gumus"]?.let { g ->
                    combinedAssets.add(g.copy(sparklinePrices = silverSpark))
                } ?: run {
                    val siQuote = yahooMetals.firstOrNull { it.symbol == "SI=F" }
                    if (siQuote != null && usdTryPrice > 0.0) {
                        combinedAssets.add(
                            LiveAssetQuote(
                                id = "gumus",
                                name = "Gram Gümüş (Ons Bazlı)",
                                symbol = "XAG/TRY",
                                price = (siQuote.price * usdTryPrice) / 31.1034768,
                                currency = "TL",
                                changePercent24h = siQuote.changePercent24h,
                                category = MarketCategory.METAL,
                                sourceName = "Ons/TRY",
                                sparklinePrices = siQuote.sparklinePrices,
                                historyKey = "SI=F"
                            )
                        )
                    }
                }

                // Platin & Paladyum TRY (Gram TL hesaplaması canlı ons * canlı USD/TRY ile)
                if (usdTryPrice > 0.0) {
                    yahooMetals.firstOrNull { it.symbol == "PL=F" }?.let { pl ->
                        combinedAssets.add(
                            LiveAssetQuote(
                                id = "metal_try_platin",
                                name = "Gram Platin",
                                symbol = "XPT/TRY",
                                price = (pl.price * usdTryPrice) / 31.1034768,
                                currency = "TL",
                                changePercent24h = pl.changePercent24h,
                                category = MarketCategory.METAL,
                                sourceName = "Ons/TRY",
                                sparklinePrices = pl.sparklinePrices,
                                historyKey = "PL=F"
                            )
                        )
                    }
                    yahooMetals.firstOrNull { it.symbol == "PA=F" }?.let { pa ->
                        combinedAssets.add(
                            LiveAssetQuote(
                                id = "metal_try_paladyum",
                                name = "Gram Paladyum",
                                symbol = "XPD/TRY",
                                price = (pa.price * usdTryPrice) / 31.1034768,
                                currency = "TL",
                                changePercent24h = pa.changePercent24h,
                                category = MarketCategory.METAL,
                                sourceName = "Ons/TRY",
                                sparklinePrices = pa.sparklinePrices,
                                historyKey = "PA=F"
                            )
                        )
                    }
                }

                // Küresel maden vadelileri ve madencilik fonları
                combinedAssets.addAll(yahooMetals)

                // 2. Dövizler (USD, EUR + diğer büyük para birimleri — canlı 30g grafikli)
                val fxIdsSeen = mutableSetOf<String>()
                truncgil.values.filter { it.category == MarketCategory.FX }.forEach { q ->
                    if (fxIdsSeen.add(q.id)) {
                        val sp = fxSparkMap[q.id].orEmpty()
                        combinedAssets.add(q.copy(sparklinePrices = sp))
                    }
                }
                fxRates.values.forEach { q ->
                    if (fxIdsSeen.add(q.id)) {
                        val sp = fxSparkMap[q.id].orEmpty()
                        val derivedChg = q.changePercent24h ?: if (sp.size >= 2 && sp[sp.lastIndex - 1] > 0.0) {
                            ((sp.last() - sp[sp.lastIndex - 1]) / sp[sp.lastIndex - 1]) * 100.0
                        } else null
                        combinedAssets.add(q.copy(sparklinePrices = sp, changePercent24h = derivedChg))
                    }
                }

                // 3. Tüm Kriptolar (CoinGecko Top 100 TRY + Binance TRY pariteleri)
                combinedAssets.addAll(cryptos)

                // 4. Tüm Fonlar (TEFAS Yatırım Fonları + BIST BYF + Küresel Büyük ETF'ler)
                val allFunds = mutableListOf<LiveAssetQuote>()
                allFunds.addAll(tefasFunds)
                allFunds.addAll(yahooFunds)

                if (combinedAssets.isEmpty() && allFunds.isEmpty()) {
                    Result.failure(IllegalStateException("Canlı piyasa verisi alınamadı. İnternet bağlantını kontrol et."))
                } else {
                    Result.success(
                        LiveMarketSnapshot(
                            fetchedAtMillis = System.currentTimeMillis(),
                            assets = combinedAssets,
                            topFunds = allFunds
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(MARKET_TAG, "Failed to fetch live market snapshot", e)
            Result.failure(e)
        }
    }

    suspend fun searchRemoteMarketAssets(rawQuery: String): Result<List<LiveAssetQuote>> = withContext(Dispatchers.IO) {
        val q = rawQuery.trim()
        if (q.length < 2) return@withContext Result.success(emptyList())
        try {
            coroutineScope {
                val cgDeferred = async { searchCoinGeckoCoins(q) }
                val yahooDeferred = async { searchYahooSymbols(q) }
                val tefasDeferred = async {
                    val code = q.uppercase(Locale.US)
                    if (code.matches(Regex("^[A-Z0-9]{3}$"))) {
                        fetchSingleTefasFund(code)
                    } else null
                }

                val merged = mutableListOf<LiveAssetQuote>()
                tefasDeferred.await()?.let { merged.add(it) }
                merged.addAll(cgDeferred.await())
                merged.addAll(yahooDeferred.await())
                Result.success(merged.distinctBy { it.symbol.uppercase(Locale.US) + "_" + it.category })
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun searchCoinGeckoCoins(query: String): List<LiveAssetQuote> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val body = httpGet("https://api.coingecko.com/api/v3/search?query=$encoded") ?: return emptyList()
        val ids = try {
            val arr = JSONObject(body).optJSONArray("coins") ?: return emptyList()
            (0 until minOf(arr.length(), 10)).mapNotNull { idx ->
                arr.optJSONObject(idx)?.optString("id")?.takeIf { it.isNotBlank() }
            }
        } catch (_: Exception) {
            emptyList()
        }
        if (ids.isEmpty()) return emptyList()

        val joined = URLEncoder.encode(ids.joinToString(","), "UTF-8")
        val marketsUrl = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=try&ids=$joined&order=market_cap_desc&per_page=10&page=1&sparkline=true&price_change_percentage=24h"
        val marketsBody = httpGet(marketsUrl) ?: return emptyList()
        return parseCoinGeckoMarketsArray(marketsBody)
    }

    private suspend fun searchYahooSymbols(query: String): List<LiveAssetQuote> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val body = httpGetYahoo("/v1/finance/search?q=$encoded&quotesCount=10&newsCount=0") ?: return emptyList()
        val specs = try {
            val quotes = JSONObject(body).optJSONArray("quotes") ?: return emptyList()
            (0 until minOf(quotes.length(), 10)).mapNotNull { i ->
                val obj = quotes.optJSONObject(i) ?: return@mapNotNull null
                val sym = obj.optString("symbol").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val quoteType = obj.optString("quoteType", "")
                val name = obj.optString("shortname").ifBlank { obj.optString("longname").ifBlank { sym } }
                val cat = when (quoteType.uppercase(Locale.US)) {
                    "CRYPTOCURRENCY" -> MarketCategory.CRYPTO
                    "FUTURE", "COMMODITY" -> MarketCategory.METAL
                    "CURRENCY" -> MarketCategory.FX
                    else -> MarketCategory.FUND
                }
                YahooTickerSpec(
                    symbol = sym,
                    name = name,
                    description = obj.optString("exchDisp", "Piyasa"),
                    category = cat
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
        if (specs.isEmpty()) return emptyList()
        return fetchYahooQuotesBatched(specs, batchSize = 6)
    }

    suspend fun fetchMarketNews(): Result<List<MarketNewsItem>> = withContext(Dispatchers.IO) {
        try {
            val feeds = listOf(
                "TRT Haber Ekonomi" to "https://www.trthaber.com/ekonomi_articles.rss",
                "Bloomberg HT" to "https://www.bloomberght.com/rss",
                "Ekonomi Gündemi" to "https://news.google.com/rss/search?q=alt%C4%B1n+bitcoin+yat%C4%B1r%C4%B1m+fonu+borsa+faiz&hl=tr&gl=TR&ceid=TR:tr"
            )
            val allItems = coroutineScope {
                feeds.map { (defaultSource, rssUrl) ->
                    async {
                        val xml = httpGet(rssUrl) ?: return@async emptyList<MarketNewsItem>()
                        parseRssItems(xml, defaultSource)
                    }
                }.flatMap { it.await() }
            }

            val deduped = allItems
                .distinctBy { it.title.lowercase(Locale.forLanguageTag("tr-TR")).take(48) }
                .sortedByDescending { it.publishedAtMillis }
                .take(12)

            val enriched = enrichNewsImages(deduped)

            if (enriched.isEmpty()) {
                Result.failure(IllegalStateException("Gündem haberleri yüklenemedi. İnternetini kontrol et."))
            } else {
                Result.success(enriched)
            }
        } catch (e: Exception) {
            Log.e(MARKET_TAG, "Failed to fetch market news RSS", e)
            Result.failure(e)
        }
    }

    private suspend fun enrichNewsImages(items: List<MarketNewsItem>): List<MarketNewsItem> = coroutineScope {
        items.map { item ->
            async {
                if (!item.imageUrl.isNullOrBlank()) {
                    item
                } else {
                    val og = fetchArticleImageUrl(item.link)
                    if (!og.isNullOrBlank()) item.copy(imageUrl = og) else item
                }
            }
        }.map { it.await() }
    }

    private fun fetchArticleImageUrl(articleUrl: String): String? {
        if (articleUrl.isBlank()) return null
        val html = httpGetShort(articleUrl, maxBytes = 90_000) ?: return null
        val metaMatches = listOf(
            Regex("""<meta[^>]+(?:property|name)=["'](?:og:image|og:image:secure_url|twitter:image|twitter:image:src)["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["'](?:og:image|og:image:secure_url|twitter:image|twitter:image:src)["']""", RegexOption.IGNORE_CASE)
        )
        for (rx in metaMatches) {
            val found = rx.find(html)?.groupValues?.getOrNull(1)?.trim()
            if (isValidNewsImageUrl(found)) return found
        }
        return extractFirstImageUrl(html)
    }

    private fun extractFirstImageUrl(html: String): String? {
        val imgRegex = Regex("""<img[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        for (match in imgRegex.findAll(html)) {
            val url = match.groupValues.getOrNull(1)?.trim()
            if (isValidNewsImageUrl(url)) return url
        }
        return null
    }

    private fun isValidNewsImageUrl(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val lower = url.lowercase(Locale.US)
        if (!lower.startsWith("http://") && !lower.startsWith("https://")) return false
        if (lower.endsWith(".svg") || lower.contains("favicon") || lower.contains("pixel") || lower.contains("1x1")) return false
        if (lower.contains("lh3.googleusercontent.com") && !lower.contains("=s")) return false
        return true
    }

    suspend fun fetchArticleBodyText(articleUrl: String): String? = withContext(Dispatchers.IO) {
        if (articleUrl.isBlank()) return@withContext null
        val html = httpGet(articleUrl) ?: return@withContext null
        extractReadableParagraphs(html)
    }

    private fun fetchTruncgilQuotes(): Map<String, LiveAssetQuote> {
        val result = mutableMapOf<String, LiveAssetQuote>()
        val endpoints = listOf(
            "https://finans.truncgil.com/today.json",
            "https://finance.truncgil.com/api/today.json"
        )
        val metalSpecs = listOf(
            Triple("gram_altin", listOf("gram-altin", "Gram Altın"), "Gram Altın" to "GAU/TRY"),
            Triple("ceyrek_altin", listOf("ceyrek-altin", "Çeyrek Altın"), "Çeyrek Altın" to "ÇEYREK"),
            Triple("yarim_altin", listOf("yarim-altin", "Yarım Altın"), "Yarım Altın" to "YARIM"),
            Triple("tam_altin", listOf("tam-altin", "Tam Altın"), "Tam Altın" to "TAM"),
            Triple("cumhuriyet_altini", listOf("cumhuriyet-altini", "Cumhuriyet Altını"), "Cumhuriyet Altını" to "CUMHURİYET"),
            Triple("ata_altin", listOf("ata-altin", "Ata Altın"), "Ata Altın" to "ATA"),
            Triple("resat_altin", listOf("resat-altin", "Reşat Altını", "Reşat Altın"), "Reşat Altını" to "REŞAT"),
            Triple("gremse_altin", listOf("gremse-altin", "Gremse Altın"), "Gremse Altın" to "GREMSE"),
            Triple("bilezik_22", listOf("22-ayar-bilezik", "22 Ayar Bilezik"), "22 Ayar Bilezik (Gram)" to "22AYAR"),
            Triple("altin_18", listOf("18-ayar-altin", "18 Ayar Altın"), "18 Ayar Altın (Gram)" to "18AYAR"),
            Triple("altin_14", listOf("14-ayar-altin", "14 Ayar Altın"), "14 Ayar Altın (Gram)" to "14AYAR"),
            Triple("has_altin", listOf("gram-has-altin", "Has Altın"), "Has Altın (Gram)" to "HAS"),
            Triple("gumus", listOf("gumus", "Gümüş"), "Gram Gümüş" to "XAG/TRY")
        )
        val fxSpecs = listOf(
            Triple("usd", listOf("USD", "Dolar"), "Amerikan Doları" to "USD/TRY"),
            Triple("eur", listOf("EUR", "Euro"), "Euro" to "EUR/TRY"),
            Triple("fx_GBP", listOf("GBP", "İngiliz Sterlini"), "İngiliz Sterlini" to "GBP/TRY"),
            Triple("fx_CHF", listOf("CHF", "İsviçre Frangı"), "İsviçre Frangı" to "CHF/TRY"),
            Triple("fx_JPY", listOf("JPY", "Japon Yeni"), "Japon Yeni" to "JPY/TRY"),
            Triple("fx_CAD", listOf("CAD", "Kanada Doları"), "Kanada Doları" to "CAD/TRY"),
            Triple("fx_AUD", listOf("AUD", "Avustralya Doları"), "Avustralya Doları" to "AUD/TRY"),
            Triple("fx_SAR", listOf("SAR", "Suudi Arabistan Riyali"), "Suudi Riyali" to "SAR/TRY")
        )

        for (url in endpoints) {
            val body = httpGet(url) ?: continue
            try {
                val json = JSONObject(body)
                metalSpecs.forEach { (id, keys, labelPair) ->
                    parseTruncgilEntry(json, keys)?.let { (price, change) ->
                        result[id] = LiveAssetQuote(
                            id = id,
                            name = labelPair.first,
                            symbol = labelPair.second,
                            price = price,
                            currency = "TL",
                            changePercent24h = change,
                            category = MarketCategory.METAL,
                            sourceName = "Piyasa"
                        )
                    }
                }
                fxSpecs.forEach { (id, keys, labelPair) ->
                    parseTruncgilEntry(json, keys)?.let { (price, change) ->
                        val baseCode = labelPair.second.substringBefore("/")
                        val yahooSym = if (baseCode == "USD") "TRY=X" else "${baseCode}TRY=X"
                        result[id] = LiveAssetQuote(
                            id = id,
                            name = labelPair.first,
                            symbol = labelPair.second,
                            price = price,
                            currency = "TL",
                            changePercent24h = change,
                            category = MarketCategory.FX,
                            sourceName = "Piyasa",
                            historyKey = yahooSym
                        )
                    }
                }
                if (result.isNotEmpty()) break
            } catch (e: Exception) {
                Log.w(MARKET_TAG, "Truncgil parse error for $url", e)
            }
        }
        return result
    }

    private fun parseTruncgilEntry(root: JSONObject, keys: List<String>): Pair<Double, Double?>? {
        for (k in keys) {
            val obj = root.optJSONObject(k) ?: continue
            val rawPrice = obj.optString("Satış").ifBlank {
                obj.optString("Selling").ifBlank { obj.optString("Alış") }
            }
            val price = parseTurkishNumber(rawPrice) ?: continue
            val rawChange = obj.optString("Değişim").ifBlank { obj.optString("Change") }
            val change = parseTurkishNumber(rawChange.replace("%", ""))
            return price to change
        }
        return null
    }

    // CoinGecko Top 100 Kripto (tek istekte fiyat + 24s değişim + 7g sparkline) + Binance tüm TRY çiftleri
    private suspend fun fetchAllCryptosTry(): List<LiveAssetQuote> = coroutineScope {
        val cgDeferred = async {
            val url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=try&order=market_cap_desc&per_page=100&page=1&sparkline=true&price_change_percentage=24h"
            val body = httpGet(url) ?: return@async emptyList()
            parseCoinGeckoMarketsArray(body)
        }
        val binanceDeferred = async {
            fetchAllBinanceTryCryptos()
        }

        val cgList = cgDeferred.await()
        val binanceList = binanceDeferred.await()

        val seenTickers = HashSet<String>()
        val merged = mutableListOf<LiveAssetQuote>()

        // Preserve stable IDs ("bitcoin", "ethereum", "solana") + CoinGecko top 100
        cgList.forEach { q ->
            val cleanBase = q.symbol.substringBefore("/")
            if (seenTickers.add(cleanBase)) {
                merged.add(q)
            }
        }
        // Merge additional Binance TRY pairs not in CoinGecko top 100 and hydrate top 24 with real 14-day klines
        val extraBinance = binanceList.filter { q ->
            val cleanBase = q.symbol.substringBefore("/")
            seenTickers.add(cleanBase)
        }
        val extraWithSparks = if (extraBinance.isNotEmpty()) {
            val topToHydrate = extraBinance.take(24)
            val sparkResults = topToHydrate.map { q ->
                val base = q.symbol.substringBefore("/")
                async {
                    val kl = fetchBinanceKlinesPrices("${base}TRY", limit = 14)
                    if (kl.size >= 2) q.copy(sparklinePrices = kl) else q
                }
            }.map { it.await() }
            sparkResults + extraBinance.drop(24)
        } else emptyList()

        merged.addAll(extraWithSparks)
        merged
    }

    private fun parseCoinGeckoMarketsArray(body: String): List<LiveAssetQuote> {
        return try {
            val arr = JSONArray(body)
            val list = ArrayList<LiveAssetQuote>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val coinId = obj.optString("id").takeIf { it.isNotBlank() } ?: continue
                val symbol = obj.optString("symbol").uppercase(Locale.US).takeIf { it.isNotBlank() } ?: continue
                val name = obj.optString("name").ifBlank { symbol }
                val price = obj.optDouble("current_price", 0.0)
                if (price <= 0.0 || price.isNaN()) continue
                val chg = obj.optDouble("price_change_percentage_24h", Double.NaN).takeIf { !it.isNaN() }

                val sparkArr = obj.optJSONObject("sparkline_in_7d")?.optJSONArray("price")
                val spark = if (sparkArr != null) {
                    val raw = ArrayList<Double>(sparkArr.length())
                    val step = (sparkArr.length() / 28).coerceAtLeast(1)
                    var idx = 0
                    while (idx < sparkArr.length()) {
                        val p = sparkArr.optDouble(idx, Double.NaN)
                        if (!p.isNaN() && p > 0.0) raw.add(p)
                        idx += step
                    }
                    raw
                } else emptyList()

                val stableId = when (coinId) {
                    "bitcoin" -> "bitcoin"
                    "ethereum" -> "ethereum"
                    "solana" -> "solana"
                    else -> "cg_$coinId"
                }

                list.add(
                    LiveAssetQuote(
                        id = stableId,
                        name = name,
                        symbol = "$symbol/TRY",
                        price = price,
                        currency = "TL",
                        changePercent24h = chg,
                        category = MarketCategory.CRYPTO,
                        sourceName = "CoinGecko",
                        sparklinePrices = spark,
                        historyKey = coinId
                    )
                )
            }
            list
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "CoinGecko markets parse failed", e)
            emptyList()
        }
    }

    private fun fetchAllBinanceTryCryptos(): List<LiveAssetQuote> {
        val body = httpGet("https://api.binance.com/api/v3/ticker/24hr") ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            val quotes = mutableListOf<Pair<Double, LiveAssetQuote>>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val pair = obj.optString("symbol")
                if (!pair.endsWith("TRY")) continue
                val base = pair.removeSuffix("TRY")
                if (base.isBlank() || base in setOf("USDT", "USDC", "FDUSD", "TUSD", "EUR")) continue
                val lastPrice = obj.optString("lastPrice").toDoubleOrNull() ?: 0.0
                val quoteVol = obj.optString("quoteVolume").toDoubleOrNull() ?: 0.0
                if (lastPrice <= 0.0 || quoteVol <= 0.0) continue
                val pct = obj.optString("priceChangePercent").toDoubleOrNull()

                val stableId = when (base) {
                    "BTC" -> "bitcoin"
                    "ETH" -> "ethereum"
                    "SOL" -> "solana"
                    else -> "binance_$base"
                }
                val displayName = when (base) {
                    "BTC" -> "Bitcoin"
                    "ETH" -> "Ethereum"
                    "SOL" -> "Solana"
                    "XRP" -> "XRP (Ripple)"
                    "BNB" -> "BNB"
                    "DOGE" -> "Dogecoin"
                    "ADA" -> "Cardano"
                    "AVAX" -> "Avalanche"
                    "TRX" -> "TRON"
                    "PAXG" -> "PAX Gold (Kripto Altın)"
                    else -> base
                }
                quotes.add(
                    quoteVol to LiveAssetQuote(
                        id = stableId,
                        name = displayName,
                        symbol = "$base/TRY",
                        price = lastPrice,
                        currency = "TL",
                        changePercent24h = pct,
                        category = MarketCategory.CRYPTO,
                        sourceName = "Binance",
                        historyKey = base.lowercase(Locale.US)
                    )
                )
            }
            quotes.sortedByDescending { it.first }.map { it.second }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "Binance 24hr parse failed", e)
            emptyList()
        }
    }

    private fun fetchOpenErRates(): Map<String, LiveAssetQuote> {
        val result = mutableMapOf<String, LiveAssetQuote>()
        val body = httpGet("https://open.er-api.com/v6/latest/USD") ?: return result
        try {
            val root = JSONObject(body)
            val rates = root.optJSONObject("rates") ?: return result
            val tryPerUsd = rates.optDouble("TRY", 0.0)
            if (tryPerUsd <= 0.0) return result

            result["usd"] = LiveAssetQuote(
                id = "usd",
                name = "Amerikan Doları",
                symbol = "USD/TRY",
                price = tryPerUsd,
                currency = "TL",
                changePercent24h = null,
                category = MarketCategory.FX,
                sourceName = "ER-API",
                historyKey = "TRY=X"
            )
            val eurPerUsd = rates.optDouble("EUR", 0.0)
            if (eurPerUsd > 0.0) {
                result["eur"] = LiveAssetQuote(
                    id = "eur",
                    name = "Euro",
                    symbol = "EUR/TRY",
                    price = tryPerUsd / eurPerUsd,
                    currency = "TL",
                    changePercent24h = null,
                    category = MarketCategory.FX,
                    sourceName = "ER-API",
                    historyKey = "EURTRY=X"
                )
            }
            extraCurrencies.forEach { (code, nameTr) ->
                val unitsPerUsd = rates.optDouble(code, 0.0)
                if (unitsPerUsd > 0.0) {
                    result["fx_$code"] = LiveAssetQuote(
                        id = "fx_$code",
                        name = nameTr,
                        symbol = "$code/TRY",
                        price = tryPerUsd / unitsPerUsd,
                        currency = "TL",
                        changePercent24h = null,
                        category = MarketCategory.FX,
                        sourceName = "ER-API",
                        historyKey = "${code}TRY=X"
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "ER-API parse failed", e)
        }
        return result
    }

    private suspend fun fetchFxSparklineMap(): Map<String, List<Double>> = coroutineScope {
        val fxSymbols = listOf(
            "usd" to "TRY=X",
            "eur" to "EURTRY=X"
        ) + extraCurrencies.map { (code, _) -> "fx_$code" to "${code}TRY=X" }

        fxSymbols.map { (id, yahooSym) ->
            async {
                val spec = YahooTickerSpec(
                    symbol = yahooSym,
                    name = id,
                    description = "",
                    category = MarketCategory.FX,
                    fixedId = id
                )
                val q = fetchSingleYahooQuote(spec)
                id to q?.sparklinePrices.orEmpty()
            }
        }.map { it.await() }
            .filter { it.second.size >= 2 }
            .toMap()
    }

    private fun fetchBinanceKlinesPrices(symbol: String, limit: Int): List<Double> {
        val body = httpGet("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=1d&limit=$limit") ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            (0 until arr.length()).mapNotNull { i ->
                arr.optJSONArray(i)?.optString(4)?.toDoubleOrNull()?.takeIf { it > 0.0 }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private suspend fun fetchYahooQuotesBatched(
        specs: List<YahooTickerSpec>,
        batchSize: Int = 8
    ): List<LiveAssetQuote> {
        val out = mutableListOf<LiveAssetQuote>()
        for (chunk in specs.chunked(batchSize)) {
            val chunkResults = coroutineScope {
                chunk.map { spec ->
                    async { fetchSingleYahooQuote(spec) }
                }.mapNotNull { it.await() }
            }
            out.addAll(chunkResults)
        }
        return out
    }

    private fun fetchSingleYahooQuote(spec: YahooTickerSpec): LiveAssetQuote? {
        val encodedSym = URLEncoder.encode(spec.symbol, "UTF-8")
        val body = httpGetYahoo("/v8/finance/chart/$encodedSym?interval=1d&range=1mo") ?: return null
        return try {
            val root = JSONObject(body)
            val chart = root.optJSONObject("chart") ?: return null
            val results = chart.optJSONArray("result") ?: return null
            if (results.length() == 0) return null
            val first = results.getJSONObject(0)
            val meta = first.optJSONObject("meta") ?: return null
            val price = meta.optDouble("regularMarketPrice", 0.0)
            val prevClose = meta.optDouble("previousClose", Double.NaN)
                .takeIf { !it.isNaN() && it > 0.0 }
                ?: meta.optDouble("chartPreviousClose", 0.0)
            val currency = meta.optString("currency", "USD")
            if (price <= 0.0) return null

            val closesArr = first.optJSONObject("indicators")
                ?.optJSONArray("quote")
                ?.optJSONObject(0)
                ?.optJSONArray("close")
            val spark = if (closesArr != null) {
                (0 until closesArr.length()).mapNotNull { idx ->
                    if (closesArr.isNull(idx)) null
                    else closesArr.optDouble(idx, Double.NaN).takeIf { !it.isNaN() && it > 0.0 }
                }
            } else emptyList()

            val changePct = if (prevClose > 0.0) {
                ((price - prevClose) / prevClose) * 100.0
            } else if (spark.size >= 2) {
                val prev = spark[spark.lastIndex - 1]
                if (prev > 0.0) ((price - prev) / prev) * 100.0 else null
            } else null

            LiveAssetQuote(
                id = spec.fixedId ?: "fund_${spec.symbol}",
                name = "${spec.name} (${spec.description})",
                symbol = spec.symbol,
                price = price,
                currency = if (currency == "TRY") "TL" else currency,
                changePercent24h = changePct,
                category = spec.category,
                sourceName = "Yahoo Finance",
                sparklinePrices = spark,
                historyKey = spec.symbol
            )
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "Yahoo parse failed for ${spec.symbol}", e)
            null
        }
    }

    // Türkiye TEFAS tüm aktif yatırım fonlarını çeker (Cloudflare engeli/offline durumunda sessizce boş döner)
    private fun fetchTefasMarketFunds(): List<LiveAssetQuote> {
        return try {
            val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("Europe/Istanbul")
            }
            val nowMs = System.currentTimeMillis()
            val endStr = fmt.format(Date(nowMs))
            val startStr = fmt.format(Date(nowMs - 7L * 24L * 60L * 60L * 1000L))
            val form = "fontip=YAT&sfontur=&fonkod=&fongrup=&bastarih=$startStr&bittarih=$endStr&fonturkod=&fonunvantip="
            val jsonBody = httpPostTefas("https://www.tefas.gov.tr/api/DB/BindHistoryInfo", form)
                ?: return emptyList()

            val root = JSONObject(jsonBody)
            val data = root.optJSONArray("data") ?: return emptyList()
            if (data.length() == 0) return emptyList()

            val grouped = linkedMapOf<String, MutableList<Pair<Long, Double>>>()
            val titles = mutableMapOf<String, String>()
            for (i in 0 until data.length()) {
                val obj = data.optJSONObject(i) ?: continue
                val code = obj.optString("FONKODU").trim()
                val title = obj.optString("FONUNVAN").trim()
                val price = obj.optDouble("FIYAT", 0.0)
                val ts = obj.optLong("TARIH", 0L)
                if (code.isBlank() || price <= 0.0 || price.isNaN()) continue
                if (title.isNotBlank()) titles[code] = title
                grouped.getOrPut(code) { mutableListOf() }.add(ts to price)
            }

            grouped.entries.mapNotNull { (code, pts) ->
                val sorted = pts.sortedBy { it.first }
                val latest = sorted.last().second
                val prev = if (sorted.size >= 2) sorted[sorted.lastIndex - 1].second else 0.0
                val chg = if (prev > 0.0) ((latest - prev) / prev) * 100.0 else null
                LiveAssetQuote(
                    id = "tefas_$code",
                    name = titles[code]?.ifBlank { code } ?: code,
                    symbol = code,
                    price = latest,
                    currency = "TL",
                    changePercent24h = chg,
                    category = MarketCategory.FUND,
                    sourceName = "TEFAS",
                    sparklinePrices = sorted.map { it.second },
                    historyKey = code
                )
            }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "TEFAS batch fetch skipped/unavailable: ${e.message}")
            emptyList()
        }
    }

    private fun fetchSingleTefasFund(code: String): LiveAssetQuote? {
        val points = fetchTefasHistory(code)
        if (points.isEmpty()) return null
        val last = points.last().price
        val prev = if (points.size >= 2) points[points.lastIndex - 1].price else 0.0
        val chg = if (prev > 0.0) ((last - prev) / prev) * 100.0 else null
        return LiveAssetQuote(
            id = "tefas_$code",
            name = "$code Yatırım Fonu",
            symbol = code,
            price = last,
            currency = "TL",
            changePercent24h = chg,
            category = MarketCategory.FUND,
            sourceName = "TEFAS",
            sparklinePrices = points.takeLast(30).map { it.price },
            historyKey = code
        )
    }

    private fun fetchTefasHistory(code: String): List<PricePoint> {
        return try {
            val fmt = SimpleDateFormat("dd.MM.yyyy", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("Europe/Istanbul")
            }
            val nowMs = System.currentTimeMillis()
            val endStr = fmt.format(Date(nowMs))
            val startStr = fmt.format(Date(nowMs - 365L * 24L * 60L * 60L * 1000L))
            val form = "fontip=YAT&sfontur=&fonkod=${URLEncoder.encode(code, "UTF-8")}&fongrup=&bastarih=$startStr&bittarih=$endStr&fonturkod=&fonunvantip="
            val jsonBody = httpPostTefas("https://www.tefas.gov.tr/api/DB/BindHistoryInfo", form) ?: return emptyList()
            val data = JSONObject(jsonBody).optJSONArray("data") ?: return emptyList()
            val raw = ArrayList<PricePoint>(data.length())
            for (i in 0 until data.length()) {
                val obj = data.optJSONObject(i) ?: continue
                val ts = obj.optLong("TARIH", 0L)
                val p = obj.optDouble("FIYAT", Double.NaN)
                if (ts > 0L && !p.isNaN() && p > 0.0) {
                    raw.add(PricePoint(ts, CurrencyUtils.formatDayMonth(ts), p))
                }
            }
            raw.sortedBy { it.timestampMillis }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "TEFAS history skipped for $code: ${e.message}")
            emptyList()
        }
    }

    suspend fun fetchAssetHistory(
        assetId: String,
        symbol: String,
        currentPrice: Double,
        historyKey: String = ""
    ): Result<List<PricePoint>> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = symbol.substringBefore("/").uppercase(Locale.US)
            val points: List<PricePoint> = when {
                assetId.startsWith("tefas_") -> {
                    fetchTefasHistory(historyKey.ifBlank { symbol })
                }
                assetId in setOf(
                    "gram_altin", "ceyrek_altin", "yarim_altin", "tam_altin",
                    "cumhuriyet_altini", "ata_altin", "resat_altin", "gremse_altin",
                    "bilezik_22", "altin_18", "altin_14", "has_altin"
                ) -> {
                    val base = fetchBinanceKlines("PAXGTRY", divisor = 31.1034768)
                        .ifEmpty { fetchCoinGeckoHistory("pax-gold", divisor = 31.1034768) }
                        .ifEmpty { fetchYahooHistory("ZGOLD.IS") }
                        .ifEmpty { fetchYahooHistory("GLD") }
                    scaleHistoryToCurrentPrice(base, currentPrice)
                }
                assetId == "gumus" -> {
                    val base = fetchYahooHistory("GMSTR.IS")
                        .ifEmpty { fetchYahooHistory("SI=F") }
                        .ifEmpty { fetchYahooHistory("SLV") }
                    scaleHistoryToCurrentPrice(base, currentPrice)
                }
                assetId.startsWith("metal_try_") && historyKey.isNotBlank() -> {
                    scaleHistoryToCurrentPrice(fetchYahooHistory(historyKey), currentPrice)
                }
                assetId == "usd" -> fetchYahooHistory("TRY=X")
                assetId == "eur" -> fetchYahooHistory("EURTRY=X")
                assetId.startsWith("fx_") -> {
                    val sym = historyKey.ifBlank { "${cleanBase}TRY=X" }
                    scaleHistoryToCurrentPrice(fetchYahooHistory(sym), currentPrice)
                }
                assetId == "bitcoin" || assetId == "ethereum" || assetId == "solana" ||
                    assetId.startsWith("cg_") || assetId.startsWith("binance_") -> {
                    val cgId = historyKey.ifBlank {
                        when (assetId) {
                            "bitcoin" -> "bitcoin"
                            "ethereum" -> "ethereum"
                            "solana" -> "solana"
                            else -> assetId.removePrefix("cg_")
                        }
                    }
                    val tryHist = fetchBinanceKlines("${cleanBase}TRY")
                        .ifEmpty { if (cgId.isNotBlank()) fetchCoinGeckoHistory(cgId) else emptyList() }
                    tryHist.ifEmpty {
                        val usdtOrYahoo = fetchBinanceKlines("${cleanBase}USDT")
                            .ifEmpty { fetchYahooHistory("$cleanBase-USD") }
                        scaleHistoryToCurrentPrice(usdtOrYahoo, currentPrice)
                    }
                }
                else -> {
                    val ticker = historyKey.ifBlank { assetId.removePrefix("fund_").ifBlank { symbol } }
                    fetchYahooHistory(ticker)
                }
            }

            if (points.size < 2) {
                Result.failure(IllegalStateException("Bu varlık için geçmiş grafik verisi şu an alınamadı."))
            } else {
                Result.success(points)
            }
        } catch (e: Exception) {
            Log.e(MARKET_TAG, "Failed to fetch history for $assetId", e)
            Result.failure(e)
        }
    }

    private fun roundSmart(value: Double): Double {
        return if (value >= 10.0) CurrencyUtils.round2(value) else value
    }

    private fun scaleHistoryToCurrentPrice(
        points: List<PricePoint>,
        targetLastPrice: Double
    ): List<PricePoint> {
        if (points.isEmpty() || targetLastPrice <= 0.0) return points
        val last = points.last().price
        if (last <= 0.0) return points
        val factor = targetLastPrice / last
        if (kotlin.math.abs(factor - 1.0) < 0.02) return points
        return points.map { it.copy(price = roundSmart(it.price * factor)) }
    }

    private fun fetchBinanceKlines(symbol: String, divisor: Double = 1.0): List<PricePoint> {
        val body = httpGet("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=1d&limit=365") ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            val list = ArrayList<PricePoint>(arr.length())
            for (i in 0 until arr.length()) {
                val row = arr.optJSONArray(i) ?: continue
                val ts = row.optLong(0, 0L)
                val close = row.optString(4).toDoubleOrNull() ?: continue
                if (ts > 0L && close > 0.0) {
                    val scaled = roundSmart(close / divisor)
                    list.add(PricePoint(ts, CurrencyUtils.formatDayMonth(ts), scaled))
                }
            }
            list
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "Binance klines parse error for $symbol", e)
            emptyList()
        }
    }

    private fun fetchCoinGeckoHistory(coinId: String, divisor: Double = 1.0): List<PricePoint> {
        val body = httpGet("https://api.coingecko.com/api/v3/coins/$coinId/market_chart?vs_currency=try&days=365")
            ?: return emptyList()
        return try {
            val root = JSONObject(body)
            val prices = root.optJSONArray("prices") ?: return emptyList()
            val list = ArrayList<PricePoint>(prices.length())
            for (i in 0 until prices.length()) {
                val pair = prices.optJSONArray(i) ?: continue
                val ts = pair.optLong(0, 0L)
                val p = pair.optDouble(1, Double.NaN)
                if (ts > 0L && !p.isNaN() && p > 0.0) {
                    val scaled = roundSmart(p / divisor)
                    list.add(PricePoint(ts, CurrencyUtils.formatDayMonth(ts), scaled))
                }
            }
            list
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "CoinGecko chart parse error for $coinId", e)
            emptyList()
        }
    }

    private fun fetchYahooHistory(symbol: String): List<PricePoint> {
        val encodedSym = URLEncoder.encode(symbol, "UTF-8")
        val body = httpGetYahoo("/v8/finance/chart/$encodedSym?interval=1d&range=1y")
            ?: return emptyList()
        return try {
            val root = JSONObject(body)
            val chart = root.optJSONObject("chart") ?: return emptyList()
            val results = chart.optJSONArray("result") ?: return emptyList()
            if (results.length() == 0) return emptyList()
            val first = results.getJSONObject(0)
            val timestamps = first.optJSONArray("timestamp") ?: return emptyList()
            val indicators = first.optJSONObject("indicators") ?: return emptyList()
            val quoteArr = indicators.optJSONArray("quote") ?: return emptyList()
            if (quoteArr.length() == 0) return emptyList()
            val closes = quoteArr.getJSONObject(0).optJSONArray("close") ?: return emptyList()

            val len = minOf(timestamps.length(), closes.length())
            val list = ArrayList<PricePoint>(len)
            for (i in 0 until len) {
                if (closes.isNull(i)) continue
                val sec = timestamps.optLong(i, 0L)
                val close = closes.optDouble(i, Double.NaN)
                if (sec > 0L && !close.isNaN() && close > 0.0) {
                    val tsMillis = sec * 1000L
                    list.add(PricePoint(tsMillis, CurrencyUtils.formatDayMonth(tsMillis), roundSmart(close)))
                }
            }
            list
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "Yahoo chart parse error for $symbol", e)
            emptyList()
        }
    }

    private fun parseRssItems(xml: String, defaultSource: String): List<MarketNewsItem> {
        val items = mutableListOf<MarketNewsItem>()
        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xml))

            var eventType = parser.eventType
            var insideItem = false
            var insideImageTag = false
            var title = ""
            var description = ""
            var contentEncoded = ""
            var link = ""
            var pubDate = ""
            var source = ""
            var imageUrl: String? = null

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        val tag = parser.name
                        if (tag == "item") {
                            insideItem = true
                            insideImageTag = false
                            title = ""
                            description = ""
                            contentEncoded = ""
                            link = ""
                            pubDate = ""
                            source = ""
                            imageUrl = null
                        } else if (insideItem) {
                            when (tag) {
                                "title" -> title = parser.nextText().trim()
                                "description" -> description = parser.nextText().trim()
                                "content:encoded" -> contentEncoded = parser.nextText().trim()
                                "link" -> link = parser.nextText().trim()
                                "pubDate" -> pubDate = parser.nextText().trim()
                                "source" -> source = parser.nextText().trim()
                                "image" -> insideImageTag = true
                                "enclosure" -> {
                                    val attrUrl = parser.getAttributeValue(null, "url")?.trim()?.replace("&amp;", "&")
                                    val attrType = parser.getAttributeValue(null, "type")?.lowercase(Locale.US).orEmpty()
                                    if (imageUrl == null && (attrType.startsWith("image") || attrType.isBlank()) && isValidNewsImageUrl(attrUrl)) {
                                        imageUrl = attrUrl
                                    }
                                }
                                "media:content", "media:thumbnail", "media:group" -> {
                                    val attrUrl = parser.getAttributeValue(null, "url")?.trim()?.replace("&amp;", "&")
                                    if (imageUrl == null && isValidNewsImageUrl(attrUrl)) {
                                        imageUrl = attrUrl
                                    }
                                }
                                "url" -> {
                                    if (insideImageTag) {
                                        val textUrl = parser.nextText().trim().replace("&amp;", "&")
                                        if (imageUrl == null && isValidNewsImageUrl(textUrl)) {
                                            imageUrl = textUrl
                                        }
                                    }
                                }
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "image") {
                            insideImageTag = false
                        }
                        if (parser.name == "item" && insideItem) {
                            if (imageUrl == null) {
                                imageUrl = (extractFirstImageUrl(description)
                                    ?: extractFirstImageUrl(contentEncoded))?.replace("&amp;", "&")
                            }
                            insideImageTag = false
                            val cleanTitle = cleanHtmlText(title)
                            val cleanDesc = cleanHtmlText(description.ifBlank { contentEncoded })
                            val usableSummary = if (
                                cleanDesc.isBlank() ||
                                cleanDesc.equals(cleanTitle, ignoreCase = true) ||
                                cleanDesc.startsWith(cleanTitle.take(28), ignoreCase = true) && cleanDesc.length < cleanTitle.length + 25
                            ) {
                                ""
                            } else {
                                cleanDesc.take(280)
                            }

                            if (cleanTitle.isNotBlank()) {
                                val (millis, formattedDate) = CurrencyUtils.parseRssPubDateToIstanbul(pubDate)
                                val resolvedSource = source.ifBlank { defaultSource }
                                items.add(
                                    MarketNewsItem(
                                        title = cleanTitle,
                                        summary = usableSummary,
                                        source = resolvedSource,
                                        publishedAt = formattedDate,
                                        publishedAtMillis = millis,
                                        link = link,
                                        fundImpact = analyzeNewsFundImpact(cleanTitle, usableSummary),
                                        imageUrl = imageUrl
                                    )
                                )
                            }
                            insideItem = false
                        }
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "RSS parse error", e)
        }
        return items
    }

    private fun cleanHtmlText(raw: String): String {
        if (raw.isBlank()) return ""
        val stripped = raw
            .replace(Regex("<script[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("<style[\\s\\S]*?</style>", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&#8217;", "'")
            .replace("&#8216;", "'")
            .replace("&#8220;", "\"")
            .replace("&#8221;", "\"")
        val withDecEntities = Regex("&#(\\d+);").replace(stripped) { match ->
            val code = match.groupValues[1].toIntOrNull()
            if (code != null && code in 32..0x10FFFF) code.toChar().toString() else ""
        }
        val withHexEntities = Regex("&#x([0-9a-fA-F]+);").replace(withDecEntities) { match ->
            val code = match.groupValues[1].toIntOrNull(16)
            if (code != null && code in 32..0x10FFFF) code.toChar().toString() else ""
        }
        return withHexEntities
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun extractReadableParagraphs(html: String): String? {
        val matches = Regex("<p[^>]*>([\\s\\S]*?)</p>", RegexOption.IGNORE_CASE).findAll(html)
        val paragraphs = matches
            .map { cleanHtmlText(it.groupValues[1]) }
            .filter { it.length >= 45 && !it.contains("çerez", ignoreCase = true) && !it.contains("cookie", ignoreCase = true) }
            .distinct()
            .take(8)
            .toList()
        return if (paragraphs.isEmpty()) null else paragraphs.joinToString("\n\n")
    }

    companion object {
        fun analyzeNewsFundImpact(title: String, summary: String): FundImpactAssessment {
            val text = "$title $summary".lowercase(Locale.forLanguageTag("tr-TR"))

            val hasGold = listOf("altın", "gram", "ons", "xau", "gümüş", "platin", "değerli metal").any { text.contains(it) }
            val hasBtc = listOf("bitcoin", "btc", "kripto", "ethereum", "eth", "coin", "blokzincir").any { text.contains(it) }
            val hasRateHikeOrTight = listOf("faiz art", "sıkılaş", "şahin", "yüksek faiz", "tcmb faiz", "mevduat", "politika faiz").any { text.contains(it) }
            val hasRateCutOrStimulus = listOf("faiz indir", "gevşeme", "likidite", "teşvik", "güvercin").any { text.contains(it) }
            val hasFxUp = listOf("dolar", "euro", "kur ", "kurda", "döviz", "enflasyon", "tüfe").any { text.contains(it) }
            val hasEquityOrBist = listOf("borsa", "bist", "hisse", "endeks", "s&p", "nasdaq", "teknoloji", "şirket").any { text.contains(it) }
            val hasRiskOff = listOf("düşüş", "gerile", "kayıp", "satış baskı", "savaş", "jeopolitik", "gerilim", "risk", "çöküş", "belirsiz").any { text.contains(it) }
            val hasRally = listOf("rekor", "yüksel", "ralli", "artış", "zirve", "büyüme", "kazanç", "iyimser", "talep").any { text.contains(it) }

            return when {
                hasBtc -> {
                    val dir = when {
                        hasRiskOff && !hasRally -> ImpactDirection.NEGATIVE
                        hasRally -> ImpactDirection.POSITIVE
                        else -> ImpactDirection.MIXED
                    }
                    val why = when (dir) {
                        ImpactDirection.POSITIVE -> "Kripto piyasasındaki alım iştahı Bitcoin Fonu ve küresel kripto ETF'lerini (IBIT) yukarı taşıyabilir."
                        ImpactDirection.NEGATIVE -> "Kripto satış baskısı Bitcoin Fonu'nda sert oynaklık ve düşüş riski yaratabilir; temkinli kalınmalı."
                        ImpactDirection.MIXED -> "Kripto haber akışı Bitcoin Fonu'nda çift yönlü oynaklığı artırabilir; kademeli takip önerilir."
                    }
                    FundImpactAssessment(listOf("Bitcoin Fonu", "IBIT ETF"), dir, why)
                }
                hasGold -> {
                    val dir = when {
                        hasRiskOff || hasRally || hasRateCutOrStimulus || hasFxUp -> ImpactDirection.POSITIVE
                        else -> ImpactDirection.MIXED
                    }
                    val why = if (dir == ImpactDirection.POSITIVE) {
                        "Güvenli liman talebi ve ons/kur desteği Altın Fonu (GLD) ile Katılım Fonları üzerinde yükseliş yönlü etki oluşturabilir."
                    } else {
                        "Altın fiyatındaki yatay/karmaşık seyir Altın Fonu'nda kısa vadeli dalgalanma yaratabilir."
                    }
                    FundImpactAssessment(listOf("Altın Fonu", "GLD ETF", "Katılım Fonu"), dir, why)
                }
                hasRateHikeOrTight -> {
                    FundImpactAssessment(
                        affectedFunds = listOf("Para Piyasası Fonu", "Hisse Senedi Fonu"),
                        direction = ImpactDirection.POSITIVE,
                        rationale = "Yüksek faiz ortamı Para Piyasası Fonu'nun aylık bileşik getirisini güçlendirirken, Hisse Senedi Fonları üzerinde kısa vadeli baskı kurabilir."
                    )
                }
                hasEquityOrBist -> {
                    val dir = when {
                        hasRiskOff && !hasRally -> ImpactDirection.NEGATIVE
                        hasRally || hasRateCutOrStimulus -> ImpactDirection.POSITIVE
                        else -> ImpactDirection.MIXED
                    }
                    val why = when (dir) {
                        ImpactDirection.POSITIVE -> "Piyasadaki pozitif risk iştahı Hisse Senedi Fonu (BIST / SPY / QQQ) tarafında getiri potansiyelini artırabilir."
                        ImpactDirection.NEGATIVE -> "Borsa tarafındaki satış ve belirsizlik Hisse Senedi Fonları'nda geçici değer kaybına yol açabilir; Para Piyasası koruma sağlar."
                        ImpactDirection.MIXED -> "Endeks ve şirket haberleri Hisse Senedi Fonları'nda seçici ve dalgalı bir seyir izletebilir."
                    }
                    FundImpactAssessment(listOf("Hisse Senedi Fonu", "SPY / QQQ / XU100"), dir, why)
                }
                hasFxUp -> {
                    FundImpactAssessment(
                        affectedFunds = listOf("Eurobond Fonu", "Altın Fonu"),
                        direction = ImpactDirection.POSITIVE,
                        rationale = "Döviz ve enflasyon dinamikleri döviz bazlı Eurobond Fonu ile Altın Fonu'nun TL bazlı koruma gücünü destekleyebilir."
                    )
                }
                hasRateCutOrStimulus -> {
                    FundImpactAssessment(
                        affectedFunds = listOf("Altın Fonu", "Hisse Senedi Fonu"),
                        direction = ImpactDirection.POSITIVE,
                        rationale = "Parasal gevşeme ve likidite artışı büyüme odaklı Hisse Senedi ve Altın Fonları için destekleyici ortam sunar."
                    )
                }
                hasRiskOff -> {
                    FundImpactAssessment(
                        affectedFunds = listOf("Para Piyasası Fonu", "Altın Fonu"),
                        direction = ImpactDirection.MIXED,
                        rationale = "Piyasa belirsizliğinde riskli fonlar baskılanırken Para Piyasası ve Altın Fonu sermaye koruması sağlar."
                    )
                }
                else -> {
                    FundImpactAssessment(
                        affectedFunds = listOf("Para Piyasası Fonu", "Dengeli Sepet"),
                        direction = ImpactDirection.MIXED,
                        rationale = "Makro ekonomi haberi tüm fon sınıflarında dengeli sepet ve kademeli pozisyon alma gerekliliğini öne çıkarır."
                    )
                }
            }
        }

        fun aggregateFundSignals(news: List<MarketNewsItem>): List<FundMarketSignal> {
            val trackedFunds = listOf(
                "Altın Fonu",
                "Para Piyasası Fonu",
                "Hisse Senedi Fonu",
                "Bitcoin Fonu",
                "Eurobond Fonu"
            )
            return trackedFunds.map { fund ->
                var pos = 0
                var neg = 0
                var mix = 0
                news.forEach { item ->
                    val matches = item.fundImpact.affectedFunds.any {
                        it.contains(fund.removeSuffix(" Fonu"), ignoreCase = true)
                    }
                    if (matches) {
                        when (item.fundImpact.direction) {
                            ImpactDirection.POSITIVE -> pos++
                            ImpactDirection.NEGATIVE -> neg++
                            ImpactDirection.MIXED -> mix++
                        }
                    }
                }
                FundMarketSignal(
                    fundName = fund,
                    positiveCount = pos,
                    negativeCount = neg,
                    mixedCount = mix
                )
            }
        }

        fun resolveBenchmarkQuoteIdForFundName(fundType: String): String {
            return when {
                fundType.contains("Altın", ignoreCase = true) -> "gram_altin"
                fundType.contains("Bitcoin", ignoreCase = true) -> "bitcoin"
                fundType.contains("Hisse", ignoreCase = true) -> "fund_XU100.IS"
                fundType.contains("Eurobond", ignoreCase = true) -> "fund_EMB"
                fundType.contains("Katılım", ignoreCase = true) -> "fund_ZGOLD.IS"
                else -> "fund_SGOV"
            }
        }

        fun resolvePopular30Mixed(allQuotes: List<LiveAssetQuote>): List<LiveAssetQuote> {
            if (allQuotes.isEmpty()) return emptyList()
            val byId = allQuotes.associateBy { it.id }

            // En çok bakılan 30 Fon + Maden + Kripto dengeli karışık sıra
            val priorityGroups: List<List<String>> = listOf(
                listOf("gram_altin"),
                listOf("bitcoin"),
                listOf("fund_XU100.IS"),
                listOf("ceyrek_altin"),
                listOf("ethereum"),
                listOf("fund_ZGOLD.IS"),
                listOf("gumus"),
                listOf("solana"),
                listOf("fund_GLDTR.IS"),
                listOf("yarim_altin"),
                listOf("cg_ripple", "binance_XRP"),
                listOf("fund_SPY"),
                listOf("tam_altin"),
                listOf("cg_binancecoin", "binance_BNB"),
                listOf("fund_QQQ"),
                listOf("fund_GC=F"),
                listOf("cg_avalanche-2", "binance_AVAX"),
                listOf("fund_GMSTR.IS"),
                listOf("metal_try_platin"),
                listOf("cg_dogecoin", "binance_DOGE"),
                listOf("fund_IBIT"),
                listOf("fund_SI=F"),
                listOf("cg_cardano", "binance_ADA"),
                listOf("fund_XU030.IS"),
                listOf("fund_BZ=F"),
                listOf("cg_chainlink", "binance_LINK"),
                listOf("fund_XBANK.IS"),
                listOf("fund_HG=F"),
                listOf("cg_tron", "binance_TRX"),
                listOf("fund_GLD"),
                listOf("fund_VOO"),
                listOf("fund_SMH"),
                listOf("fund_SCHD"),
                listOf("fund_EMB"),
                listOf("fund_SGOV")
            )

            val selected = ArrayList<LiveAssetQuote>(30)
            val seenIds = HashSet<String>(32)

            for (candidates in priorityGroups) {
                if (selected.size >= 30) break
                val match = candidates.firstNotNullOfOrNull { byId[it] }
                if (match != null && seenIds.add(match.id)) {
                    selected.add(match)
                }
            }

            if (selected.size < 30) {
                val fundsPool = allQuotes.filter { it.category == MarketCategory.FUND && it.id !in seenIds }
                val metalsPool = allQuotes.filter { it.category == MarketCategory.METAL && it.id !in seenIds }
                val cryptoPool = allQuotes.filter { it.category == MarketCategory.CRYPTO && it.id !in seenIds }
                val maxPool = maxOf(fundsPool.size, metalsPool.size, cryptoPool.size)
                for (i in 0 until maxPool) {
                    if (selected.size >= 30) break
                    if (i < metalsPool.size && seenIds.add(metalsPool[i].id)) selected.add(metalsPool[i])
                    if (selected.size < 30 && i < cryptoPool.size && seenIds.add(cryptoPool[i].id)) selected.add(cryptoPool[i])
                    if (selected.size < 30 && i < fundsPool.size && seenIds.add(fundsPool[i].id)) selected.add(fundsPool[i])
                }
            }

            if (selected.size < 30) {
                for (q in allQuotes) {
                    if (selected.size >= 30) break
                    if (seenIds.add(q.id)) selected.add(q)
                }
            }

            return selected.take(30)
        }
    }

    private fun parseTurkishNumber(raw: String): Double? {
        val cleaned = raw.trim().replace("$", "").replace("TL", "").trim()
        if (cleaned.isEmpty()) return null
        val normalized = if (cleaned.contains(",") && cleaned.contains(".")) {
            cleaned.replace(".", "").replace(",", ".")
        } else if (cleaned.contains(",")) {
            cleaned.replace(",", ".")
        } else {
            cleaned
        }
        return normalized.toDoubleOrNull()
    }

    private fun httpPostTefas(urlString: String, formBody: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 5000
                readTimeout = 6000
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                setRequestProperty("X-Requested-With", "XMLHttpRequest")
                setRequestProperty("Referer", "https://www.tefas.gov.tr/TarihselVeriler.aspx")
                setRequestProperty("Origin", "https://www.tefas.gov.tr")
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(formBody)
                writer.flush()
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                Log.w(MARKET_TAG, "TEFAS HTTP ${conn.responseCode}")
                null
            }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "TEFAS request skipped: ${e.message}")
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpGetYahoo(pathAndQuery: String): String? {
        return httpGet("https://query1.finance.yahoo.com$pathAndQuery")
            ?: httpGet("https://query2.finance.yahoo.com$pathAndQuery")
    }

    private fun httpGetShort(urlString: String, maxBytes: Int = 90_000): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                instanceFollowRedirects = true
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*")
            }
            if (conn.responseCode in 200..299) {
                val stream = conn.inputStream
                val buffer = ByteArray(4096)
                val out = java.io.ByteArrayOutputStream()
                var total = 0
                while (total < maxBytes) {
                    val read = stream.read(buffer)
                    if (read <= 0) break
                    out.write(buffer, 0, read)
                    total += read
                }
                out.toString("UTF-8")
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpGet(urlString: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(urlString)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                )
                setRequestProperty("Accept", "application/json, application/xml, text/xml, */*")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                Log.w(MARKET_TAG, "HTTP ${conn.responseCode} for $urlString")
                null
            }
        } catch (e: Exception) {
            Log.w(MARKET_TAG, "Network call failed for $urlString: ${e.message}")
            null
        } finally {
            conn?.disconnect()
        }
    }
}
