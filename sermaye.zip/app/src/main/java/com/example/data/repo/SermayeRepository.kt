package com.example.data.repo

import androidx.room.withTransaction
import com.example.data.local.AssetPriceAlertRule
import com.example.data.local.FundEntity
import com.example.data.local.FundSnapshotEntity
import com.example.data.local.MarketNoteEntity
import com.example.data.local.MarketTagEntity
import com.example.data.local.SermayeDatabase
import com.example.data.local.TagPriceEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.UserPreferencesDataStore
import com.example.data.local.UserProfile
import com.example.data.local.VaultBalancesEntity
import com.example.data.local.VaultType
import com.example.domain.AVAILABLE_FUND_OPTIONS
import com.example.domain.FinanceEngine
import com.example.domain.RiskProfileMode
import com.example.util.CurrencyUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

sealed interface RepoResult<out T> {
    data class Success<T>(val data: T) : RepoResult<T>
    data class Error(val message: String) : RepoResult<Nothing>
}

class SermayeRepository(
    private val db: SermayeDatabase,
    private val prefs: UserPreferencesDataStore
) {
    private val balancesDao = db.vaultBalancesDao()
    private val txDao = db.transactionDao()
    private val fundDao = db.fundDao()
    private val marketDao = db.marketDao()

    val userProfileFlow: Flow<UserProfile> = prefs.userProfileFlow
    val balancesFlow: Flow<VaultBalancesEntity> = balancesDao.observeBalances().map {
        it ?: VaultBalancesEntity(id = 1, storeBalance = 0.0, idleFundCash = 0.0, selfBalance = 0.0)
    }
    val transactionsFlow: Flow<List<TransactionEntity>> = txDao.observeAllTransactions()
    val fundsFlow: Flow<List<FundEntity>> = fundDao.observeAllFunds()
    val snapshotsFlow: Flow<List<FundSnapshotEntity>> = fundDao.observeSnapshots()
    val tagsFlow: Flow<List<MarketTagEntity>> = marketDao.observeTags()
    val tagPricesFlow: Flow<List<TagPriceEntity>> = marketDao.observeAllTagPrices()
    val notesFlow: Flow<List<MarketNoteEntity>> = marketDao.observeNotes()

    suspend fun completeSetup(
        userName: String,
        email: String,
        initialStore: Double,
        initialFund: Double,
        initialSelf: Double,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) {
        db.withTransaction {
            val cleanStore = CurrencyUtils.round2(initialStore)
            val cleanFund = CurrencyUtils.round2(initialFund)
            val cleanSelf = CurrencyUtils.round2(initialSelf)

            balancesDao.upsertBalances(
                VaultBalancesEntity(
                    id = 1,
                    storeBalance = cleanStore,
                    idleFundCash = cleanFund,
                    selfBalance = cleanSelf
                )
            )

            val totalInitial = CurrencyUtils.round2(cleanStore + cleanFund + cleanSelf)
            if (totalInitial > 0.0) {
                txDao.insertTransaction(
                    TransactionEntity(
                        dateMillis = System.currentTimeMillis(),
                        amount = totalInitial,
                        sourceOrCategory = "Başlangıç Kasası",
                        note = "Kurulum açılış bakiyesi",
                        storeDelta = cleanStore,
                        fundDelta = cleanFund,
                        selfDelta = cleanSelf,
                        type = TransactionType.INPUT.name
                    )
                )
                recordCurrentFundSnapshotInternal()
            }
        }

        prefs.saveSetupProfile(
            userName = userName,
            email = email,
            monthlyIncome = monthlyIncome,
            storeRatio = storeRatio,
            fundRatio = fundRatio,
            selfRatio = selfRatio,
            storeTargetAmount = storeTargetAmount,
            storeTargetDateMillis = storeTargetDateMillis
        )
    }

    suspend fun updateSettingsProfile(
        userName: String,
        email: String,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) {
        prefs.saveSetupProfile(
            userName = userName,
            email = email,
            monthlyIncome = monthlyIncome,
            storeRatio = storeRatio,
            fundRatio = fundRatio,
            selfRatio = selfRatio,
            storeTargetAmount = storeTargetAmount,
            storeTargetDateMillis = storeTargetDateMillis
        )
    }

    suspend fun setDarkMode(isDark: Boolean) = prefs.setDarkMode(isDark)

    suspend fun setWeeklyReminderEnabled(enabled: Boolean) = prefs.setWeeklyReminderEnabled(enabled)

    suspend fun dismissWeeklyReminder(epochDay: Long) = prefs.dismissWeeklyReminder(epochDay)

    suspend fun setMarketAlertsEnabled(enabled: Boolean) = prefs.setMarketAlertsEnabled(enabled)

    suspend fun setAlertThresholdPercent(threshold: Double) = prefs.setAlertThresholdPercent(threshold)

    suspend fun saveLastAlertPrices(goldPrice: Double, btcPrice: Double, topFundPrice: Double) =
        prefs.saveLastAlertPrices(goldPrice, btcPrice, topFundPrice)

    suspend fun toggleFavoriteAsset(assetId: String): Boolean = prefs.toggleFavoriteAsset(assetId)

    suspend fun saveAssetAlert(rule: AssetPriceAlertRule) = prefs.saveAssetAlert(rule)

    suspend fun removeAssetAlert(assetId: String) = prefs.removeAssetAlert(assetId)

    fun preferencesStore(): UserPreferencesDataStore = prefs

    suspend fun addIncome(
        amount: Double,
        source: String,
        note: String,
        dateMillis: Long,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int
    ): RepoResult<Triple<Double, Double, Double>> {
        if (amount <= 0.0) return RepoResult.Error("Lütfen tutar gir")
        if (source.isBlank()) return RepoResult.Error("Kaynak seç")

        val storePart = CurrencyUtils.round2(amount * (storeRatio / 100.0))
        val fundPart = CurrencyUtils.round2(amount * (fundRatio / 100.0))
        val selfPart = CurrencyUtils.round2(amount - storePart - fundPart)

        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            balancesDao.upsertBalances(
                current.copy(
                    storeBalance = CurrencyUtils.round2(current.storeBalance + storePart),
                    idleFundCash = CurrencyUtils.round2(current.idleFundCash + fundPart),
                    selfBalance = CurrencyUtils.round2(current.selfBalance + selfPart)
                )
            )
            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = dateMillis,
                    amount = CurrencyUtils.round2(amount),
                    sourceOrCategory = source,
                    note = note.trim().take(50),
                    storeDelta = storePart,
                    fundDelta = fundPart,
                    selfDelta = selfPart,
                    type = TransactionType.INPUT.name
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return RepoResult.Success(Triple(storePart, fundPart, selfPart))
    }

    suspend fun withdrawFromVault(
        vault: VaultType,
        amount: Double,
        category: String,
        note: String,
        dateMillis: Long
    ): RepoResult<Unit> {
        if (amount <= 0.0) return RepoResult.Error("Lütfen tutar gir")
        if (category.isBlank()) return RepoResult.Error("Harcama türü seç")

        var errorMsg: String? = null
        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            val available = when (vault) {
                VaultType.STORE -> current.storeBalance
                VaultType.FUND -> current.idleFundCash
                VaultType.SELF -> current.selfBalance
            }
            if (amount > available + 0.0001) {
                errorMsg = "Bu kasada yeterli para yok. Kasan: ${CurrencyUtils.formatTL(available)}, " +
                    "çıkarmak istediğin: ${CurrencyUtils.formatTL(amount)}"
                return@withTransaction
            }
            val cleanAmount = CurrencyUtils.round2(amount)
            val updated = when (vault) {
                VaultType.STORE -> current.copy(storeBalance = CurrencyUtils.round2(current.storeBalance - cleanAmount))
                VaultType.FUND -> current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash - cleanAmount))
                VaultType.SELF -> current.copy(selfBalance = CurrencyUtils.round2(current.selfBalance - cleanAmount))
            }
            balancesDao.upsertBalances(updated)
            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = dateMillis,
                    amount = cleanAmount,
                    sourceOrCategory = "${vault.label} • $category",
                    note = note.trim().take(50),
                    storeDelta = if (vault == VaultType.STORE) -cleanAmount else 0.0,
                    fundDelta = if (vault == VaultType.FUND) -cleanAmount else 0.0,
                    selfDelta = if (vault == VaultType.SELF) -cleanAmount else 0.0,
                    type = TransactionType.EXPENSE.name
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return if (errorMsg != null) RepoResult.Error(errorMsg!!) else RepoResult.Success(Unit)
    }

    suspend fun transferBetweenVaults(
        from: VaultType,
        to: VaultType,
        amount: Double
    ): RepoResult<Unit> {
        if (from == to) return RepoResult.Error("Aynı kasaya transfer olmaz")
        if (amount <= 0.0) return RepoResult.Error("Lütfen tutar gir")

        var errorMsg: String? = null
        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            val available = when (from) {
                VaultType.STORE -> current.storeBalance
                VaultType.FUND -> current.idleFundCash
                VaultType.SELF -> current.selfBalance
            }
            if (amount > available + 0.0001) {
                errorMsg = "Bu kasada yeterli para yok. Kasan: ${CurrencyUtils.formatTL(available)}, " +
                    "transfer etmek istediğin: ${CurrencyUtils.formatTL(amount)}"
                return@withTransaction
            }

            val clean = CurrencyUtils.round2(amount)
            var store = current.storeBalance
            var fund = current.idleFundCash
            var self = current.selfBalance

            when (from) {
                VaultType.STORE -> store = CurrencyUtils.round2(store - clean)
                VaultType.FUND -> fund = CurrencyUtils.round2(fund - clean)
                VaultType.SELF -> self = CurrencyUtils.round2(self - clean)
            }
            when (to) {
                VaultType.STORE -> store = CurrencyUtils.round2(store + clean)
                VaultType.FUND -> fund = CurrencyUtils.round2(fund + clean)
                VaultType.SELF -> self = CurrencyUtils.round2(self + clean)
            }

            balancesDao.upsertBalances(
                current.copy(storeBalance = store, idleFundCash = fund, selfBalance = self)
            )

            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = System.currentTimeMillis(),
                    amount = clean,
                    sourceOrCategory = "Transfer: ${from.label.removeSuffix(" Kasası")} -> ${to.label.removeSuffix(" Kasası")}",
                    note = "${CurrencyUtils.formatTL(clean)} aktarıldı",
                    storeDelta = CurrencyUtils.round2(store - current.storeBalance),
                    fundDelta = CurrencyUtils.round2(fund - current.idleFundCash),
                    selfDelta = CurrencyUtils.round2(self - current.selfBalance),
                    type = TransactionType.TRANSFER.name
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return if (errorMsg != null) RepoResult.Error(errorMsg!!) else RepoResult.Success(Unit)
    }

    suspend fun deleteTransactionAndReverse(tx: TransactionEntity): RepoResult<Unit> {
        var errorMsg: String? = null
        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            if (tx.type == TransactionType.FUND_BUY.name && tx.linkedFundId != null) {
                val linkedFund = fundDao.getFundById(tx.linkedFundId)
                if (linkedFund != null) {
                    fundDao.deleteFundById(linkedFund.id)
                    balancesDao.upsertBalances(
                        current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash + linkedFund.investedAmount))
                    )
                    txDao.deleteById(tx.id)
                    recordCurrentFundSnapshotInternal()
                    return@withTransaction
                }
            }

            val nextStore = CurrencyUtils.round2(current.storeBalance - tx.storeDelta)
            val nextFund = CurrencyUtils.round2(current.idleFundCash - tx.fundDelta)
            val nextSelf = CurrencyUtils.round2(current.selfBalance - tx.selfDelta)

            if (nextStore < -0.001 || nextFund < -0.001 || nextSelf < -0.001) {
                errorMsg = "Bu işlem silinirse kasa bakiyesi eksiye düşer. Önce bağlı harcamayı veya fonu düzelt."
                return@withTransaction
            }

            balancesDao.upsertBalances(
                current.copy(
                    storeBalance = kotlin.math.max(0.0, nextStore),
                    idleFundCash = kotlin.math.max(0.0, nextFund),
                    selfBalance = kotlin.math.max(0.0, nextSelf)
                )
            )
            txDao.deleteById(tx.id)
            recordCurrentFundSnapshotInternal()
        }
        return if (errorMsg != null) RepoResult.Error(errorMsg!!) else RepoResult.Success(Unit)
    }

    suspend fun investInFund(
        fundType: String,
        riskLabel: String,
        amount: Double,
        monthlyReturnPercent: Double,
        purchaseDateMillis: Long
    ): RepoResult<Unit> {
        if (amount <= 0.0) return RepoResult.Error("Lütfen geçerli bir tutar gir")
        if (monthlyReturnPercent < 0.0 || monthlyReturnPercent > 20.0) {
            return RepoResult.Error("Aylık getiri beklentisi %0 ile %20 arasında olmalı")
        }

        var errorMsg: String? = null
        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            if (amount > current.idleFundCash + 0.0001) {
                errorMsg = "Boştaki fon paran yetersiz. Boştaki paran: ${CurrencyUtils.formatTL(current.idleFundCash)}"
                return@withTransaction
            }

            val clean = CurrencyUtils.round2(amount)
            val fundId = fundDao.insertFund(
                FundEntity(
                    fundType = fundType,
                    riskLabel = riskLabel,
                    investedAmount = clean,
                    monthlyReturnPercent = CurrencyUtils.round2(monthlyReturnPercent),
                    purchaseDateMillis = purchaseDateMillis
                )
            )

            balancesDao.upsertBalances(
                current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash - clean))
            )

            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = purchaseDateMillis,
                    amount = clean,
                    sourceOrCategory = "Fon Alımı: $fundType",
                    note = "Aylık beklenti ${CurrencyUtils.formatPercent(monthlyReturnPercent)}",
                    storeDelta = 0.0,
                    fundDelta = -clean,
                    selfDelta = 0.0,
                    type = TransactionType.FUND_BUY.name,
                    linkedFundId = fundId
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return if (errorMsg != null) RepoResult.Error(errorMsg!!) else RepoResult.Success(Unit)
    }

    suspend fun updateFundManualValue(fund: FundEntity, newValue: Double): RepoResult<Unit> {
        if (newValue < 0.0) return RepoResult.Error("Fon değeri negatif olamaz")
        db.withTransaction {
            fundDao.updateFund(
                fund.copy(
                    manualOverrideValue = CurrencyUtils.round2(newValue),
                    manualOverrideDateMillis = System.currentTimeMillis()
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return RepoResult.Success(Unit)
    }

    suspend fun sellFund(fund: FundEntity, currentValue: Double): RepoResult<Double> {
        val cleanProceeds = CurrencyUtils.round2(currentValue)
        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            balancesDao.upsertBalances(
                current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash + cleanProceeds))
            )
            fundDao.deleteFundById(fund.id)
            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = System.currentTimeMillis(),
                    amount = cleanProceeds,
                    sourceOrCategory = "Fon Satıldı: ${fund.fundType}",
                    note = "Yatırılan: ${CurrencyUtils.formatTL(fund.investedAmount)}",
                    storeDelta = 0.0,
                    fundDelta = cleanProceeds,
                    selfDelta = 0.0,
                    type = TransactionType.FUND_SELL.name
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        return RepoResult.Success(cleanProceeds)
    }

    suspend fun addMonthlyFundYield(lastAddedYm: String): RepoResult<Double> {
        val currentYm = CurrencyUtils.currentYearMonth()
        if (lastAddedYm == currentYm) {
            return RepoResult.Error("Bu ayın getirisi zaten eklendi. Bir sonraki ay tekrar ekleyebilirsin.")
        }

        val funds = fundDao.getAllFundsOnce()
        if (funds.isEmpty()) {
            return RepoResult.Error("Getiri hesaplamak için önce bir fon yatırımı yapmalısın.")
        }

        val now = System.currentTimeMillis()
        val totalYield = CurrencyUtils.round2(
            funds.sumOf { fund ->
                val computed = FinanceEngine.computeFundMetrics(fund, now)
                FinanceEngine.computeOneMonthYield(computed)
            }
        )

        if (totalYield <= 0.0) {
            return RepoResult.Error("Bu ay eklenecek pozitif fon getirisi bulunmuyor.")
        }

        db.withTransaction {
            val current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            balancesDao.upsertBalances(
                current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash + totalYield))
            )
            txDao.insertTransaction(
                TransactionEntity(
                    dateMillis = now,
                    amount = totalYield,
                    sourceOrCategory = "Fon Getirisi",
                    note = "$currentYm aylık fon kazancı",
                    storeDelta = 0.0,
                    fundDelta = totalYield,
                    selfDelta = 0.0,
                    type = TransactionType.FUND_YIELD.name
                )
            )
            recordCurrentFundSnapshotInternal()
        }
        prefs.setLastMonthlyYieldYm(currentYm)
        return RepoResult.Success(totalYield)
    }

    suspend fun applyAiRiskAllocation(
        mode: RiskProfileMode,
        sellExistingFirst: Boolean
    ): RepoResult<Int> = applyCustomAllocation(
        allocations = mode.allocations,
        planLabel = "AI ${mode.shortTitle} planı",
        sellExistingFirst = sellExistingFirst
    )

    suspend fun applyCustomAllocation(
        allocations: List<Pair<String, Int>>,
        planLabel: String,
        sellExistingFirst: Boolean
    ): RepoResult<Int> {
        var createdCount = 0
        var errorMsg: String? = null
        val now = System.currentTimeMillis()

        db.withTransaction {
            var current = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
            if (sellExistingFirst) {
                val existingFunds = fundDao.getAllFundsOnce()
                var proceedsSum = 0.0
                existingFunds.forEach { f ->
                    val computed = FinanceEngine.computeFundMetrics(f, now)
                    proceedsSum += computed.currentValue
                    txDao.insertTransaction(
                        TransactionEntity(
                            dateMillis = now,
                            amount = computed.currentValue,
                            sourceOrCategory = "Fon Satıldı: ${f.fundType}",
                            note = "AI kâr planı değişimi",
                            storeDelta = 0.0,
                            fundDelta = computed.currentValue,
                            selfDelta = 0.0,
                            type = TransactionType.FUND_SELL.name
                        )
                    )
                }
                fundDao.deleteAllFunds()
                current = current.copy(idleFundCash = CurrencyUtils.round2(current.idleFundCash + proceedsSum))
                balancesDao.upsertBalances(current)
            }

            val available = CurrencyUtils.round2(current.idleFundCash)
            if (available <= 0.0) {
                errorMsg = "Boştaki fon paran 0,00 TL. Önce Fon Kasana para ekle."
                return@withTransaction
            }

            var remainingCash = available
            allocations.forEachIndexed { index, (fundName, pct) ->
                val amount = if (index == allocations.lastIndex) {
                    CurrencyUtils.round2(remainingCash)
                } else {
                    CurrencyUtils.round2(available * (pct / 100.0))
                }
                if (amount > 0.0) {
                    remainingCash = CurrencyUtils.round2(remainingCash - amount)
                    val spec = AVAILABLE_FUND_OPTIONS.firstOrNull { it.name == fundName }
                        ?: AVAILABLE_FUND_OPTIONS.first()
                    val fundId = fundDao.insertFund(
                        FundEntity(
                            fundType = spec.name,
                            riskLabel = spec.riskLabel,
                            investedAmount = amount,
                            monthlyReturnPercent = spec.defaultMonthlyReturnPercent,
                            purchaseDateMillis = now
                        )
                    )
                    txDao.insertTransaction(
                        TransactionEntity(
                            dateMillis = now,
                            amount = amount,
                            sourceOrCategory = "Fon Alımı: ${spec.name}",
                            note = "$planLabel (%$pct)",
                            storeDelta = 0.0,
                            fundDelta = -amount,
                            selfDelta = 0.0,
                            type = TransactionType.FUND_BUY.name,
                            linkedFundId = fundId
                        )
                    )
                    createdCount++
                }
            }

            balancesDao.upsertBalances(current.copy(idleFundCash = kotlin.math.max(0.0, remainingCash)))
            recordCurrentFundSnapshotInternal()
        }

        return if (errorMsg != null) RepoResult.Error(errorMsg!!) else RepoResult.Success(createdCount)
    }

    suspend fun addMarketTag(rawTag: String): RepoResult<Unit> {
        val cleaned = rawTag.trim()
        if (cleaned.isEmpty()) return RepoResult.Error("Lütfen bir etiket yaz (Örn: #altın)")
        val normalized = if (cleaned.startsWith("#")) cleaned else "#$cleaned"
        marketDao.insertTag(MarketTagEntity(tagName = normalized))
        return RepoResult.Success(Unit)
    }

    suspend fun deleteMarketTag(tagId: Long) = marketDao.deleteTagById(tagId)

    suspend fun addTagPrice(tagId: Long, price: Double): RepoResult<Unit> {
        if (price <= 0.0) return RepoResult.Error("Geçerli bir fiyat gir")
        marketDao.insertTagPrice(
            TagPriceEntity(
                tagId = tagId,
                dateMillis = System.currentTimeMillis(),
                price = CurrencyUtils.round2(price)
            )
        )
        return RepoResult.Success(Unit)
    }

    suspend fun addMarketNote(content: String): RepoResult<Unit> {
        val cleaned = content.trim()
        if (cleaned.isEmpty()) return RepoResult.Error("Not metni boş olamaz")
        marketDao.insertNote(
            MarketNoteEntity(
                dateMillis = System.currentTimeMillis(),
                content = cleaned
            )
        )
        return RepoResult.Success(Unit)
    }

    suspend fun deleteMarketNote(noteId: Long) = marketDao.deleteNoteById(noteId)

    suspend fun clearAllData() {
        db.clearAllTables()
        prefs.clearAll()
    }

    private suspend fun recordCurrentFundSnapshotInternal() {
        val now = System.currentTimeMillis()
        val balances = balancesDao.getBalancesOnce() ?: VaultBalancesEntity()
        val funds = fundDao.getAllFundsOnce()
        val locked = funds.sumOf { FinanceEngine.computeFundMetrics(it, now).currentValue }
        val totalFund = CurrencyUtils.round2(balances.idleFundCash + locked)
        fundDao.upsertSnapshot(
            FundSnapshotEntity(
                epochDay = CurrencyUtils.currentEpochDay(now),
                totalFundValue = totalFund
            )
        )
    }
}
