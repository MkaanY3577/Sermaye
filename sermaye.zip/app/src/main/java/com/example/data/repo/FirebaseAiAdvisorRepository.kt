package com.example.data.repo

import android.util.Log
import com.example.data.local.UserProfile
import com.example.domain.AiProfitPlan
import com.example.domain.AssetStatisticalForecast
import com.example.domain.PortfolioSummary
import com.example.domain.RiskProfileMode
import com.example.util.CurrencyUtils
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val AI_TAG = "SermayeGeminiAdvisor"

sealed interface AiCommentaryState {
    data object Idle : AiCommentaryState
    data object Loading : AiCommentaryState
    data class Streaming(val text: String) : AiCommentaryState
    data class Success(val text: String) : AiCommentaryState
    data class Error(val message: String) : AiCommentaryState
}

class FirebaseAiAdvisorRepository {

    // Lazily initialize Firebase.ai so FirebaseApp / App Check are guaranteed ready first
    private val model by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.8-flash")
    }

    fun streamPersonalizedAdvice(
        profile: UserProfile,
        summary: PortfolioSummary,
        selectedRisk: RiskProfileMode,
        profitPlan: AiProfitPlan,
        liveSnapshot: LiveMarketSnapshot?,
        news: List<MarketNewsItem>
    ): Flow<AiCommentaryState> = flow {
        emit(AiCommentaryState.Loading)

        val fundsBreakdown = if (summary.computedFunds.isEmpty()) {
            "Aktif fon yok."
        } else {
            summary.computedFunds.joinToString("\n") { f ->
                "- ${f.entity.fundType} (${f.entity.riskLabel}): Yatırılan ${CurrencyUtils.formatTL(f.entity.investedAmount)}, " +
                    "Güncel ${CurrencyUtils.formatTL(f.currentValue)}, Kar/Zarar ${CurrencyUtils.formatSignedTL(f.profitTL)} " +
                    "(${CurrencyUtils.formatSignedPercent(f.profitPercent)}), Geçen süre: ${f.monthsElapsedFromPurchase} ay"
            }
        }

        val goalInfo = if (profile.storeTargetAmount > 0.0) {
            val remaining = (profile.storeTargetAmount - summary.storeBalance).coerceAtLeast(0.0)
            "Mağaza Hedefi: ${CurrencyUtils.formatTL(profile.storeTargetAmount)}, " +
                "Kalan: ${CurrencyUtils.formatTL(remaining)}, " +
                "Tahmini Kalan Ay: ${summary.aiAdvice.monthsToStoreGoal?.let { "%.1f".format(it) } ?: "Belirsiz"}"
        } else {
            "Mağaza Hedefi: Belirtilmedi"
        }

        val marketContext = if (liveSnapshot == null) {
            "Canlı piyasa fiyatı henüz çekilmedi."
        } else {
            val assets = liveSnapshot.assets.joinToString(", ") { a ->
                val chg = a.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
                "${a.name}: ${CurrencyUtils.formatTL(a.price)}$chg"
            }
            val funds = liveSnapshot.topFunds.joinToString(", ") { f ->
                val chg = f.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
                "${f.symbol}: ${"%.2f".format(f.price)} ${f.currency}$chg"
            }
            "Canlı Fiyatlar: $assets | Büyük Fonlar: $funds"
        }

        val newsImpactContext = if (news.isEmpty()) {
            "Güncel haber sinyali henüz yüklenmedi."
        } else {
            news.take(5).joinToString("\n") { item ->
                "- ${item.title} -> [${item.fundImpact.direction.label}: ${item.fundImpact.affectedFunds.joinToString(", ")}]"
            }
        }

        val planLine = profitPlan.smartAllocations.joinToString(", ") { (name, pct) -> "$name %$pct" }

        val prompt = """
            Sen "SERMAYE" uygulamasının kâr odaklı, ciddi, net ve tamamen gerçek rakamlara dayanan finansal stratejistisin.
            Amacın kullanıcının parasını boşta bekletmeden, zarar eden fonlardan kurtarıp kâr potansiyeli en yüksek yasal fon dağılımına yönlendirmek.
            KESİN KURAL: Aşağıdaki gerçek veriler dışında HİÇBİR rakam, tarih, fiyat veya fon adı uydurma!
            Eğer kullanıcının toplam serveti 0 TL ise yalnızca para eklemesi gerektiğini ve neden fonun önemli olduğunu kısaca söyle.

            KULLANICI PORTFÖYÜ VE KÂR HESABI:
            - İsim: ${profile.userName.ifBlank { "Kullanıcı" }}
            - Toplam Servet: ${CurrencyUtils.formatTL(summary.totalWealth)}
            - Mağaza Kasası: ${CurrencyUtils.formatTL(summary.storeBalance)}
            - Fon Kasası Toplam: ${CurrencyUtils.formatTL(summary.totalFundVault)} (Boşta Bekleyen: ${CurrencyUtils.formatTL(summary.idleFundCash)}, Fonda Kilitli: ${CurrencyUtils.formatTL(summary.lockedFundValue)})
            - Boştaki Paranın Aylık Fırsat Kaybı: ${CurrencyUtils.formatTL(profitPlan.idleCashOpportunityMonthlyTL)}/ay
            - Mevcut Aylık Beklenen Fon Getirisi: ${CurrencyUtils.formatTL(profitPlan.currentMonthlyProfitTL)}/ay
            - Önerilen Akıllı Plan (${profitPlan.strategyTitle}): $planLine
            - Önerilen Plan Aylık Getirisi: ${CurrencyUtils.formatTL(profitPlan.projectedMonthlyProfitTL)}/ay (Aylık Artış: +${CurrencyUtils.formatTL(profitPlan.monthlyProfitBoostTL)}, 12 Ay Bileşik Fark: +${CurrencyUtils.formatTL(profitPlan.yearlyCompoundBoostTL)})
            - $goalInfo
            - Aktif Fonlar:
            $fundsBreakdown

            CANLI PİYASA VE HABER SİNYALLERİ:
            $marketContext
            $newsImpactContext

            Kullanıcıya doğrudan uygulanabilir 4 kısa, net, kâr odaklı madde yaz:
            1) Boştaki para / aylık kâr artışı için tam TL hamlesi
            2) Mevcut fonlarda kâr realizasyonu veya zayıf fon değişimi
            3) Canlı piyasa ve haber yönüne göre öne çıkan / kaçınılacak fonlar
            4) Mağaza hedefi için likidite ve risk kuralı
            Yasal uyarı ekleme (ekranda zaten gösteriliyor).
        """.trimIndent()

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        accumulated.append(chunkText)
                        emit(AiCommentaryState.Streaming(accumulated.toString()))
                    }
                }
            }
            if (accumulated.isNotBlank()) {
                emit(AiCommentaryState.Success(accumulated.toString()))
            } else {
                emit(AiCommentaryState.Error("Gemini boş yanıt döndürdü. Lütfen tekrar dene."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(AI_TAG, "Gemini streaming timed out", e)
            emit(AiCommentaryState.Error("Bağlantı 60 saniye içinde yanıt vermedi. İnternetini kontrol edip tekrar dene."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(AI_TAG, "Gemini AI call failed", e)
            emit(
                AiCommentaryState.Error(
                    e.localizedMessage ?: "Canlı Gemini AI bağlantısı kurulamadı. Yukarıdaki kâr planı çevrimdışı geçerlidir."
                )
            )
        }
    }

    fun streamMarketAgendaSummary(
        snapshot: LiveMarketSnapshot?,
        news: List<MarketNewsItem>,
        signals: List<FundMarketSignal>,
        summary: PortfolioSummary?
    ): Flow<AiCommentaryState> = flow {
        emit(AiCommentaryState.Loading)

        val priceBlock = if (snapshot == null || (snapshot.assets.isEmpty() && snapshot.topFunds.isEmpty())) {
            "Canlı fiyat verisi henüz alınamadı."
        } else {
            val assetsTxt = snapshot.assets.joinToString("\n") { a ->
                val chg = a.changePercent24h?.let { " (24s: ${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
                "- ${a.name}: ${CurrencyUtils.formatTL(a.price)}$chg"
            }
            val fundsTxt = snapshot.topFunds.joinToString("\n") { f ->
                val chg = f.changePercent24h?.let { " (Günlük: ${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
                "- ${f.symbol} (${f.name}): ${"%.2f".format(f.price)} ${f.currency}$chg"
            }
            "PİYASA FİYATLARI:\n$assetsTxt\n\nEN BÜYÜK FONLAR:\n$fundsTxt"
        }

        val newsBlock = if (news.isEmpty()) {
            "Güncel haber başlığı bulunamadı."
        } else {
            news.take(8).joinToString("\n") { item ->
                val summarySnippet = if (item.summary.isNotBlank()) " — ${item.summary.take(120)}" else ""
                "- ${item.title} (${item.source})$summarySnippet | Tahmini Fon Etkisi: ${item.fundImpact.affectedFunds.joinToString(", ")} (${item.fundImpact.direction.label})"
            }
        }

        val signalBlock = if (signals.isEmpty()) {
            "Sinyal hesaplanmadı."
        } else {
            signals.joinToString(", ") { s ->
                "${s.fundName}: +${s.positiveCount} / -${s.negativeCount} (Net ${s.netScore})"
            }
        }

        val portfolioNote = if (summary != null && summary.totalFundVault > 0.0) {
            "KULLANICI FON KASASI: Toplam ${CurrencyUtils.formatTL(summary.totalFundVault)} (Boşta ${CurrencyUtils.formatTL(summary.idleFundCash)}, Kilitli ${CurrencyUtils.formatTL(summary.lockedFundValue)})."
        } else {
            "Kullanıcı fon kasası henüz boş veya başlangıç aşamasında."
        }

        val prompt = """
            Sen SERMAYE uygulamasının canlı piyasa ve fon kâr stratejistisin.
            Aşağıdaki GERÇEK canlı fiyatları, güncel ekonomi haberlerini ve kullanıcının kasa durumunu kullanarak sade ve net Türkçe ile 4 kısa maddede özet ver:
            1) Altın, Döviz ve Bitcoin ne yönde hareket ediyor?
            2) Bugünkü haberlerin fonlara net etkisi nedir? (Hangi fonlara YÜKSELİŞ ▲ desteği var, hangilerinde DÜŞÜŞ ▼ / oynaklık baskısı var?)
            3) En büyük piyasa fonları (GLD, SPY, QQQ, IBIT, BIST) nasıl bir sinyal veriyor?
            4) Kâr odaklı net öneri: Kullanıcının fon kasası için bugünkü gündeme göre hangi fona ağırlık verip nereden uzak durması daha kârlı olur?

            KESİN KURAL: Aşağıdaki verilerde olmayan hiçbir fiyat, oran veya haber uydurma!

            $priceBlock

            FON SİNYAL ÖZETİ:
            $signalBlock

            GÜNCEL HABERLER VE ETKİLERİ:
            $newsBlock

            $portfolioNote
        """.trimIndent()

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        accumulated.append(chunkText)
                        emit(AiCommentaryState.Streaming(accumulated.toString()))
                    }
                }
            }
            if (accumulated.isNotBlank()) {
                emit(AiCommentaryState.Success(accumulated.toString()))
            } else {
                emit(AiCommentaryState.Error("Gemini boş gündem özeti döndürdü."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(AI_TAG, "Market agenda Gemini streaming timed out", e)
            emit(AiCommentaryState.Error("Gündem özeti zaman aşımına uğradı. Tekrar dene."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(AI_TAG, "Market agenda Gemini call failed", e)
            emit(AiCommentaryState.Error(e.localizedMessage ?: "Gündem özeti alınamadı."))
        }
    }

    fun streamAssetForecast(
        assetName: String,
        symbol: String,
        category: String,
        currentPrice: Double,
        currency: String,
        change24hPercent: Double?,
        statForecast: AssetStatisticalForecast,
        relevantNews: List<MarketNewsItem>,
        userHoldingSummary: String? = null
    ): Flow<AiCommentaryState> = flow {
        emit(AiCommentaryState.Loading)

        val currentPriceStr = CurrencyUtils.formatMoneyByCurrency(currentPrice, currency)
        val chg24Str = change24hPercent?.let { CurrencyUtils.formatSignedPercent(it) } ?: "Veri yok"
        val h1m = statForecast.change1MPercent?.let { CurrencyUtils.formatSignedPercent(it) } ?: "Veri yok"
        val h6m = statForecast.change6MPercent?.let { CurrencyUtils.formatSignedPercent(it) } ?: "Veri yok"
        val h12m = statForecast.change12MPercent?.let { CurrencyUtils.formatSignedPercent(it) } ?: "Veri yok"

        val bandsText = statForecast.horizons.joinToString("\n") { h ->
            "- ${h.horizonLabel}: Baz Tahmin ${CurrencyUtils.formatSignedPercent(h.projectedChangePercent)} " +
                "(~${CurrencyUtils.formatMoneyByCurrency(h.projectedPrice, currency)}), " +
                "Alt-Üst Bant: ${CurrencyUtils.formatSignedPercent(h.conservativePercent)} / ${CurrencyUtils.formatSignedPercent(h.optimisticPercent)}"
        }

        val newsText = if (relevantNews.isEmpty()) {
            "Bu varlıkla doğrudan ilişkili ek haber bulunmadı."
        } else {
            relevantNews.take(4).joinToString("\n") { n ->
                "- ${n.title} (${n.source}) -> Etki: ${n.fundImpact.direction.label}"
            }
        }

        val holdingText = if (userHoldingSummary.isNullOrBlank()) {
            "Kullanıcı şu an kataloğu inceliyor."
        } else {
            "KULLANICININ ELİNDEKİ POZİSYON: $userHoldingSummary"
        }

        val prompt = """
            Sen SERMAYE uygulamasının kantitatif fon ve altın analiz uzmanısın.
            Kullanıcı "$assetName" ($symbol • $category) varlığına tıkladı ve 1 aylık, 6 aylık, 12 aylık gelecek tahmini istiyor.
            KESİN KURAL: Sadece aşağıdaki GERÇEK piyasa verilerine, gerçekleşmiş tarihsel performansa ve baz istatistik bantlarına dayan. Olmayan fiyat veya uydurma veri ekleme!

            CANLI DURUM:
            - Anlık Fiyat: $currentPriceStr (Günlük/24s Değişim: $chg24Str)
            - Gerçekleşmiş Tarihsel Değişim: 1 Ay $h1m | 6 Ay $h6m | 12 Ay $h12m
            - Aylık Ortalama Trend Hızı: ${CurrencyUtils.formatSignedPercent(statForecast.realizedMonthlyDriftPercent)} • Aylık Oynaklık (Risk): %${statForecast.monthlyVolatilityPercent}
            - Sinyal: ${statForecast.trendSignal}
            - $holdingText

            İSTATİSTİKSEL PROJEKSİYON BANTLARI:
            $bandsText

            İLGİLİ GÜNCEL HABERLER:
            $newsText

            Şu 4 net başlıkla kısa, anlaşılır Türkçe tahmin ve strateji yaz:
            • 1 Aylık Tahmin (% ve fiyat yönü, kısa vadeli tetikleyici)
            • 6 Aylık Tahmin (orta vade trendi ve haber/makro etkisi)
            • 12 Aylık Tahmin (uzun vade bileşik/değer beklentisi ve alt-üst senaryo)
            • Kâr & Risk Önerisi (kademeli alım, tut veya kâr al stratejisi)
        """.trimIndent()

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(prompt).collect { chunk ->
                    val chunkText = chunk.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        accumulated.append(chunkText)
                        emit(AiCommentaryState.Streaming(accumulated.toString()))
                    }
                }
            }
            if (accumulated.isNotBlank()) {
                emit(AiCommentaryState.Success(accumulated.toString()))
            } else {
                emit(AiCommentaryState.Error("AI tahmin yanıtı boş döndü. Sayısal bantları yukarıdan inceleyebilirsin."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(AI_TAG, "Asset forecast Gemini streaming timed out", e)
            emit(AiCommentaryState.Error("AI tahmini zaman aşımına uğradı. Lütfen tekrar dene."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(AI_TAG, "Asset forecast Gemini call failed", e)
            emit(AiCommentaryState.Error(e.localizedMessage ?: "Canlı AI tahmini şu an alınamadı; yukarıdaki istatistiksel 1A/6A/12A tahminler aktiftir."))
        }
    }
}
