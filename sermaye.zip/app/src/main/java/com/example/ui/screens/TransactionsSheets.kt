package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.VaultType
import com.example.ui.SermayeUiState
import com.example.ui.components.AutoBalanceSplitSliders
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.DatePickerSelectorRow
import com.example.ui.components.HomeSectionCursor
import com.example.ui.components.SermayeHomeTopCursorBar
import com.example.ui.components.SermayeTextField
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddIncomeBottomSheet(
    uiState: SermayeUiState,
    onDismiss: () -> Unit,
    onSubmit: (
        amount: Double,
        source: String,
        note: String,
        dateMillis: Long,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int
    ) -> Unit
) {
    val colors = LocalSermayeColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var amountInput by remember { mutableStateOf("") }
    var selectedSource by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var dateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var storeRatio by remember { mutableIntStateOf(uiState.profile.storeRatio) }
    var fundRatio by remember { mutableIntStateOf(uiState.profile.fundRatio) }
    var selfRatio by remember { mutableIntStateOf(uiState.profile.selfRatio) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val parsedAmount = CurrencyUtils.parsePositiveOrZero(amountInput) ?: 0.0
    val sources = listOf("Maaş", "Mağaza Satışı", "Ek İş", "Kira / Temettü", "Prim", "Diğer")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.cardBackground,
        scrimColor = colors.textPrimary.copy(alpha = 0.65f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Para Ekle",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Kapat",
                        tint = colors.textPrimary
                    )
                }
            }

            SermayeTextField(
                value = amountInput,
                onValueChange = {
                    amountInput = it
                    errorMsg = null
                },
                label = "TUTAR",
                placeholder = "0",
                isNumeric = true,
                suffixText = "TL",
                testTag = "add_income_amount_input"
            )
            if (parsedAmount > 0.0) {
                Text(
                    text = "Biçimlendirilmiş Tutar: ${CurrencyUtils.formatTL(parsedAmount)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.selfGreen
                )
            }

            Text(
                text = "NEREDEN GELDİ?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sources.forEach { src ->
                    val selected = selectedSource == src
                    OutlinedButton(
                        onClick = {
                            selectedSource = src
                            errorMsg = null
                        },
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                        )
                    ) {
                        Text(
                            text = src,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            SermayeTextField(
                value = noteInput,
                onValueChange = { noteInput = it },
                label = "AÇIKLAMA (Maks 50 karakter)",
                placeholder = "Örn: Kasım maaşı",
                maxLength = 50,
                testTag = "add_income_note_input"
            )

            DatePickerSelectorRow(
                label = "TARİH",
                selectedDateMillis = dateMillis,
                onDateSelected = { if (it != null) dateMillis = it }
            )

            Text(
                text = "Nasıl Bölüştürelim?",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            AutoBalanceSplitSliders(
                storeRatio = storeRatio,
                fundRatio = fundRatio,
                selfRatio = selfRatio,
                previewAmount = parsedAmount,
                onRatiosChanged = { s, f, k ->
                    storeRatio = s
                    fundRatio = f
                    selfRatio = k
                }
            )

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.alertRed
                )
            }

            CrispSolidButton(
                text = "EKLE - ${CurrencyUtils.formatTL(parsedAmount)}",
                containerColor = colors.selfGreen,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth(),
                testTag = "add_income_submit_button",
                onClick = {
                    when {
                        parsedAmount <= 0.0 -> errorMsg = "Lütfen tutar gir"
                        selectedSource.isBlank() -> errorMsg = "Kaynak seç"
                        else -> onSubmit(
                            parsedAmount,
                            selectedSource,
                            noteInput,
                            dateMillis,
                            storeRatio,
                            fundRatio,
                            selfRatio
                        )
                    }
                }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WithdrawBottomSheet(
    uiState: SermayeUiState,
    onDismiss: () -> Unit,
    onSubmit: (
        vault: VaultType,
        amount: Double,
        category: String,
        note: String,
        dateMillis: Long
    ) -> Unit
) {
    val colors = LocalSermayeColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val summary = uiState.summary

    var selectedVault by remember { mutableStateOf(VaultType.STORE) }
    var amountInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var dateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val parsedAmount = CurrencyUtils.parsePositiveOrZero(amountInput) ?: 0.0
    val categories = listOf(
        "Mal Alımı",
        "Kira",
        "Fatura & Aidat",
        "Market & Gıda",
        "Ulaşım",
        "Vergi & SGK",
        "Kendine Harcama",
        "Diğer"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.cardBackground,
        scrimColor = colors.textPrimary.copy(alpha = 0.65f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Para Çıkar",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Kapat", tint = colors.textPrimary)
                }
            }

            Text(
                text = "HANGİ KASADAN?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultType.entries.forEach { vault ->
                    val available = when (vault) {
                        VaultType.STORE -> summary.storeBalance
                        VaultType.FUND -> summary.idleFundCash
                        VaultType.SELF -> summary.selfBalance
                    }
                    val vaultSuffix = if (vault == VaultType.FUND) " (Boşta)" else ""
                    val selected = selectedVault == vault
                    OutlinedButton(
                        onClick = {
                            selectedVault = vault
                            errorMsg = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                        )
                    ) {
                        Text(
                            text = "${vault.label}$vaultSuffix - ${CurrencyUtils.formatTL(available)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            SermayeTextField(
                value = amountInput,
                onValueChange = {
                    amountInput = it
                    errorMsg = null
                },
                label = "NE KADAR?",
                placeholder = "0",
                isNumeric = true,
                suffixText = "TL",
                testTag = "withdraw_amount_input"
            )

            Text(
                text = "NE İÇİN?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val selected = selectedCategory == cat
                    OutlinedButton(
                        onClick = {
                            selectedCategory = cat
                            errorMsg = null
                        },
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                        )
                    ) {
                        Text(text = cat, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            SermayeTextField(
                value = noteInput,
                onValueChange = { noteInput = it },
                label = "AÇIKLAMA (İsteğe bağlı)",
                placeholder = "Örn: Kumaş tedariki",
                maxLength = 50,
                testTag = "withdraw_note_input"
            )

            DatePickerSelectorRow(
                label = "TARİH",
                selectedDateMillis = dateMillis,
                onDateSelected = { if (it != null) dateMillis = it }
            )

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.alertRed
                )
            }

            CrispSolidButton(
                text = "ÇIKAR - ${CurrencyUtils.formatTL(parsedAmount)}",
                containerColor = colors.alertRed,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth(),
                testTag = "withdraw_submit_button",
                onClick = {
                    val available = when (selectedVault) {
                        VaultType.STORE -> summary.storeBalance
                        VaultType.FUND -> summary.idleFundCash
                        VaultType.SELF -> summary.selfBalance
                    }
                    when {
                        parsedAmount <= 0.0 -> errorMsg = "Lütfen tutar gir"
                        selectedCategory.isBlank() -> errorMsg = "Harcama türü seç"
                        parsedAmount > available + 0.0001 -> {
                            errorMsg = "Bu kasada yeterli para yok. Kasan: ${CurrencyUtils.formatTL(available)}, " +
                                "çıkarmak istediğin: ${CurrencyUtils.formatTL(parsedAmount)}"
                        }
                        else -> onSubmit(
                            selectedVault,
                            parsedAmount,
                            selectedCategory,
                            noteInput,
                            dateMillis
                        )
                    }
                }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferBottomSheet(
    uiState: SermayeUiState,
    onDismiss: () -> Unit,
    onSubmit: (from: VaultType, to: VaultType, amount: Double) -> Unit
) {
    val colors = LocalSermayeColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val summary = uiState.summary

    var fromVault by remember { mutableStateOf(VaultType.STORE) }
    var toVault by remember { mutableStateOf(VaultType.FUND) }
    var amountInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val parsedAmount = CurrencyUtils.parsePositiveOrZero(amountInput) ?: 0.0

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.cardBackground,
        scrimColor = colors.textPrimary.copy(alpha = 0.65f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kasalar Arası Transfer",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Kapat", tint = colors.textPrimary)
                }
            }

            Text("NEREDEN?", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultType.entries.forEach { vault ->
                    val available = when (vault) {
                        VaultType.STORE -> summary.storeBalance
                        VaultType.FUND -> summary.idleFundCash
                        VaultType.SELF -> summary.selfBalance
                    }
                    val selected = fromVault == vault
                    OutlinedButton(
                        onClick = {
                            fromVault = vault
                            errorMsg = null
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                        )
                    ) {
                        Text("${vault.label} (${CurrencyUtils.formatTL(available)})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text("NEREYE?", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultType.entries.forEach { vault ->
                    val available = when (vault) {
                        VaultType.STORE -> summary.storeBalance
                        VaultType.FUND -> summary.idleFundCash
                        VaultType.SELF -> summary.selfBalance
                    }
                    val selected = toVault == vault
                    OutlinedButton(
                        onClick = {
                            toVault = vault
                            errorMsg = null
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                        )
                    ) {
                        Text("${vault.label} (${CurrencyUtils.formatTL(available)})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            SermayeTextField(
                value = amountInput,
                onValueChange = {
                    amountInput = it
                    errorMsg = null
                },
                label = "NE KADAR?",
                placeholder = "0",
                isNumeric = true,
                suffixText = "TL",
                testTag = "transfer_amount_input"
            )

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.alertRed
                )
            }

            CrispSolidButton(
                text = "TRANSFER ET",
                containerColor = colors.storeBlue,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth(),
                testTag = "transfer_submit_button",
                onClick = {
                    val available = when (fromVault) {
                        VaultType.STORE -> summary.storeBalance
                        VaultType.FUND -> summary.idleFundCash
                        VaultType.SELF -> summary.selfBalance
                    }
                    when {
                        fromVault == toVault -> errorMsg = "Aynı kasaya transfer olmaz"
                        parsedAmount <= 0.0 -> errorMsg = "Lütfen tutar gir"
                        parsedAmount > available + 0.0001 -> {
                            errorMsg = "Bu kasada yeterli para yok. Kasan: ${CurrencyUtils.formatTL(available)}"
                        }
                        else -> onSubmit(fromVault, toVault, parsedAmount)
                    }
                }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

enum class TxFilterOption(val label: String) {
    ALL("Tümü"),
    INPUT("Sadece Girdi"),
    EXPENSE("Sadece Çıktı"),
    TRANSFER("Sadece Transfer")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AllTransactionsScreen(
    transactions: List<TransactionEntity>,
    monthNetCashflow: Double = 0.0,
    onBack: () -> Unit,
    onOpenIncomeExpense: () -> Unit = {},
    onDeleteTransaction: (TransactionEntity) -> Unit
) {
    val colors = LocalSermayeColors.current
    var searchQuery by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(TxFilterOption.ALL) }
    var txToDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    BackHandler(onBack = onBack)

    val filtered = remember(transactions, searchQuery, filter) {
        transactions.filter { tx ->
            val matchesFilter = when (filter) {
                TxFilterOption.ALL -> true
                TxFilterOption.INPUT -> tx.type == TransactionType.INPUT.name || tx.type == TransactionType.FUND_YIELD.name || tx.type == TransactionType.FUND_SELL.name
                TxFilterOption.EXPENSE -> tx.type == TransactionType.EXPENSE.name || tx.type == TransactionType.FUND_BUY.name
                TxFilterOption.TRANSFER -> tx.type == TransactionType.TRANSFER.name
            }
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                tx.note.lowercase().contains(q) ||
                tx.sourceOrCategory.lowercase().contains(q)
            matchesFilter && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Geri",
                    tint = colors.textPrimary
                )
            }
            Text(
                text = "Tüm İşlemler",
                fontFamily = PoppinsFontFamily,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
        SermayeHomeTopCursorBar(
            active = HomeSectionCursor.ALL_TRANSACTIONS,
            monthNetCashflow = monthNetCashflow,
            onSelectHome = onBack,
            onSelectIncomeExpense = onOpenIncomeExpense,
            onSelectAllTransactions = {},
            modifier = Modifier.widthIn(max = 600.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SermayeTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = "İşlemlerde Ara",
                    placeholder = "Açıklama veya kaynak yaz...",
                    testTag = "all_tx_search_input"
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TxFilterOption.entries.forEach { option ->
                        val selected = filter == option
                        OutlinedButton(
                            onClick = { filter = option },
                            modifier = Modifier.height(48.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                                contentColor = if (selected) colors.cardBackground else colors.textPrimary
                            )
                        ) {
                            Text(option.label, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Aradığın kritere uygun işlem bulunamadı.",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        } else {
            items(filtered, key = { it.id }) { tx ->
                TransactionRowCard(
                    tx = tx,
                    onRequestDelete = { txToDelete = tx },
                    modifier = Modifier.widthIn(max = 600.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (txToDelete != null) {
        val target = txToDelete!!
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            containerColor = colors.cardBackground,
            title = {
                Text("İşlemi Sil", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
            },
            text = {
                Text(
                    "Bu işlemi silmek istiyor musun? Kasan geri düzeltilecek.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransaction(target)
                        txToDelete = null
                    }
                ) {
                    Text("Evet, Sil", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { txToDelete = null }) {
                    Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                }
            }
        )
    }
}
