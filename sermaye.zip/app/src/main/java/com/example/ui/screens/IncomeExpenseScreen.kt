package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.domain.CashflowCategoryStat
import com.example.domain.CashflowPeriod
import com.example.domain.FinanceEngine
import com.example.ui.components.CrispCashflowBarChart
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.HomeSectionCursor
import com.example.ui.components.SermayeHomeTopCursorBar
import com.example.ui.components.SermayeTextField
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils

private enum class CashflowLedgerFilter(val label: String) {
    ALL("Tümü"),
    INCOME("Gelirler"),
    EXPENSE("Giderler"),
    TRANSFER("Transferler")
}

private enum class CategoryTab(val label: String) {
    EXPENSE("Gider Kategorileri"),
    INCOME("Gelir Kaynakları")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun IncomeExpenseScreen(
    transactions: List<TransactionEntity>,
    monthNetCashflow: Double = 0.0,
    onBack: () -> Unit,
    onOpenAllTransactions: () -> Unit = {},
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit
) {
    val colors = LocalSermayeColors.current
    var selectedPeriod by remember { mutableStateOf(CashflowPeriod.THIS_MONTH) }
    var selectedCategoryTab by remember { mutableStateOf(CategoryTab.EXPENSE) }
    var ledgerFilter by remember { mutableStateOf(CashflowLedgerFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var txToDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    BackHandler(onBack = onBack)

    val report = remember(transactions, selectedPeriod) {
        FinanceEngine.buildIncomeExpenseReport(
            transactions = transactions,
            period = selectedPeriod
        )
    }

    val filteredTransactions = remember(report.periodTransactions, ledgerFilter, searchQuery) {
        val q = searchQuery.trim().lowercase()
        report.periodTransactions.filter { tx ->
            val matchesType = when (ledgerFilter) {
                CashflowLedgerFilter.ALL -> true
                CashflowLedgerFilter.INCOME -> tx.type == TransactionType.INPUT.name ||
                    tx.type == TransactionType.FUND_YIELD.name ||
                    tx.type == TransactionType.FUND_SELL.name
                CashflowLedgerFilter.EXPENSE -> tx.type == TransactionType.EXPENSE.name ||
                    tx.type == TransactionType.FUND_BUY.name
                CashflowLedgerFilter.TRANSFER -> tx.type == TransactionType.TRANSFER.name
            }
            val matchesQuery = q.isEmpty() ||
                tx.sourceOrCategory.lowercase().contains(q) ||
                tx.note.lowercase().contains(q)
            matchesType && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. SABİT ÜST BAR + İMLEÇ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("ie_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Geri",
                        tint = colors.textPrimary
                    )
                }
                Text(
                    text = "Gelir & Gider",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                modifier = Modifier
                    .background(colors.summaryBg, RoundedCornerShape(8.dp))
                    .border(1.dp, colors.summaryBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = selectedPeriod.label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.summaryText
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        SermayeHomeTopCursorBar(
            active = HomeSectionCursor.INCOME_EXPENSE,
            monthNetCashflow = monthNetCashflow,
            onSelectHome = onBack,
            onSelectIncomeExpense = {},
            onSelectAllTransactions = onOpenAllTransactions,
            modifier = Modifier.widthIn(max = 600.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

        // 2. DÖNEM SEÇİCİ
        item(key = "ie_period_chips", contentType = "periods") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CashflowPeriod.entries.forEach { period ->
                    val selected = selectedPeriod == period
                    OutlinedButton(
                        onClick = { selectedPeriod = period },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("ie_period_${period.name}"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (selected) colors.storeBlue else colors.borderColor),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selected) colors.storeBlue else colors.cardBackground,
                            contentColor = if (selected) PureWhite else colors.textPrimary
                        )
                    ) {
                        Text(
                            text = period.label,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 3. NAKİT AKIŞI ÖZET KARTI + HIZLI EKLEME BUTONLARI
        item(key = "ie_summary_card", contentType = "summary") {
            val netColor = when {
                report.netCashflow > 0.0 -> colors.selfGreen
                report.netCashflow < 0.0 -> colors.alertRed
                else -> colors.storeBlue
            }

            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Nakit Akışı Özeti",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    if (report.totalIncome > 0.0) {
                        Box(
                            modifier = Modifier
                                .background(netColor, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Tasarruf ${CurrencyUtils.formatPercent(report.savingsRatePercent)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val isWide = maxWidth >= 460.dp
                    if (isWide) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CashflowMetricTile(
                                title = "TOPLAM GELİR (${report.incomeCount})",
                                valueText = "+${CurrencyUtils.formatTL(report.totalIncome)}",
                                accent = colors.selfGreen,
                                icon = Icons.AutoMirrored.Filled.TrendingUp,
                                modifier = Modifier.weight(1f)
                            )
                            CashflowMetricTile(
                                title = "TOPLAM GİDER (${report.expenseCount})",
                                valueText = "-${CurrencyUtils.formatTL(report.totalExpense)}",
                                accent = colors.alertRed,
                                icon = Icons.AutoMirrored.Filled.TrendingDown,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            CashflowMetricTile(
                                title = "TOPLAM GELİR (${report.incomeCount})",
                                valueText = "+${CurrencyUtils.formatTL(report.totalIncome)}",
                                accent = colors.selfGreen,
                                icon = Icons.AutoMirrored.Filled.TrendingUp,
                                modifier = Modifier.fillMaxWidth()
                            )
                            CashflowMetricTile(
                                title = "TOPLAM GİDER (${report.expenseCount})",
                                valueText = "-${CurrencyUtils.formatTL(report.totalExpense)}",
                                accent = colors.alertRed,
                                icon = Icons.AutoMirrored.Filled.TrendingDown,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(colors.background)
                        .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Net Nakit Dengesi",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = CurrencyUtils.formatSignedTL(report.netCashflow),
                        fontFamily = PoppinsFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = netColor,
                        modifier = Modifier.testTag("ie_net_cashflow_text")
                    )
                }

                // Gelir / Gider Oran Çubuğu
                val totalFlow = (report.totalIncome + report.totalExpense).takeIf { it > 0.01 }
                if (totalFlow != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    val incW = (report.totalIncome / totalFlow).toFloat().coerceIn(0.04f, 0.96f)
                    val expW = (1f - incW).coerceAtLeast(0.04f)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .border(1.dp, colors.borderColor, RoundedCornerShape(5.dp))
                    ) {
                        Box(modifier = Modifier.weight(incW).height(10.dp).background(colors.selfGreen))
                        Box(modifier = Modifier.weight(expW).height(10.dp).background(colors.alertRed))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    val incPct = ((report.totalIncome / totalFlow) * 100).toInt()
                    val expPct = (100 - incPct).coerceAtLeast(0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Gelir Payı %$incPct", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.selfGreen)
                        Text("Gider Payı %$expPct", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.alertRed)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CrispSolidButton(
                        text = "+ Gelir Ekle",
                        containerColor = colors.selfGreen,
                        contentColor = PureWhite,
                        onClick = onAddIncome,
                        modifier = Modifier.weight(1f),
                        testTag = "ie_add_income_button"
                    )
                    CrispSolidButton(
                        text = "- Gider Ekle",
                        containerColor = colors.alertRed,
                        contentColor = PureWhite,
                        onClick = onAddExpense,
                        modifier = Modifier.weight(1f),
                        testTag = "ie_add_expense_button"
                    )
                }
            }
        }

        // 4. 6 AYLIK GELİR & GİDER KARŞILAŞTIRMA GRAFİĞİ
        item(key = "ie_monthly_chart", contentType = "chart") {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "6 Aylık Gelir vs Gider",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Son 6 takvim ayındaki toplam giriş ve harcama karşılaştırması",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
                Spacer(modifier = Modifier.height(10.dp))
                CrispCashflowBarChart(
                    bars = report.monthlyBars,
                    incomeColor = colors.selfGreen,
                    expenseColor = colors.alertRed
                )
            }
        }

        // 5. KATEGORİ DAĞILIMI
        item(key = "ie_category_breakdown", contentType = "categories") {
            val activeStats = if (selectedCategoryTab == CategoryTab.EXPENSE) {
                report.expenseCategories
            } else {
                report.incomeCategories
            }
            val barColor = if (selectedCategoryTab == CategoryTab.EXPENSE) {
                colors.alertRed
            } else {
                colors.selfGreen
            }

            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "Kategori Dağılımı",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryTab.entries.forEach { tab ->
                        val selected = selectedCategoryTab == tab
                        val activeFill = if (tab == CategoryTab.EXPENSE) colors.alertRed else colors.selfGreen
                        OutlinedButton(
                            onClick = { selectedCategoryTab = tab },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("ie_cat_tab_${tab.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (selected) activeFill else colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) activeFill else colors.cardBackground,
                                contentColor = if (selected) PureWhite else colors.textPrimary
                            )
                        ) {
                            Text(
                                text = tab.label,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (activeStats.isEmpty()) {
                    Text(
                        text = if (selectedCategoryTab == CategoryTab.EXPENSE) {
                            "${selectedPeriod.label} döneminde gider kaydı bulunmuyor."
                        } else {
                            "${selectedPeriod.label} döneminde gelir kaydı bulunmuyor."
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.disclaimerText
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        activeStats.forEach { stat ->
                            CategoryBreakdownRow(
                                stat = stat,
                                accentColor = barColor
                            )
                        }
                    }
                }
            }
        }

        // 6. HAREKET LİSTESİ FİLTRE & ARAMA
        item(key = "ie_ledger_header", contentType = "ledger_header") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Dönem Hareketleri (${filteredTransactions.size})",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                SermayeTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = "Hareketlerde Ara",
                    placeholder = "Kategori veya açıklama yaz...",
                    testTag = "ie_search_input"
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CashflowLedgerFilter.entries.forEach { filter ->
                        val selected = ledgerFilter == filter
                        OutlinedButton(
                            onClick = { ledgerFilter = filter },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("ie_ledger_filter_${filter.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                                contentColor = if (selected) colors.cardBackground else colors.textPrimary
                            )
                        ) {
                            Text(filter.label, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (filteredTransactions.isEmpty()) {
            item(key = "ie_empty_ledger", contentType = "empty") {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Seçili dönem ve filtre için hareket bulunamadı.",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        } else {
            items(
                items = filteredTransactions,
                key = { it.id },
                contentType = { "tx_row" }
            ) { tx ->
                TransactionRowCard(
                    tx = tx,
                    onRequestDelete = { txToDelete = tx },
                    modifier = Modifier.widthIn(max = 600.dp)
                )
            }
        }

        item(key = "ie_bottom_spacer", contentType = "spacer") {
            Spacer(modifier = Modifier.height(20.dp))
        }
        }
    }

    if (txToDelete != null) {
        val target = txToDelete!!
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            containerColor = colors.cardBackground,
            title = {
                Text("İşlemi Sil", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
            },
            text = {
                Text(
                    "Bu işlemi silmek istiyor musun? Kasan ve gelir-gider özetin geri düzeltilecek.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransaction(target)
                        txToDelete = null
                    }
                ) {
                    Text("Evet, Sil", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { txToDelete = null }) {
                    Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                }
            }
        )
    }
}

@Composable
private fun CashflowMetricTile(
    title: String,
    valueText: String,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(colors.background)
            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = valueText,
            fontFamily = PoppinsFontFamily,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CategoryBreakdownRow(
    stat: CashflowCategoryStat,
    accentColor: Color
) {
    val colors = LocalSermayeColors.current
    val fillFraction = (stat.sharePercent / 100.0).toFloat().coerceIn(0.03f, 1f)
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${stat.category} (${stat.count})",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${CurrencyUtils.formatTL(stat.amount)} • ${CurrencyUtils.formatPercent(stat.sharePercent)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(colors.background)
                .border(1.dp, colors.borderColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fillFraction)
                    .height(8.dp)
                    .background(accentColor, RoundedCornerShape(4.dp))
            )
        }
    }
}
