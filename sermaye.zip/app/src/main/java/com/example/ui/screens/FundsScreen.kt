package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.AssetPriceAlertRule
import com.example.data.local.FundEntity
import com.example.data.repo.LiveAssetQuote
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.LiveMarketUiState
import com.example.data.repo.MarketCategory
import com.example.domain.AVAILABLE_FUND_OPTIONS
import com.example.domain.ComputedFund
import com.example.domain.FinanceEngine
import com.example.domain.FundOptionSpec
import com.example.domain.InvestmentSortOption
import com.example.ui.SermayeUiState
import com.example.ui.components.AssetAlertThresholdDialog
import com.example.ui.components.CrispMiniSparkline
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.DatePickerSelectorRow
import com.example.ui.components.LiveClockBadge
import com.example.ui.components.SermayeTextField
import com.example.ui.components.VaultCard
import com.example.ui.components.resolveDisplaySparkline
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.pow

private enum class InvestmentFilterCategory(val label: String) {
    ALL("Tümü"),
    FAVORITES("⭐ Favoriler"),
    FUNDS("Tüm Fonlar"),
    METALS("Altın & Madenler"),
    CRYPTO("Tüm Kriptolar"),
    FX("Döviz"),
    MY_INVESTMENTS("Yatırımlarım")
}

@Composable
fun FundsScreen(
    uiState: SermayeUiState,
    onInvestInFund: (
        fundType: String,
        riskLabel: String,
        amount: Double,
        monthlyReturnPercent: Double,
        purchaseDateMillis: Long,
        onSuccess: () -> Unit
    ) -> Unit,
    onUpdateFundValue: (FundEntity, Double) -> Unit,
    onSellFund: (FundEntity, Double) -> Unit,
    onAddMonthlyYield: () -> Unit,
    onRefreshLiveMarket: () -> Unit,
    onOpenLiveAssetDetail: (LiveAssetQuote) -> Unit,
    onOpenUserFundDetail: (ComputedFund) -> Unit,
    onRemoteSearch: (String) -> Unit,
    onClearRemoteSearch: () -> Unit,
    onConsumePendingInvestFundType: () -> Unit,
    onOpenFundOptionSetDetail: (FundOptionSpec) -> Unit = {},
    onToggleFavoriteAsset: (String, String) -> Unit = { _, _ -> },
    onEnableAssetAlert: (LiveAssetQuote, Double) -> Unit = { _, _ -> },
    onDisableAssetAlert: (String, String) -> Unit = { _, _ -> },
    onShowToast: (String, Boolean) -> Unit = { _, _ -> }
) {
    val colors = LocalSermayeColors.current
    val context = LocalContext.current
    val summary = uiState.summary
    val trLocale = remember { Locale.forLanguageTag("tr-TR") }

    var showInvestSheet by remember { mutableStateOf(false) }
    var preselectedOptionName by remember { mutableStateOf<String?>(null) }
    var fundToUpdate by remember { mutableStateOf<ComputedFund?>(null) }
    var fundToSell by remember { mutableStateOf<ComputedFund?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(InvestmentFilterCategory.ALL) }
    var selectedSort by remember { mutableStateOf(InvestmentSortOption.DEFAULT) }
    var alertDialogQuote by remember { mutableStateOf<LiveAssetQuote?>(null) }

    var pendingAfterPermission by remember { mutableStateOf<(() -> Unit)?>(null) }
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingAfterPermission
        pendingAfterPermission = null
        if (granted) {
            action?.invoke()
        } else {
            onShowToast("Telefon bildirimi için bildirim izni vermen gerekiyor.", true)
        }
    }

    fun requestPermissionOrRun(onGrantedImmediate: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                onGrantedImmediate()
            } else {
                pendingAfterPermission = onGrantedImmediate
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            onGrantedImmediate()
        }
    }

    LaunchedEffect(uiState.pendingInvestFundType) {
        val pending = uiState.pendingInvestFundType
        if (!pending.isNullOrBlank()) {
            preselectedOptionName = pending
            showInvestSheet = true
            onConsumePendingInvestFundType()
        }
    }

    // Auto-refresh live prices every 25s without per-second parent recompositions
    LaunchedEffect(Unit) {
        if (uiState.liveMarketState is LiveMarketUiState.Idle) {
            onRefreshLiveMarket()
        }
        while (true) {
            delay(25_000L)
            onRefreshLiveMarket()
        }
    }

    val liveSnapshot = (uiState.liveMarketState as? LiveMarketUiState.Ready)?.snapshot
    val allCatalogQuotes = remember(liveSnapshot) {
        if (liveSnapshot == null) emptyList()
        else (liveSnapshot.assets + liveSnapshot.topFunds).distinctBy { it.id }
    }
    val quotesById = remember(allCatalogQuotes) {
        allCatalogQuotes.associateBy { it.id }
    }

    val favoriteIds = uiState.profile.favoriteAssetIds
    val assetAlerts = uiState.profile.assetAlerts
    val normalizedQuery = remember(searchQuery) { searchQuery.trim().lowercase(trLocale) }

    val filteredUserFunds = remember(summary.computedFunds, normalizedQuery, selectedFilter, selectedSort) {
        if (selectedFilter != InvestmentFilterCategory.ALL && selectedFilter != InvestmentFilterCategory.MY_INVESTMENTS) {
            emptyList()
        } else {
            val base = if (normalizedQuery.isEmpty()) {
                summary.computedFunds
            } else {
                summary.computedFunds.filter { cf ->
                    cf.entity.fundType.lowercase(trLocale).contains(normalizedQuery) ||
                        cf.entity.riskLabel.lowercase(trLocale).contains(normalizedQuery)
                }
            }
            FinanceEngine.sortComputedFunds(base, selectedSort)
        }
    }

    val filteredPresets = remember(normalizedQuery, selectedSort) {
        val base = AVAILABLE_FUND_OPTIONS.filter { opt ->
            normalizedQuery.isEmpty() ||
                opt.name.lowercase(trLocale).contains(normalizedQuery) ||
                opt.riskLabel.lowercase(trLocale).contains(normalizedQuery)
        }
        FinanceEngine.sortFundOptionSpecs(base, selectedSort)
    }

    val filteredCatalogQuotes = remember(
        allCatalogQuotes,
        uiState.remoteSearchState,
        normalizedQuery,
        selectedFilter,
        selectedSort,
        favoriteIds
    ) {
        if (selectedFilter == InvestmentFilterCategory.MY_INVESTMENTS) {
            emptyList()
        } else {
            val baseList = if (normalizedQuery.length >= 2 &&
                uiState.remoteSearchState.query.equals(searchQuery.trim(), ignoreCase = true)
            ) {
                (allCatalogQuotes + uiState.remoteSearchState.results).distinctBy {
                    "${it.id}_${it.symbol}".lowercase(Locale.US)
                }
            } else {
                allCatalogQuotes
            }
            val matched = baseList.filter { q ->
                val catMatch = when (selectedFilter) {
                    InvestmentFilterCategory.ALL -> true
                    InvestmentFilterCategory.FAVORITES -> q.id in favoriteIds
                    InvestmentFilterCategory.FUNDS -> q.category == MarketCategory.FUND
                    InvestmentFilterCategory.METALS -> q.category == MarketCategory.METAL
                    InvestmentFilterCategory.CRYPTO -> q.category == MarketCategory.CRYPTO || q.symbol in listOf("IBIT", "FBTC", "ETHA")
                    InvestmentFilterCategory.FX -> q.category == MarketCategory.FX
                    InvestmentFilterCategory.MY_INVESTMENTS -> false
                }
                val queryMatch = if (normalizedQuery.isEmpty()) {
                    true
                } else {
                    q.name.lowercase(trLocale).contains(normalizedQuery) ||
                        q.symbol.lowercase(trLocale).contains(normalizedQuery) ||
                        q.category.lowercase(trLocale).contains(normalizedQuery) ||
                        q.sourceName.lowercase(trLocale).contains(normalizedQuery)
                }
                catMatch && queryMatch
            }
            FinanceEngine.sortLiveAssetQuotes(matched, selectedSort)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // HEADER + CANLI SAAT + YENİLE
        item(key = "funds_header", contentType = "header") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .padding(top = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "YATIRIM",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    OutlinedButton(
                        onClick = onRefreshLiveMarket,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("funds_refresh_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, colors.borderColor)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Canlı fiyatları yenile",
                            tint = colors.storeBlue
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Yenile", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                LiveClockBadge(
                    prefix = "Canlı:",
                    suffix = "TSİ • Grafik ve 1A/6A/12A AI tahmin"
                )
            }
        }

        // KOMPAKT YATIRIM ÖZET KARTI (Arama & grafik kartları ilk ekranda hemen görünsün)
        if (normalizedQuery.isEmpty() && (selectedFilter == InvestmentFilterCategory.ALL || selectedFilter == InvestmentFilterCategory.MY_INVESTMENTS)) {
            item(key = "funds_summary_card", contentType = "summary") {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Toplam Yatırım Kasası",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.disclaimerText
                            )
                            Text(
                                text = CurrencyUtils.formatTL(summary.totalFundVault),
                                fontFamily = PoppinsFontFamily,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.fundOrange
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Boşta: ${CurrencyUtils.formatTL(summary.idleFundCash)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Kilitli: ${CurrencyUtils.formatTL(summary.lockedFundValue)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.disclaimerText
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                preselectedOptionName = null
                                showInvestSheet = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("funds_invest_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = colors.fundOrange,
                                contentColor = PureWhite
                            )
                        ) {
                            Text(
                                text = "YATIRIM YAP",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        OutlinedButton(
                            onClick = onAddMonthlyYield,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("funds_add_monthly_yield_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = colors.selfGreen,
                                contentColor = PureWhite
                            )
                        ) {
                            Text(
                                text = "GETİRİ EKLE",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // ARAMA ÇUBUĞU, KATEGORİ FİLTRELERİ VE SIRALAMA ÇUBUĞU
        item(key = "funds_search_filter_sort", contentType = "controls") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { next ->
                        searchQuery = next
                        if (next.trim().length >= 2) {
                            onRemoteSearch(next)
                        } else {
                            onClearRemoteSearch()
                        }
                    },
                    placeholder = {
                        Text(
                            text = "Fon (TEFAS/ETF), tüm kripto veya maden ara...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.disclaimerText
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Ara",
                            tint = colors.storeBlue
                        )
                    },
                    trailingIcon = if (searchQuery.isNotEmpty()) {
                        {
                            IconButton(
                                onClick = {
                                    searchQuery = ""
                                    onClearRemoteSearch()
                                },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Aramayı temizle",
                                    tint = colors.textPrimary
                                )
                            }
                        }
                    } else null,
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = colors.cardBackground,
                        unfocusedContainerColor = colors.cardBackground,
                        focusedBorderColor = colors.borderColor,
                        unfocusedBorderColor = colors.borderColor,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        cursorColor = colors.storeBlue
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("funds_search_input")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    InvestmentFilterCategory.entries.forEach { cat ->
                        val selected = selectedFilter == cat
                        val chipLabel = if (cat == InvestmentFilterCategory.FAVORITES && favoriteIds.isNotEmpty()) {
                            "${cat.label} (${favoriteIds.size})"
                        } else {
                            cat.label
                        }
                        OutlinedButton(
                            onClick = { selectedFilter = cat },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("funds_filter_${cat.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                                contentColor = if (selected) colors.cardBackground else colors.textPrimary
                            )
                        ) {
                            Text(chipLabel, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Sort,
                            contentDescription = "Sırala",
                            tint = colors.storeBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Sırala:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    InvestmentSortOption.entries.forEach { sortOpt ->
                        val selected = selectedSort == sortOpt
                        OutlinedButton(
                            onClick = { selectedSort = sortOpt },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("funds_sort_${sortOpt.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (selected) colors.storeBlue else colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.storeBlue else colors.cardBackground,
                                contentColor = if (selected) PureWhite else colors.textPrimary
                            )
                        ) {
                            Text(sortOpt.label, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // TÜM YATIRIM SETLERİ (6 HAZIR FON SETİ — HER BİRİ GRAFİKLİ & TIKLANABİLİR)
        if (selectedFilter == InvestmentFilterCategory.ALL || selectedFilter == InvestmentFilterCategory.FUNDS) {
            if (filteredPresets.isNotEmpty()) {
                item(key = "funds_presets_carousel", contentType = "presets") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 600.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Yatırım Setleri (${filteredPresets.size} Fon Paketi)",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            filteredPresets.forEach { option ->
                                val benchmarkQuote = quotesById[LiveMarketRepository.resolveBenchmarkQuoteIdForFundName(option.name)]
                                FundOptionSetCard(
                                    option = option,
                                    benchmarkQuote = benchmarkQuote,
                                    onCardClick = { onOpenFundOptionSetDetail(option) },
                                    onQuickInvest = {
                                        preselectedOptionName = option.name
                                        showInvestSheet = true
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // KULLANICININ AKTİF YATIRIMLARI (Varsa veya Yatırımlarım sekmesi seçiliyse göster)
        if ((selectedFilter == InvestmentFilterCategory.ALL && summary.computedFunds.isNotEmpty()) ||
            selectedFilter == InvestmentFilterCategory.MY_INVESTMENTS
        ) {
            item {
                Text(
                    text = "Aktif Yatırımlarım (${filteredUserFunds.size})",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                )
            }

            if (summary.computedFunds.isEmpty()) {
                item {
                    VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                        Text(
                            text = "Henüz aktif yatırımın yok. Yukarıdan YATIRIM YAP ile başlayabilir veya canlı varlıklara tıklayıp grafiğini inceleyebilirsin.",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            } else if (filteredUserFunds.isEmpty() && normalizedQuery.isNotEmpty()) {
                item {
                    VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                        Text(
                            text = "Aramana uyan aktif yatırımın yok.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.disclaimerText
                        )
                    }
                }
            } else {
                items(
                    items = filteredUserFunds,
                    key = { "user_${it.entity.id}" },
                    contentType = { "user_fund" }
                ) { item ->
                    val benchmarkQuote = quotesById[LiveMarketRepository.resolveBenchmarkQuoteIdForFundName(item.entity.fundType)]
                    FundPositionCard(
                        computed = item,
                        liveBenchmarkQuote = benchmarkQuote,
                        onCardClick = { onOpenUserFundDetail(item) },
                        onUpdateClick = { fundToUpdate = item },
                        onSellClick = { fundToSell = item },
                        modifier = Modifier.widthIn(max = 600.dp)
                    )
                }
            }
        }

        // TÜM FONLAR, TÜM KRİPTOLAR VE TÜM MADENLER KATALOĞU (GRAFİKLİ + TIKLANABİLİR + 1A/6A/12A AI TAHMİNLİ)
        if (selectedFilter != InvestmentFilterCategory.MY_INVESTMENTS) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Tüm Fonlar, Kriptolar & Madenler (${filteredCatalogQuotes.size})",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    if (uiState.remoteSearchState.isSearching) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = colors.storeBlue,
                            strokeWidth = 2.dp
                        )
                    }
                }
            }

            when (val live = uiState.liveMarketState) {
                is LiveMarketUiState.Idle,
                is LiveMarketUiState.Loading -> {
                    item {
                        VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = colors.storeBlue,
                                    strokeWidth = 3.dp
                                )
                                Text(
                                    text = "Tüm fonlar, kriptolar ve maden grafikleri çekiliyor...",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                            }
                        }
                    }
                }
                is LiveMarketUiState.Error -> {
                    item {
                        VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                            Text(
                                text = live.message,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.alertRed
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            CrispSolidButton(
                                text = "Tekrar Dene",
                                containerColor = colors.storeBlue,
                                contentColor = PureWhite,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = onRefreshLiveMarket
                            )
                        }
                    }
                }
                is LiveMarketUiState.Ready -> {
                    if (filteredCatalogQuotes.isEmpty()) {
                        item {
                            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                                Text(
                                    text = if (uiState.remoteSearchState.isSearching) {
                                        "\"$searchQuery\" canlı piyasada aranıyor..."
                                    } else {
                                        "\"$searchQuery\" için canlı piyasa sonucu bulunamadı."
                                    },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                if (searchQuery.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            searchQuery = ""
                                            selectedFilter = InvestmentFilterCategory.ALL
                                            onClearRemoteSearch()
                                        },
                                        modifier = Modifier.height(48.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, colors.borderColor)
                                    ) {
                                        Text("Aramayı Temizle", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.storeBlue)
                                    }
                                }
                            }
                        }
                    } else {
                        itemsIndexed(
                            items = filteredCatalogQuotes,
                            key = { _, quote -> "live_${quote.id.lowercase(Locale.US)}_${quote.symbol.uppercase(Locale.US)}" },
                            contentType = { _, _ -> "live_catalog" }
                        ) { index, quote ->
                            LiveCatalogAssetCard(
                                quote = quote,
                                rank = index + 1,
                                isFavorite = quote.id in favoriteIds,
                                alertRule = assetAlerts[quote.id],
                                onToggleFavorite = { onToggleFavoriteAsset(quote.id, quote.name) },
                                onAlertClick = {
                                    requestPermissionOrRun {
                                        alertDialogQuote = quote
                                    }
                                },
                                onClick = { onOpenLiveAssetDetail(quote) },
                                modifier = Modifier.widthIn(max = 600.dp)
                            )
                        }
                    }
                }
            }
        }

        item(key = "funds_bottom_spacer", contentType = "spacer") { Spacer(modifier = Modifier.height(16.dp)) }
    }

    if (showInvestSheet) {
        InvestInFundBottomSheet(
            idleFundCash = summary.idleFundCash,
            initialOptionName = preselectedOptionName,
            onDismiss = { showInvestSheet = false },
            onSubmit = { type, risk, amount, retPct, date ->
                onInvestInFund(type, risk, amount, retPct, date) {
                    showInvestSheet = false
                }
            }
        )
    }

    if (fundToUpdate != null) {
        UpdateFundValueDialog(
            target = fundToUpdate!!,
            onDismiss = { fundToUpdate = null },
            onConfirm = { newVal ->
                onUpdateFundValue(fundToUpdate!!.entity, newVal)
                fundToUpdate = null
            }
        )
    }

    if (fundToSell != null) {
        SellFundConfirmDialog(
            target = fundToSell!!,
            onDismiss = { fundToSell = null },
            onConfirm = {
                onSellFund(fundToSell!!.entity, fundToSell!!.currentValue)
                fundToSell = null
            }
        )
    }

    val activeQuoteDialog = alertDialogQuote
    if (activeQuoteDialog != null) {
        AssetAlertThresholdDialog(
            assetName = activeQuoteDialog.name,
            symbol = activeQuoteDialog.symbol,
            currentPrice = activeQuoteDialog.price,
            currency = activeQuoteDialog.currency,
            existingRule = assetAlerts[activeQuoteDialog.id],
            onDismiss = { alertDialogQuote = null },
            onConfirmEnable = { pct ->
                onEnableAssetAlert(activeQuoteDialog, pct)
                alertDialogQuote = null
            },
            onDisable = {
                onDisableAssetAlert(activeQuoteDialog.id, activeQuoteDialog.name)
                alertDialogQuote = null
            }
        )
    }
}

@Composable
fun UpdateFundValueDialog(
    target: ComputedFund,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    val colors = LocalSermayeColors.current
    var valueInput by remember(target.entity.id) { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        title = {
            Text(
                text = "${target.entity.fundType} Değerini Güncelle",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = colors.textPrimary
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Mevcut hesaplanan değer: ${CurrencyUtils.formatTL(target.currentValue)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                SermayeTextField(
                    value = valueInput,
                    onValueChange = {
                        valueInput = it
                        error = null
                    },
                    label = "Yeni Güncel Değer",
                    placeholder = "0",
                    isNumeric = true,
                    suffixText = "TL"
                )
                if (error != null) {
                    Text(error!!, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.alertRed)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val parsed = CurrencyUtils.parsePositiveOrZero(valueInput)
                    if (parsed == null) {
                        error = "Geçerli bir tutar gir"
                    } else {
                        onConfirm(parsed)
                    }
                }
            ) {
                Text("Kaydet", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.selfGreen)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
            }
        }
    )
}

@Composable
fun SellFundConfirmDialog(
    target: ComputedFund,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val colors = LocalSermayeColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        title = {
            Text("Yatırımdan Çık", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
        },
        text = {
            Text(
                text = "${target.entity.fundType} satılacak ve ${CurrencyUtils.formatTL(target.currentValue)} " +
                    "boştaki yatırım parana geri eklenecek. Onaylıyor musun?",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text("Evet, Sat", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
            }
        }
    )
}

@Composable
private fun FundOptionSetCard(
    option: FundOptionSpec,
    benchmarkQuote: LiveAssetQuote?,
    onCardClick: () -> Unit,
    onQuickInvest: () -> Unit
) {
    val colors = LocalSermayeColors.current
    val riskColor = when {
        option.riskLabel.contains("Düşük") -> colors.selfGreen
        option.riskLabel.contains("Orta") -> colors.fundOrange
        option.riskLabel.contains("Çok") -> colors.alertRed
        else -> colors.storeBlue
    }
    val sparkPrices = remember(option, benchmarkQuote) {
        val liveSpark = benchmarkQuote?.sparklinePrices.orEmpty()
        if (liveSpark.size >= 2) {
            liveSpark
        } else {
            val r = option.defaultMonthlyReturnPercent / 100.0
            (0..12).map { m -> 100.0 * (1.0 + r).pow(m.toDouble()) }
        }
    }
    val lineColor = if (sparkPrices.size >= 2 && sparkPrices.last() < sparkPrices.first()) {
        colors.alertRed
    } else {
        riskColor
    }

    Column(
        modifier = Modifier
            .width(236.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(colors.cardBackground)
            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onCardClick)
            .padding(14.dp)
            .testTag("fund_set_card_${option.name}"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(riskColor, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = option.riskLabel,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureWhite
                )
            }
            Text(
                text = "+%${CurrencyUtils.formatEditableNumber(option.defaultMonthlyReturnPercent)}/ay",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.selfGreen
            )
        }

        Text(
            text = option.name,
            fontFamily = PoppinsFontFamily,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        val subLine = if (benchmarkQuote != null) {
            "${benchmarkQuote.symbol}: ${CurrencyUtils.formatMoneyByCurrency(benchmarkQuote.price, benchmarkQuote.currency)}"
        } else {
            "12 Aylık Bileşik Büyüme"
        }
        Text(
            text = subLine,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.storeBlue,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        CrispMiniSparkline(
            prices = sparkPrices,
            lineColor = lineColor,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Detay & AI ▸",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.storeBlue
            )
            OutlinedButton(
                onClick = onQuickInvest,
                modifier = Modifier.height(48.dp),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, colors.fundOrange),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = colors.fundOrange,
                    contentColor = PureWhite
                )
            ) {
                Text("Yatır", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LiveCatalogAssetCard(
    quote: LiveAssetQuote,
    rank: Int,
    isFavorite: Boolean,
    alertRule: AssetPriceAlertRule?,
    onToggleFavorite: () -> Unit,
    onAlertClick: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val chg = quote.changePercent24h
    val trendPositive = (chg ?: 0.0) >= 0.0
    val badgeBg = if (trendPositive) colors.selfGreen else colors.alertRed
    val displaySpark = remember(quote) { resolveDisplaySparkline(quote) }
    val sparkColor = when {
        displaySpark.size >= 2 && displaySpark.last() >= displaySpark.first() -> colors.selfGreen
        displaySpark.size >= 2 -> colors.alertRed
        else -> badgeBg
    }
    val categoryColor = when (quote.category) {
        MarketCategory.FUND -> colors.storeBlue
        MarketCategory.METAL -> colors.fundOrange
        MarketCategory.CRYPTO -> colors.selfGreen
        else -> colors.textPrimary
    }
    val hasAlert = alertRule?.enabled == true
    val rankBadgeColor = if (rank <= 3) colors.fundOrange else colors.storeBlue

    VaultCard(
        modifier = modifier.testTag("catalog_asset_${quote.id}"),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(rankBadgeColor, RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "#$rank",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(categoryColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                            .border(1.dp, categoryColor, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = quote.category,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }
                    if (hasAlert && alertRule != null) {
                        Box(
                            modifier = Modifier
                                .background(colors.fundOrange.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
                                .border(1.dp, colors.fundOrange, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "±${CurrencyUtils.formatPercent(alertRule.thresholdPercent)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.fundOrange
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = quote.name,
                    fontFamily = PoppinsFontFamily,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "${quote.symbol} • ${quote.sourceName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyUtils.formatMoneyByCurrency(quote.price, quote.currency),
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                if (chg != null) {
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .background(badgeBg, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = CurrencyUtils.formatSignedPercent(chg),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                }
            }
        }
        if (displaySpark.size >= 2) {
            Spacer(modifier = Modifier.height(8.dp))
            CrispMiniSparkline(
                prices = displaySpark,
                lineColor = sparkColor,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ShowChart,
                    contentDescription = null,
                    tint = colors.storeBlue,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Grafik & AI Tahmin ▸",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.storeBlue,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onAlertClick,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("funds_alert_asset_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (hasAlert) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                        contentDescription = if (hasAlert) "${quote.name} fiyat bildirimini düzenle" else "${quote.name} için fiyat bildirimi aç",
                        tint = if (hasAlert) colors.fundOrange else colors.textPrimary
                    )
                }
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("funds_fav_asset_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                        contentDescription = if (isFavorite) "${quote.name} favorilerden çıkar" else "${quote.name} favorilere ekle",
                        tint = if (isFavorite) Color(0xFFF59E0B) else colors.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun FundPositionCard(
    computed: ComputedFund,
    liveBenchmarkQuote: LiveAssetQuote?,
    onCardClick: () -> Unit,
    onUpdateClick: () -> Unit,
    onSellClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val isProfit = computed.profitTL >= 0.0
    val profitColor = if (isProfit) colors.selfGreen else colors.alertRed

    val displaySparkline = remember(computed, liveBenchmarkQuote) {
        if (liveBenchmarkQuote != null && liveBenchmarkQuote.sparklinePrices.size >= 2) {
            liveBenchmarkQuote.sparklinePrices
        } else {
            val base = computed.entity.investedAmount.coerceAtLeast(1.0)
            val rate = (computed.entity.monthlyReturnPercent / 100.0).coerceAtLeast(0.0)
            (0..6).map { m ->
                base * (1.0 + rate).pow(m.toDouble() * 0.5)
            }.let { list ->
                list.dropLast(1) + computed.currentValue.coerceAtLeast(0.0)
            }
        }
    }

    VaultCard(
        modifier = modifier.testTag("user_fund_card_${computed.entity.id}"),
        onClick = onCardClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = computed.entity.fundType,
                fontFamily = PoppinsFontFamily,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = computed.entity.riskLabel,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.fundOrange
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Alış Tarihi: ${CurrencyUtils.formatDate(computed.entity.purchaseDateMillis)} (${computed.monthsElapsedFromPurchase} ay geçti)",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Yatırılan Tutar: ${CurrencyUtils.formatTL(computed.entity.investedAmount)} • Aylık Beklenti: ${CurrencyUtils.formatPercent(computed.entity.monthlyReturnPercent)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Güncel Değer: ${CurrencyUtils.formatTL(computed.currentValue)}",
            fontFamily = PoppinsFontFamily,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Kar/Zarar: ${CurrencyUtils.formatSignedTL(computed.profitTL)} (${CurrencyUtils.formatSignedPercent(computed.profitPercent)})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = profitColor
        )
        if (liveBenchmarkQuote != null) {
            val chgStr = liveBenchmarkQuote.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Canlı Piyasa (${liveBenchmarkQuote.symbol}): ${CurrencyUtils.formatMoneyByCurrency(liveBenchmarkQuote.price, liveBenchmarkQuote.currency)}$chgStr",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.storeBlue
            )
        }
        if (displaySparkline.size >= 2) {
            Spacer(modifier = Modifier.height(8.dp))
            CrispMiniSparkline(
                prices = displaySparkline,
                lineColor = profitColor,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ShowChart,
                contentDescription = null,
                tint = colors.storeBlue,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = "Canlı Grafik & 1A / 6A / 12A AI Tahmini Gör ▸",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.storeBlue
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = onUpdateClick,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, colors.borderColor)
            ) {
                Text(
                    text = "Değeri Güncelle",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            OutlinedButton(
                onClick = onSellClick,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, colors.alertRed)
            ) {
                Text(
                    text = "Yatırımdan Çık",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.alertRed,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InvestInFundBottomSheet(
    idleFundCash: Double,
    initialOptionName: String? = null,
    onDismiss: () -> Unit,
    onSubmit: (
        fundType: String,
        riskLabel: String,
        amount: Double,
        monthlyReturnPercent: Double,
        purchaseDateMillis: Long
    ) -> Unit
) {
    val colors = LocalSermayeColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val initialOption = remember(initialOptionName) {
        AVAILABLE_FUND_OPTIONS.firstOrNull { it.name == initialOptionName } ?: AVAILABLE_FUND_OPTIONS.first()
    }
    var selectedOption by remember(initialOption) { mutableStateOf<FundOptionSpec>(initialOption) }
    var amountInput by remember { mutableStateOf("") }
    var returnInput by remember(initialOption) {
        mutableStateOf(CurrencyUtils.formatEditableNumber(initialOption.defaultMonthlyReturnPercent))
    }
    var dateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.cardBackground,
        scrimColor = colors.textPrimary.copy(alpha = 0.65f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Yatırım Yap",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Kapat", tint = colors.textPrimary)
                }
            }

            Text(
                text = "Boştaki Yatırım Paran: ${CurrencyUtils.formatTL(idleFundCash)}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.fundOrange
            )

            Text("HANGİ YATIRIM SETİ / FON?", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AVAILABLE_FUND_OPTIONS.forEach { opt ->
                    val selected = selectedOption.name == opt.name
                    val compoundCurve = remember(opt) {
                        val r = opt.defaultMonthlyReturnPercent / 100.0
                        (0..12).map { m -> 100.0 * (1.0 + r).pow(m.toDouble()) }
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) colors.textPrimary else colors.cardBackground)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                            .clickable {
                                selectedOption = opt
                                returnInput = CurrencyUtils.formatEditableNumber(opt.defaultMonthlyReturnPercent)
                                errorMsg = null
                            }
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${opt.name} - ${opt.riskLabel}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) colors.cardBackground else colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "%${CurrencyUtils.formatEditableNumber(opt.defaultMonthlyReturnPercent)}/ay",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.selfGreen
                            )
                        }
                        CrispMiniSparkline(
                            prices = compoundCurve,
                            lineColor = if (selected) colors.fundOrange else colors.selfGreen,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            SermayeTextField(
                value = amountInput,
                onValueChange = {
                    amountInput = it
                    errorMsg = null
                },
                label = "NE KADAR?",
                placeholder = "0",
                isNumeric = true,
                suffixText = "TL",
                testTag = "fund_invest_amount_input"
            )

            if (idleFundCash > 0.0) {
                OutlinedButton(
                    onClick = {
                        amountInput = CurrencyUtils.formatEditableNumber(idleFundCash)
                        errorMsg = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("fund_invest_fill_all_button"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, colors.fundOrange)
                ) {
                    Text(
                        text = "Tüm Boştaki Parayı Yaz (${CurrencyUtils.formatTL(idleFundCash)})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.fundOrange
                    )
                }
            }

            SermayeTextField(
                value = returnInput,
                onValueChange = {
                    returnInput = it
                    errorMsg = null
                },
                label = "AYLIK GETİRİ BEKLENTİN? (%0 - %20)",
                placeholder = "3,5",
                isNumeric = true,
                suffixText = "%",
                testTag = "fund_invest_return_input"
            )

            DatePickerSelectorRow(
                label = "TARİH",
                selectedDateMillis = dateMillis,
                onDateSelected = { if (it != null) dateMillis = it }
            )

            if (errorMsg != null) {
                Text(errorMsg!!, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.alertRed)
            }

            CrispSolidButton(
                text = "YATIR",
                containerColor = colors.fundOrange,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth(),
                testTag = "fund_invest_submit_button",
                onClick = {
                    val amt = CurrencyUtils.parsePositiveOrZero(amountInput) ?: 0.0
                    val ret = CurrencyUtils.parsePositiveOrZero(returnInput) ?: -1.0
                    when {
                        amt <= 0.0 -> errorMsg = "Lütfen yatırım tutarını gir"
                        amt > idleFundCash + 0.0001 -> {
                            errorMsg = "Boştaki paran yetersiz. Boştaki paran: ${CurrencyUtils.formatTL(idleFundCash)}"
                        }
                        ret < 0.0 || ret > 20.0 -> {
                            errorMsg = "Aylık getiri beklentisi %0 ile %20 arası olmalı"
                        }
                        else -> onSubmit(selectedOption.name, selectedOption.riskLabel, amt, ret, dateMillis)
                    }
                }
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
