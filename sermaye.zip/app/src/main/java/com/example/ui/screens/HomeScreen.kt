package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.VaultType
import com.example.data.repo.LiveAssetQuote
import com.example.data.repo.LiveMarketUiState
import com.example.ui.HomeModalSheet
import com.example.ui.SermayeUiState
import com.example.ui.components.CrispLineGrowthChart
import com.example.ui.components.CrispMiniSparkline
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.HomeSectionCursor
import com.example.ui.components.SermayeHomeTopCursorBar
import com.example.ui.components.VaultCard
import com.example.ui.components.resolveDisplaySparkline
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlin.math.abs

@Composable
fun HomeScreen(
    uiState: SermayeUiState,
    onToggleDarkMode: (Boolean) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenVaultDetail: (VaultType) -> Unit,
    onOpenSheet: (HomeModalSheet) -> Unit,
    onOpenAllTransactions: () -> Unit,
    onDeleteTransaction: (TransactionEntity) -> Unit,
    onDismissWeeklyReminder: () -> Unit,
    onOpenLiveAssetDetail: (LiveAssetQuote) -> Unit = {},
    onToggleFavoriteAsset: (String, String) -> Unit = { _, _ -> },
    onOpenMarketPopular30: () -> Unit = {},
    onOpenIncomeExpense: () -> Unit = {}
) {
    val colors = LocalSermayeColors.current
    val summary = uiState.summary
    var txToDelete by remember { mutableStateOf<TransactionEntity?>(null) }

    val lastStoreTx = remember(uiState.transactions) {
        uiState.transactions.firstOrNull { abs(it.storeDelta) > 0.001 }
    }
    val lastSelfTx = remember(uiState.transactions) {
        uiState.transactions.firstOrNull { abs(it.selfDelta) > 0.001 }
    }
    val recentTransactions = remember(uiState.transactions) {
        uiState.transactions.take(10)
    }
    val liveSnap = (uiState.liveMarketState as? LiveMarketUiState.Ready)?.snapshot
    val favoriteIds = uiState.profile.favoriteAssetIds
    val assetAlerts = uiState.profile.assetAlerts

    val favoriteQuotes = remember(liveSnap, favoriteIds) {
        if (liveSnap == null || favoriteIds.isEmpty()) {
            emptyList()
        } else {
            val pool = (liveSnap.assets + liveSnap.topFunds).distinctBy { it.id }
            pool.filter { it.id in favoriteIds }
        }
    }

    val quickTickers = remember(liveSnap) {
        if (liveSnap == null) emptyList()
        else {
            val ids = listOf("gram_altin", "bitcoin", "fund_XU100.IS", "usd", "gumus")
            val pool = (liveSnap.assets + liveSnap.topFunds).associateBy { it.id }
            ids.mapNotNull { pool[it] }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. SABİT ÜST BAR + İMLEÇ (Kasa Özeti / Gelir & Gider / Hareketler)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Merhaba ${uiState.profile.userName}, 👋",
                fontFamily = PoppinsFontFamily,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onToggleDarkMode(!uiState.profile.isDarkMode) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("toggle_dark_mode_button")
                ) {
                    Icon(
                        imageVector = if (uiState.profile.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = if (uiState.profile.isDarkMode) "Açık Tema" else "Karanlık Tema",
                        tint = colors.textPrimary
                    )
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("home_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Ayarlar",
                        tint = colors.textPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        SermayeHomeTopCursorBar(
            active = HomeSectionCursor.VAULT_HOME,
            monthNetCashflow = summary.thisMonthIncome - summary.thisMonthExpense,
            onSelectHome = {},
            onSelectIncomeExpense = onOpenIncomeExpense,
            onSelectAllTransactions = onOpenAllTransactions,
            modifier = Modifier.widthIn(max = 600.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

        // HAFTALIK HATIRLATMA KARTI (varsa ve açıksa)
        if (uiState.showWeeklyReminder) {
            item {
                VaultCard(
                    modifier = Modifier.widthIn(max = 600.dp),
                    backgroundColor = colors.summaryBg,
                    borderColor = colors.summaryBorder
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Bu ay paranı ekledin mi?",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.summaryText,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onDismissWeeklyReminder) {
                            Text(
                                text = "Tamam",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.summaryText
                            )
                        }
                    }
                }
            }
        }

        // 2. HERO TOPLAM SERVET KARTI (Görselli + Oran Çubuklu)
        item {
            val deltaText = when {
                summary.thisMonthNetChange > 0.0 -> "Bu ay ${CurrencyUtils.formatSignedTL(summary.thisMonthNetChange)}"
                summary.thisMonthNetChange < 0.0 -> "Bu ay ${CurrencyUtils.formatSignedTL(summary.thisMonthNetChange)}"
                else -> "Bu ay değişim yok"
            }
            val deltaBg = when {
                summary.thisMonthNetChange > 0.0 -> colors.selfGreen
                summary.thisMonthNetChange < 0.0 -> colors.alertRed
                else -> colors.storeBlue
            }

            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_vault),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .matchParentSize()
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xE60B1220),
                                        Color(0xB80F172A)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TOPLAM SERVETİN",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFCBD5E1)
                            )
                            Box(
                                modifier = Modifier
                                    .background(deltaBg, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = deltaText,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PureWhite
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = CurrencyUtils.formatTL(summary.totalWealth),
                            fontFamily = PoppinsFontFamily,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite,
                            modifier = Modifier.testTag("home_total_wealth_text")
                        )
                    }
                }

                // 3-Kasa Oransal Dağılım Çubuğu
                val totalPositive = (summary.storeBalance + summary.totalFundVault + summary.selfBalance)
                    .takeIf { it > 0.01 }
                if (totalPositive != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    val sW = (summary.storeBalance / totalPositive).toFloat().coerceAtLeast(0.02f)
                    val fW = (summary.totalFundVault / totalPositive).toFloat().coerceAtLeast(0.02f)
                    val kW = (summary.selfBalance / totalPositive).toFloat().coerceAtLeast(0.02f)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .border(1.dp, colors.borderColor, RoundedCornerShape(5.dp))
                    ) {
                        Box(modifier = Modifier.weight(sW).height(10.dp).background(colors.storeBlue))
                        Box(modifier = Modifier.weight(fW).height(10.dp).background(colors.fundOrange))
                        Box(modifier = Modifier.weight(kW).height(10.dp).background(colors.selfGreen))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    val sPct = ((summary.storeBalance / totalPositive) * 100).toInt()
                    val fPct = ((summary.totalFundVault / totalPositive) * 100).toInt()
                    val kPct = (100 - sPct - fPct).coerceAtLeast(0)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Mağaza %$sPct", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.storeBlue)
                        Text("Yatırım %$fPct", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.fundOrange)
                        Text("Kendine %$kPct", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.selfGreen)
                    }
                }
            }
        }

        // FAVORİ TAKİP LİSTEM (Piyasa & Yatırım ile senkronize)
        item(key = "home_favorites_section", contentType = "favorites") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (favoriteQuotes.isNotEmpty()) {
                            "⭐ Favori Takip Listem (${favoriteQuotes.size})"
                        } else {
                            "⭐ Favori Takip Listem"
                        },
                        fontFamily = PoppinsFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    TextButton(onClick = onOpenMarketPopular30) {
                        Text(
                            text = "Piyasa ▸",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.storeBlue
                        )
                    }
                }

                if (favoriteQuotes.isEmpty()) {
                    VaultCard(
                        onClick = onOpenMarketPopular30,
                        modifier = Modifier.testTag("home_empty_favorites_card")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (favoriteIds.isNotEmpty() && liveSnap == null) {
                                        "${favoriteIds.size} favori varlığın canlı fiyatları yükleniyor..."
                                    } else {
                                        "Favori eklediğin kripto, fon ve madenler burada anlık görünür."
                                    },
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = onOpenMarketPopular30,
                                modifier = Modifier.height(48.dp),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, colors.storeBlue)
                            ) {
                                Text("Ekle", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.storeBlue)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        favoriteQuotes.forEach { quote ->
                            val spark = remember(quote) { resolveDisplaySparkline(quote) }
                            val isUp = (quote.changePercent24h ?: 0.0) >= 0.0
                            val tint = if (isUp) colors.selfGreen else colors.alertRed
                            val activeRule = assetAlerts[quote.id]?.takeIf { it.enabled }
                            Column(
                                modifier = Modifier
                                    .width(204.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(colors.cardBackground)
                                    .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                                    .clickable { onOpenLiveAssetDetail(quote) }
                                    .padding(12.dp)
                                    .testTag("home_fav_card_${quote.id}"),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = quote.symbol,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.storeBlue,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { onToggleFavoriteAsset(quote.id, quote.name) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = "${quote.name} favorilerden çıkar",
                                            tint = Color(0xFFF59E0B)
                                        )
                                    }
                                }
                                Text(
                                    text = quote.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = CurrencyUtils.formatMoneyByCurrency(quote.price, quote.currency),
                                        fontFamily = PoppinsFontFamily,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    quote.changePercent24h?.let { chg ->
                                        Text(
                                            text = CurrencyUtils.formatSignedPercent(chg),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = tint
                                        )
                                    }
                                }
                                if (activeRule != null) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = colors.fundOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "Alarm: ±${CurrencyUtils.formatPercent(activeRule.thresholdPercent)}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.fundOrange
                                        )
                                    }
                                }
                                if (spark.size >= 2) {
                                    CrispMiniSparkline(
                                        prices = spark,
                                        lineColor = tint,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // CANLI PİYASA ŞERİDİ (Tıklanabilir mini grafikler)
        if (quickTickers.isNotEmpty()) {
            item(key = "home_quick_tickers", contentType = "tickers") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Canlı Piyasa Nabzı",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        quickTickers.forEach { quote ->
                            val spark = remember(quote) { resolveDisplaySparkline(quote) }
                            val isUp = (quote.changePercent24h ?: 0.0) >= 0.0
                            val tint = if (isUp) colors.selfGreen else colors.alertRed
                            Column(
                                modifier = Modifier
                                    .width(172.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(colors.cardBackground)
                                    .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                                    .clickable { onOpenLiveAssetDetail(quote) }
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = quote.symbol,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.storeBlue,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    quote.changePercent24h?.let { chg ->
                                        Text(
                                            text = CurrencyUtils.formatSignedPercent(chg),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = tint
                                        )
                                    }
                                }
                                Text(
                                    text = CurrencyUtils.formatMoneyByCurrency(quote.price, quote.currency),
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (spark.size >= 2) {
                                    CrispMiniSparkline(
                                        prices = spark,
                                        lineColor = tint,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. 3 KASA KARTI (geniş ekranda yan yana, mobilde alt alta)
        item {
            val storeSubtitle = if (lastStoreTx != null) {
                "Son işlem: ${CurrencyUtils.formatRelativeDays(lastStoreTx.dateMillis)} ${CurrencyUtils.formatSignedTL(lastStoreTx.storeDelta)}"
            } else {
                "Henüz işlem yok"
            }
            val fundSubtitle = if (summary.computedFunds.isNotEmpty() || summary.totalFundReturnTL != 0.0) {
                "Fonların getirisi: ${CurrencyUtils.formatSignedTL(summary.totalFundReturnTL)}"
            } else {
                "Henüz fon yatırımı yok"
            }
            val selfSubtitle = if (lastSelfTx != null) {
                "Son işlem: ${CurrencyUtils.formatRelativeDays(lastSelfTx.dateMillis)} ${CurrencyUtils.formatSignedTL(lastSelfTx.selfDelta)}"
            } else {
                "Henüz işlem yok"
            }

            BoxWithConstraints(modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth()) {
                if (maxWidth >= 540.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SingleVaultCard(
                            emoji = "🏪",
                            title = "MAĞAZA KASASI",
                            amount = summary.storeBalance,
                            subtitle = storeSubtitle,
                            accentColor = colors.storeBlue,
                            onClick = { onOpenVaultDetail(VaultType.STORE) },
                            modifier = Modifier.weight(1f),
                            testTag = "vault_card_store"
                        )
                        SingleVaultCard(
                            emoji = "📈",
                            title = "FON KASASI",
                            amount = summary.totalFundVault,
                            subtitle = fundSubtitle,
                            accentColor = colors.fundOrange,
                            onClick = { onOpenVaultDetail(VaultType.FUND) },
                            modifier = Modifier.weight(1f),
                            testTag = "vault_card_fund"
                        )
                        SingleVaultCard(
                            emoji = "💚",
                            title = "KENDİNE KASASI",
                            amount = summary.selfBalance,
                            subtitle = selfSubtitle,
                            accentColor = colors.selfGreen,
                            onClick = { onOpenVaultDetail(VaultType.SELF) },
                            modifier = Modifier.weight(1f),
                            testTag = "vault_card_self"
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SingleVaultCard(
                            emoji = "🏪",
                            title = "MAĞAZA KASASI",
                            amount = summary.storeBalance,
                            subtitle = storeSubtitle,
                            accentColor = colors.storeBlue,
                            onClick = { onOpenVaultDetail(VaultType.STORE) },
                            testTag = "vault_card_store"
                        )
                        SingleVaultCard(
                            emoji = "📈",
                            title = "FON KASASI",
                            amount = summary.totalFundVault,
                            subtitle = fundSubtitle,
                            accentColor = colors.fundOrange,
                            onClick = { onOpenVaultDetail(VaultType.FUND) },
                            testTag = "vault_card_fund"
                        )
                        SingleVaultCard(
                            emoji = "💚",
                            title = "KENDİNE KASASI",
                            amount = summary.selfBalance,
                            subtitle = selfSubtitle,
                            accentColor = colors.selfGreen,
                            onClick = { onOpenVaultDetail(VaultType.SELF) },
                            testTag = "vault_card_self"
                        )
                    }
                }
            }
        }

        // 3.5 BU AY GELİR & GİDER ÖZET KARTI
        item(key = "home_income_expense_card", contentType = "income_expense") {
            val monthIncome = summary.thisMonthIncome
            val monthExpense = summary.thisMonthExpense
            val monthNet = monthIncome - monthExpense
            val netColor = when {
                monthNet > 0.0 -> colors.selfGreen
                monthNet < 0.0 -> colors.alertRed
                else -> colors.storeBlue
            }
            VaultCard(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .testTag("home_income_expense_card"),
                onClick = onOpenIncomeExpense
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Gelir & Gider • Bu Ay",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = onOpenIncomeExpense,
                        modifier = Modifier.testTag("home_open_income_expense_button")
                    ) {
                        Text(
                            text = "Detaylar ▸",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.storeBlue
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.background)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text("GELİR", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "+${CurrencyUtils.formatTL(monthIncome)}",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.selfGreen,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.background)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text("GİDER", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "-${CurrencyUtils.formatTL(monthExpense)}",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.alertRed,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(colors.background)
                            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Text("NET AKIŞ", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = CurrencyUtils.formatSignedTL(monthNet),
                            fontFamily = PoppinsFontFamily,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = netColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                val flowTotal = (monthIncome + monthExpense).takeIf { it > 0.01 }
                if (flowTotal != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    val incW = (monthIncome / flowTotal).toFloat().coerceIn(0.04f, 0.96f)
                    val expW = (1f - incW).coerceAtLeast(0.04f)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .border(1.dp, colors.borderColor, RoundedCornerShape(4.dp))
                    ) {
                        Box(modifier = Modifier.weight(incW).height(8.dp).background(colors.selfGreen))
                        Box(modifier = Modifier.weight(expW).height(8.dp).background(colors.alertRed))
                    }
                }
            }
        }

        // 4. 12 AYLIK BÜYÜME GRAFİĞİ
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "12 Aylık Büyümen",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                CrispLineGrowthChart(
                    points = summary.growthSeries,
                    lineColor = colors.storeBlue,
                    emptyText = "Henüz veri yok. Para ekleyince grafiğin burada oluşacak."
                )
            }
        }

        // 5. AI ÖZETİ KARTI
        item {
            VaultCard(
                modifier = Modifier.widthIn(max = 600.dp),
                backgroundColor = colors.summaryBg,
                borderColor = colors.summaryBorder
            ) {
                Text(
                    text = "🤖 AI ÖZETİ",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.summaryText
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = summary.aiAdvice.homeSummary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.summaryText
                )
            }
        }

        // 6. 2 DEV BUTON: + PARA EKLE & - PARA ÇIKAR
        item {
            BoxWithConstraints(modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth()) {
                if (maxWidth >= 460.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CrispSolidButton(
                            text = "+ PARA EKLE",
                            containerColor = colors.selfGreen,
                            contentColor = PureWhite,
                            onClick = { onOpenSheet(HomeModalSheet.ADD_INCOME) },
                            modifier = Modifier.weight(1f),
                            testTag = "home_add_income_button"
                        )
                        CrispSolidButton(
                            text = "- PARA ÇIKAR",
                            containerColor = colors.alertRed,
                            contentColor = PureWhite,
                            onClick = { onOpenSheet(HomeModalSheet.WITHDRAW) },
                            modifier = Modifier.weight(1f),
                            testTag = "home_withdraw_button"
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CrispSolidButton(
                            text = "+ PARA EKLE",
                            containerColor = colors.selfGreen,
                            contentColor = PureWhite,
                            onClick = { onOpenSheet(HomeModalSheet.ADD_INCOME) },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "home_add_income_button"
                        )
                        CrispSolidButton(
                            text = "- PARA ÇIKAR",
                            containerColor = colors.alertRed,
                            contentColor = PureWhite,
                            onClick = { onOpenSheet(HomeModalSheet.WITHDRAW) },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "home_withdraw_button"
                        )
                    }
                }
            }
        }

        // 7. KÜÇÜK LİNKLER: Transfer Yap & Tüm İşlemleri Gör
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { onOpenSheet(HomeModalSheet.TRANSFER) },
                    modifier = Modifier.testTag("home_transfer_link")
                ) {
                    Text(
                        text = "Transfer Yap →",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.storeBlue
                    )
                }
                TextButton(
                    onClick = onOpenAllTransactions,
                    modifier = Modifier.testTag("home_all_tx_link")
                ) {
                    Text(
                        text = "Tüm İşlemleri Gör →",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        }

        // BÖLÜM 5: SON İŞLEMLER (Son 10 işlem)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Son İşlemler",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                TextButton(onClick = onOpenAllTransactions) {
                    Text(
                        text = "Tümünü Gör →",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.storeBlue
                    )
                }
            }
        }

        if (recentTransactions.isEmpty()) {
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Henüz işlem yok. Para ekleyince burada görünecek.",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        } else {
            items(
                items = recentTransactions,
                key = { it.id },
                contentType = { "tx_row" }
            ) { tx ->
                TransactionRowCard(
                    tx = tx,
                    onRequestDelete = { txToDelete = tx },
                    modifier = Modifier.widthIn(max = 600.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    if (txToDelete != null) {
        val target = txToDelete!!
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            containerColor = colors.cardBackground,
            title = {
                Text(
                    text = "İşlemi Sil",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = colors.textPrimary
                )
            },
            text = {
                Text(
                    text = "Bu işlemi silmek istiyor musun? Kasan geri düzeltilecek.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTransaction(target)
                        txToDelete = null
                    }
                ) {
                    Text("Evet, Sil", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { txToDelete = null }) {
                    Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                }
            }
        )
    }
}

@Composable
private fun SingleVaultCard(
    emoji: String,
    title: String,
    amount: Double,
    subtitle: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val colors = LocalSermayeColors.current
    VaultCard(
        modifier = modifier.then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .background(accentColor, RoundedCornerShape(4.dp))
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "$emoji $title",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = accentColor
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = CurrencyUtils.formatTL(amount),
            fontFamily = PoppinsFontFamily,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary
        )
    }
}

@Composable
fun TransactionRowCard(
    tx: TransactionEntity,
    onRequestDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val isPositive = tx.type == TransactionType.INPUT.name ||
        tx.type == TransactionType.FUND_SELL.name ||
        tx.type == TransactionType.FUND_YIELD.name
    val isTransfer = tx.type == TransactionType.TRANSFER.name

    val amountText = when {
        isTransfer -> CurrencyUtils.formatTL(tx.amount)
        isPositive -> "+${CurrencyUtils.formatTL(tx.amount)}"
        else -> "-${CurrencyUtils.formatTL(tx.amount)}"
    }
    val amountColor = when {
        isTransfer -> colors.storeBlue
        isPositive -> colors.selfGreen
        else -> colors.alertRed
    }

    VaultCard(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${CurrencyUtils.formatDate(tx.dateMillis)} • ${tx.sourceOrCategory}",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                if (tx.note.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tx.note,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                }
                if (tx.type == TransactionType.INPUT.name) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Mağaza +${CurrencyUtils.formatTL(tx.storeDelta)}, " +
                            "Fon +${CurrencyUtils.formatTL(tx.fundDelta)}, " +
                            "Kendine +${CurrencyUtils.formatTL(tx.selfDelta)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = amountText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = amountColor
                )
                IconButton(
                    onClick = onRequestDelete,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("delete_tx_${tx.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "İşlemi sil",
                        tint = colors.alertRed
                    )
                }
            }
        }
    }
}
