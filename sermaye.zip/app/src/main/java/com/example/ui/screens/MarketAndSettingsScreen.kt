package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.AssetPriceAlertRule
import com.example.data.local.MarketNoteEntity
import com.example.data.local.MarketTagEntity
import com.example.data.local.TagPriceEntity
import com.example.data.repo.AiCommentaryState
import com.example.data.repo.FundMarketSignal
import com.example.data.repo.ImpactDirection
import com.example.data.repo.LiveAssetQuote
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.LiveMarketUiState
import com.example.data.repo.MarketCategory
import com.example.data.repo.MarketNewsItem
import com.example.data.repo.MarketNewsUiState
import com.example.domain.MonthlyPoint
import com.example.ui.MarketSettingsSubTab
import com.example.ui.SelectedNewsDetailState
import com.example.ui.SermayeUiState
import com.example.ui.components.AssetAlertThresholdDialog
import com.example.ui.components.AutoBalanceSplitSliders
import com.example.ui.components.CrispLineGrowthChart
import com.example.ui.components.CrispMiniSparkline
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.DatePickerSelectorRow
import com.example.ui.components.LiveClockBadge
import com.example.ui.components.NewsCoverImage
import com.example.ui.components.SermayeTextField
import com.example.ui.components.VaultCard
import com.example.ui.components.resolveDisplaySparkline
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private enum class MarketFilterCategory(val label: String) {
    FEATURED("En Çok Bakılan 30"),
    FAVORITES("⭐ Favoriler"),
    FUNDS("Tüm Fonlar"),
    METALS("Altın & Madenler"),
    CRYPTO("Tüm Kriptolar"),
    FX("Döviz"),
    ALL("Tümü")
}

private enum class MarketJumpSection(val label: String, val icon: ImageVector) {
    ASSETS("Fon & Maden", Icons.AutoMirrored.Filled.ShowChart),
    ALERTS("Alarmlar", Icons.Default.NotificationsActive),
    NEWS("Haberler", Icons.AutoMirrored.Filled.Article),
    NOTES("Notlar", Icons.Default.EditNote)
}

@Composable
fun MarketAndSettingsScreen(
    uiState: SermayeUiState,
    onSelectSubTab: (MarketSettingsSubTab) -> Unit,
    onRefreshLiveMarket: () -> Unit,
    onOpenLiveAssetDetail: (LiveAssetQuote) -> Unit,
    onToggleFavoriteAsset: (String, String) -> Unit,
    onEnableAssetAlert: (LiveAssetQuote, Double) -> Unit,
    onDisableAssetAlert: (String, String) -> Unit,
    onRemoteSearch: (String) -> Unit,
    onClearRemoteSearch: () -> Unit,
    onSendLiveNotification: () -> Unit,
    onSummarizeAgendaWithAi: () -> Unit,
    onOpenNewsArticle: (MarketNewsItem) -> Unit,
    onCloseNewsArticle: () -> Unit,
    onToggleMarketAlerts: (Boolean) -> Unit,
    onSelectAlertThreshold: (Double) -> Unit,
    onAddMarketTag: (String, onSuccess: () -> Unit) -> Unit,
    onDeleteMarketTag: (Long) -> Unit,
    onAddTagPrice: (Long, Double, onSuccess: () -> Unit) -> Unit,
    onAddMarketNote: (String, onSuccess: () -> Unit) -> Unit,
    onDeleteMarketNote: (Long) -> Unit,
    onSaveSettings: (
        userName: String,
        email: String,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) -> Unit,
    onToggleWeeklyReminder: (Boolean) -> Unit,
    onShowToast: (String, Boolean) -> Unit,
    onClearAllData: () -> Unit
) {
    val colors = LocalSermayeColors.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp)
                .padding(top = 12.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MarketSettingsSubTab.entries.forEach { subTab ->
                val selected = uiState.marketSettingsSubTab == subTab
                OutlinedButton(
                    onClick = { onSelectSubTab(subTab) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("subtab_${subTab.name}"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, colors.borderColor),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                        contentColor = if (selected) colors.cardBackground else colors.textPrimary
                    )
                ) {
                    Text(subTab.label, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (uiState.marketSettingsSubTab == MarketSettingsSubTab.MARKET) {
            MarketTrackingContent(
                uiState = uiState,
                tags = uiState.marketTags,
                tagPrices = uiState.tagPrices,
                notes = uiState.marketNotes,
                onRefreshLiveMarket = onRefreshLiveMarket,
                onOpenLiveAssetDetail = onOpenLiveAssetDetail,
                onToggleFavoriteAsset = onToggleFavoriteAsset,
                onEnableAssetAlert = onEnableAssetAlert,
                onDisableAssetAlert = onDisableAssetAlert,
                onRemoteSearch = onRemoteSearch,
                onClearRemoteSearch = onClearRemoteSearch,
                onSendLiveNotification = onSendLiveNotification,
                onSummarizeAgendaWithAi = onSummarizeAgendaWithAi,
                onOpenNewsArticle = onOpenNewsArticle,
                onCloseNewsArticle = onCloseNewsArticle,
                onToggleMarketAlerts = onToggleMarketAlerts,
                onSelectAlertThreshold = onSelectAlertThreshold,
                onAddMarketTag = onAddMarketTag,
                onDeleteMarketTag = onDeleteMarketTag,
                onAddTagPrice = onAddTagPrice,
                onAddMarketNote = onAddMarketNote,
                onDeleteMarketNote = onDeleteMarketNote,
                onShowError = { onShowToast(it, true) }
            )
        } else {
            SettingsContent(
                uiState = uiState,
                onSaveSettings = onSaveSettings,
                onToggleWeeklyReminder = onToggleWeeklyReminder,
                onShowToast = onShowToast,
                onClearAllData = onClearAllData
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MarketTrackingContent(
    uiState: SermayeUiState,
    tags: List<MarketTagEntity>,
    tagPrices: List<TagPriceEntity>,
    notes: List<MarketNoteEntity>,
    onRefreshLiveMarket: () -> Unit,
    onOpenLiveAssetDetail: (LiveAssetQuote) -> Unit,
    onToggleFavoriteAsset: (String, String) -> Unit,
    onEnableAssetAlert: (LiveAssetQuote, Double) -> Unit,
    onDisableAssetAlert: (String, String) -> Unit,
    onRemoteSearch: (String) -> Unit,
    onClearRemoteSearch: () -> Unit,
    onSendLiveNotification: () -> Unit,
    onSummarizeAgendaWithAi: () -> Unit,
    onOpenNewsArticle: (MarketNewsItem) -> Unit,
    onCloseNewsArticle: () -> Unit,
    onToggleMarketAlerts: (Boolean) -> Unit,
    onSelectAlertThreshold: (Double) -> Unit,
    onAddMarketTag: (String, () -> Unit) -> Unit,
    onDeleteMarketTag: (Long) -> Unit,
    onAddTagPrice: (Long, Double, () -> Unit) -> Unit,
    onAddMarketNote: (String, () -> Unit) -> Unit,
    onDeleteMarketNote: (Long) -> Unit,
    onShowError: (String) -> Unit
) {
    val colors = LocalSermayeColors.current
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val trLocale = remember { Locale.forLanguageTag("tr-TR") }
    var marketSearchQuery by remember { mutableStateOf("") }
    var selectedMarketFilter by remember { mutableStateOf(MarketFilterCategory.FEATURED) }
    var newTagInput by remember { mutableStateOf("") }
    var newNoteInput by remember { mutableStateOf("") }
    var alertDialogQuote by remember { mutableStateOf<LiveAssetQuote?>(null) }
    var alertDialogRuleToEdit by remember { mutableStateOf<AssetPriceAlertRule?>(null) }

    // Auto-refresh market data every 60 seconds without disturbing scroll or 60fps rendering
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            onRefreshLiveMarket()
        }
    }

    var pendingActionAfterPermission by remember { mutableStateOf<(() -> Unit)?>(null) }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingActionAfterPermission
        pendingActionAfterPermission = null
        if (granted) {
            action?.invoke()
        } else {
            onShowError("Telefon bildirimi için bildirim izni vermen gerekiyor.")
        }
    }

    fun requestPermissionOrRun(onGrantedImmediate: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                onGrantedImmediate()
            } else {
                pendingActionAfterPermission = onGrantedImmediate
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            onGrantedImmediate()
        }
    }

    val liveReady = uiState.liveMarketState as? LiveMarketUiState.Ready
    val allMarketQuotes = remember(liveReady) {
        if (liveReady == null) emptyList()
        else (liveReady.snapshot.assets + liveReady.snapshot.topFunds).distinctBy { it.id }
    }
    val favoriteIds = uiState.profile.favoriteAssetIds
    val assetAlerts = uiState.profile.assetAlerts
    val normQuery = remember(marketSearchQuery) { marketSearchQuery.trim().lowercase(trLocale) }
    val filteredMarketQuotes = remember(
        allMarketQuotes,
        uiState.remoteSearchState,
        normQuery,
        selectedMarketFilter,
        favoriteIds
    ) {
        val base = if (normQuery.length >= 2 &&
            uiState.remoteSearchState.query.equals(marketSearchQuery.trim(), ignoreCase = true)
        ) {
            (allMarketQuotes + uiState.remoteSearchState.results).distinctBy {
                "${it.id}_${it.symbol}".lowercase(Locale.US)
            }
        } else {
            allMarketQuotes
        }
        if (normQuery.isNotEmpty()) {
            base.filter { q ->
                val catOk = when (selectedMarketFilter) {
                    MarketFilterCategory.FEATURED, MarketFilterCategory.ALL -> true
                    MarketFilterCategory.FAVORITES -> q.id in favoriteIds
                    MarketFilterCategory.FUNDS -> q.category == MarketCategory.FUND
                    MarketFilterCategory.METALS -> q.category == MarketCategory.METAL
                    MarketFilterCategory.CRYPTO -> q.category == MarketCategory.CRYPTO || q.symbol in listOf("IBIT", "FBTC", "ETHA")
                    MarketFilterCategory.FX -> q.category == MarketCategory.FX
                }
                catOk && (
                    q.name.lowercase(trLocale).contains(normQuery) ||
                        q.symbol.lowercase(trLocale).contains(normQuery) ||
                        q.category.lowercase(trLocale).contains(normQuery) ||
                        q.sourceName.lowercase(trLocale).contains(normQuery)
                    )
            }
        } else {
            when (selectedMarketFilter) {
                MarketFilterCategory.FEATURED -> LiveMarketRepository.resolvePopular30Mixed(base)
                MarketFilterCategory.FAVORITES -> base.filter { it.id in favoriteIds }
                MarketFilterCategory.FUNDS -> base.filter { it.category == MarketCategory.FUND }
                MarketFilterCategory.METALS -> base.filter { it.category == MarketCategory.METAL }
                MarketFilterCategory.CRYPTO -> base.filter { it.category == MarketCategory.CRYPTO || it.symbol in listOf("IBIT", "FBTC", "ETHA") }
                MarketFilterCategory.FX -> base.filter { it.category == MarketCategory.FX }
                MarketFilterCategory.ALL -> base
            }
        }
    }

    val showAllFeaturedBtn = selectedMarketFilter == MarketFilterCategory.FEATURED &&
        normQuery.isEmpty() &&
        allMarketQuotes.size > filteredMarketQuotes.size

    val marketListItemCount = when (uiState.liveMarketState) {
        is LiveMarketUiState.Idle,
        is LiveMarketUiState.Loading,
        is LiveMarketUiState.Error -> 1
        is LiveMarketUiState.Ready -> {
            if (filteredMarketQuotes.isEmpty()) 2
            else 1 + filteredMarketQuotes.size + (if (showAllFeaturedBtn) 1 else 0)
        }
    }
    val assetsSectionIndex = 0
    val alertsSectionIndex = 2 + marketListItemCount
    val newsSectionIndex = alertsSectionIndex + 1
    val notesSectionIndex = newsSectionIndex + 1

    val activeJumpSection by remember(alertsSectionIndex, newsSectionIndex, notesSectionIndex) {
        derivedStateOf {
            val firstIdx = listState.firstVisibleItemIndex
            when {
                firstIdx >= notesSectionIndex -> MarketJumpSection.NOTES
                firstIdx >= newsSectionIndex -> MarketJumpSection.NEWS
                firstIdx >= alertsSectionIndex -> MarketJumpSection.ALERTS
                else -> MarketJumpSection.ASSETS
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
    ) {
        // SABİT BÖLÜM IŞINLANMA ÇUBUĞU (Fon & Maden / Alarmlar / Haberler / Notlar)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MarketJumpSection.entries.forEach { sec ->
                val isCurrent = activeJumpSection == sec
                val targetIndex = when (sec) {
                    MarketJumpSection.ASSETS -> assetsSectionIndex
                    MarketJumpSection.ALERTS -> alertsSectionIndex
                    MarketJumpSection.NEWS -> newsSectionIndex
                    MarketJumpSection.NOTES -> notesSectionIndex
                }
                OutlinedButton(
                    onClick = {
                        coroutineScope.launch {
                            listState.animateScrollToItem(targetIndex)
                        }
                    },
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("market_jump_${sec.name}"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, if (isCurrent) colors.storeBlue else colors.borderColor),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isCurrent) colors.storeBlue else colors.cardBackground,
                        contentColor = if (isCurrent) PureWhite else colors.textPrimary
                    )
                ) {
                    Icon(
                        imageVector = sec.icon,
                        contentDescription = sec.label,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sec.label,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item(key = "market_header", contentType = "header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Canlı Piyasa & Gündem",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        OutlinedButton(
                            onClick = onRefreshLiveMarket,
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("market_refresh_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = colors.cardBackground,
                                contentColor = colors.textPrimary
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Canlı fiyatları yenile",
                                tint = colors.storeBlue
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Yenile", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LiveClockBadge(
                        prefix = "Canlı Saat:",
                        suffix = "(TSİ) • Otomatik güncellenir"
                    )
                }
            }

        // 1. ARAMA + KATEGORİ FİLTRESİ + CANLI TÜM FONLAR, KRİPTOLAR VE MADENLER
        item(key = "market_search_filters", contentType = "search_filters") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = marketSearchQuery,
                    onValueChange = { next ->
                        marketSearchQuery = next
                        if (next.trim().length >= 2) {
                            onRemoteSearch(next)
                        } else {
                            onClearRemoteSearch()
                        }
                    },
                    placeholder = {
                        Text(
                            text = "Fon (TEFAS/ETF), tüm kripto veya maden ara...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.disclaimerText
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Piyasada ara",
                            tint = colors.storeBlue
                        )
                    },
                    trailingIcon = if (marketSearchQuery.isNotEmpty()) {
                        {
                            IconButton(
                                onClick = {
                                    marketSearchQuery = ""
                                    onClearRemoteSearch()
                                },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Aramayı temizle",
                                    tint = colors.textPrimary
                                )
                            }
                        }
                    } else null,
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = colors.cardBackground,
                        unfocusedContainerColor = colors.cardBackground,
                        focusedBorderColor = colors.borderColor,
                        unfocusedBorderColor = colors.borderColor,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        cursorColor = colors.storeBlue
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("market_search_input")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MarketFilterCategory.entries.forEach { cat ->
                        val selected = selectedMarketFilter == cat
                        val chipLabel = if (cat == MarketFilterCategory.FAVORITES && favoriteIds.isNotEmpty()) {
                            "${cat.label} (${favoriteIds.size})"
                        } else {
                            cat.label
                        }
                        OutlinedButton(
                            onClick = { selectedMarketFilter = cat },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("market_filter_${cat.name}"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                                contentColor = if (selected) colors.cardBackground else colors.textPrimary
                            )
                        ) {
                            Text(chipLabel, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        when (val live = uiState.liveMarketState) {
            is LiveMarketUiState.Idle,
            is LiveMarketUiState.Loading -> {
                item(key = "market_loading", contentType = "status") {
                    VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = colors.storeBlue,
                                strokeWidth = 3.dp
                            )
                            Text(
                                text = "Tüm fonlar, kriptolar ve madenler canlı alınıyor...",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                    }
                }
            }
            is LiveMarketUiState.Error -> {
                item(key = "market_error", contentType = "status") {
                    VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                        Text(
                            text = live.message,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.alertRed
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        CrispSolidButton(
                            text = "Tekrar Dene",
                            containerColor = colors.storeBlue,
                            contentColor = PureWhite,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = onRefreshLiveMarket
                        )
                    }
                }
            }
            is LiveMarketUiState.Ready -> {
                val timeText = CurrencyUtils.formatIstanbulTimeWithSeconds(live.snapshot.fetchedAtMillis)
                item(key = "market_count_header", contentType = "subheader") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 600.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedMarketFilter.label} (${filteredMarketQuotes.size} / ${allMarketQuotes.size})",
                            fontFamily = PoppinsFontFamily,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (uiState.remoteSearchState.isSearching) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = colors.storeBlue,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "$timeText TSİ",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.storeBlue
                            )
                        }
                    }
                }

                if (filteredMarketQuotes.isEmpty()) {
                    item(key = "market_empty", contentType = "status") {
                        VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                            Text(
                                text = when {
                                    uiState.remoteSearchState.isSearching -> "\"$marketSearchQuery\" canlı piyasada aranıyor..."
                                    selectedMarketFilter == MarketFilterCategory.FAVORITES -> "Henüz favori eklemedin. Herhangi bir varlıktaki ★ yıldız simgesine dokunarak favorilere ekleyebilirsin."
                                    else -> "Aramana uyan fon, kripto veya maden bulunamadı."
                                },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                    }
                } else {
                    items(
                        items = filteredMarketQuotes,
                        key = { "mkt_${it.id.lowercase(Locale.US)}_${it.symbol.uppercase(Locale.US)}" },
                        contentType = { "asset_row" }
                    ) { quote ->
                        LiveAssetRow(
                            quote = quote,
                            isFund = quote.category == MarketCategory.FUND,
                            isFavorite = quote.id in favoriteIds,
                            alertRule = assetAlerts[quote.id],
                            onToggleFavorite = { onToggleFavoriteAsset(quote.id, quote.name) },
                            onAlertClick = {
                                requestPermissionOrRun {
                                    alertDialogRuleToEdit = null
                                    alertDialogQuote = quote
                                }
                            },
                            onClick = { onOpenLiveAssetDetail(quote) },
                            modifier = Modifier.widthIn(max = 600.dp)
                        )
                    }

                    if (showAllFeaturedBtn) {
                        item(key = "market_show_all_btn", contentType = "action") {
                            OutlinedButton(
                                onClick = { selectedMarketFilter = MarketFilterCategory.ALL },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .widthIn(max = 600.dp)
                                    .height(48.dp)
                                    .testTag("market_show_all_button"),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, colors.storeBlue)
                            ) {
                                Text(
                                    text = "Tüm Piyasayı Gör (${allMarketQuotes.size} Fon, Kripto & Maden) ▸",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.storeBlue
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. TELEFONA FİYAT BİLDİRİMLERİ (GENEL + ÖZEL VARLIK ALARMLARI)
        item(key = "market_alerts_section", contentType = "alerts") {
            val thresholdOptions = listOf(0.5, 1.0, 2.0, 5.0)
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = colors.fundOrange
                    )
                    Text(
                        text = "Telefona Fiyat Bildirimleri",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Altın, Bitcoin veya büyük fon düşünce/yükselince bildir",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = uiState.profile.marketAlertsEnabled,
                        modifier = Modifier.testTag("market_alerts_switch"),
                        onCheckedChange = { checked ->
                            if (checked) {
                                requestPermissionOrRun {
                                    onToggleMarketAlerts(true)
                                }
                            } else {
                                onToggleMarketAlerts(false)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PureWhite,
                            checkedTrackColor = colors.selfGreen
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Değişim Eşiği (Düşüş / Yükseliş)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    thresholdOptions.forEach { threshold ->
                        val selected = kotlin.math.abs(uiState.profile.alertThresholdPercent - threshold) < 0.01
                        OutlinedButton(
                            onClick = { onSelectAlertThreshold(threshold) },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("alert_threshold_$threshold"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) colors.fundOrange else colors.cardBackground,
                                contentColor = if (selected) PureWhite else colors.textPrimary
                            )
                        ) {
                            Text(
                                text = CurrencyUtils.formatPercent(threshold),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                val activeCustomAlerts = assetAlerts.values.filter { it.enabled }
                if (activeCustomAlerts.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(thickness = 1.dp, color = colors.borderColor)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Özel Varlık Alarmların (${activeCustomAlerts.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        activeCustomAlerts.forEach { rule ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(colors.summaryBg, RoundedCornerShape(10.dp))
                                    .border(1.dp, colors.summaryBorder, RoundedCornerShape(10.dp))
                                    .clickable {
                                        requestPermissionOrRun {
                                            alertDialogQuote = null
                                            alertDialogRuleToEdit = rule
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${rule.assetName} (${rule.symbol})",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.summaryText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Hedef: ±${CurrencyUtils.formatPercent(rule.thresholdPercent)} • Baz: ${CurrencyUtils.formatMoneyByCurrency(rule.baselinePrice, rule.currency)}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.storeBlue
                                    )
                                }
                                IconButton(
                                    onClick = { onDisableAssetAlert(rule.assetId, rule.assetName) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "${rule.assetName} alarmını sil",
                                        tint = colors.alertRed
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                CrispSolidButton(
                    text = "ŞİMDİ KONTROL ET VE BİLDİRİM GÖNDER",
                    containerColor = colors.selfGreen,
                    contentColor = PureWhite,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "market_send_test_notice_button",
                    onClick = {
                        requestPermissionOrRun {
                            onSendLiveNotification()
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Herhangi bir fon, kripto veya maden kartındaki 🔔 zil simgesine dokunarak istediğin % değişim için ayrı bildirim kurabilirsin.",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            }
        }

        // 3. PİYASA GÜNDEMİ / HABERLER (UYGULAMA İÇİ HABERLER + FON ETKİSİ + GEMINI AI)
        item(key = "market_news_section", contentType = "news") {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "Piyasa Gündemi & Fonlara Etkisi",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Haberleri doğrudan uygulama içinde oku; her haberin hemen altında fonları ne yönde etkileyeceğini gör.",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
                Spacer(modifier = Modifier.height(10.dp))

                CrispSolidButton(
                    text = "Gündem + Kâr Stratejisini AI ile Özetle",
                    containerColor = colors.storeBlue,
                    contentColor = PureWhite,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "market_ai_summary_button",
                    onClick = onSummarizeAgendaWithAi
                )

                when (val aiState = uiState.marketAgendaAiState) {
                    is AiCommentaryState.Idle -> Unit
                    is AiCommentaryState.Loading -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = colors.storeBlue,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "Haberler ve fon etkileri analiz ediliyor...",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                    }
                    is AiCommentaryState.Streaming -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        MarketAiAgendaBox(text = aiState.text)
                    }
                    is AiCommentaryState.Success -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        MarketAiAgendaBox(text = aiState.text)
                    }
                    is AiCommentaryState.Error -> {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = aiState.message,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.alertRed
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(thickness = 1.dp, color = colors.borderColor)
                Spacer(modifier = Modifier.height(12.dp))

                when (val news = uiState.marketNewsState) {
                    is MarketNewsUiState.Idle,
                    is MarketNewsUiState.Loading -> {
                        Text(
                            text = "Gündem haberleri yükleniyor...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    is MarketNewsUiState.Error -> {
                        Text(
                            text = news.message,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.alertRed
                        )
                    }
                    is MarketNewsUiState.Ready -> {
                        if (news.items.isEmpty()) {
                            Text(
                                text = "Şu an gösterilecek gündem haberi bulunamadı.",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                news.items.forEachIndexed { idx, newsItem ->
                                    val dirColor = when (newsItem.fundImpact.direction) {
                                        ImpactDirection.POSITIVE -> colors.selfGreen
                                        ImpactDirection.NEGATIVE -> colors.alertRed
                                        ImpactDirection.MIXED -> colors.fundOrange
                                    }
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(colors.cardBackground, RoundedCornerShape(12.dp))
                                            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onOpenNewsArticle(newsItem) }
                                            .padding(12.dp)
                                            .testTag("market_news_item_$idx"),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(164.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                                        ) {
                                            NewsCoverImage(
                                                imageUrl = newsItem.imageUrl,
                                                headline = newsItem.title,
                                                affectedFunds = newsItem.fundImpact.affectedFunds,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(
                                                        Brush.verticalGradient(
                                                            colors = listOf(
                                                                PureBlack.copy(alpha = 0.55f),
                                                                Color.Transparent,
                                                                PureBlack.copy(alpha = 0.60f)
                                                            )
                                                        )
                                                    )
                                            )
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .align(Alignment.TopStart)
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(PureBlack.copy(alpha = 0.72f), RoundedCornerShape(6.dp))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = newsItem.source,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = PureWhite,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .background(dirColor, RoundedCornerShape(6.dp))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Text(
                                                        text = newsItem.fundImpact.direction.label,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = PureWhite
                                                    )
                                                }
                                            }
                                            if (newsItem.publishedAt.isNotBlank()) {
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomStart)
                                                        .padding(10.dp)
                                                        .background(PureBlack.copy(alpha = 0.72f), RoundedCornerShape(6.dp))
                                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                                ) {
                                                    Text(
                                                        text = newsItem.publishedAt,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = PureWhite
                                                    )
                                                }
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = newsItem.title,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = colors.textPrimary,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Article,
                                                contentDescription = "Uygulama içinde oku",
                                                tint = colors.storeBlue
                                            )
                                        }

                                        if (newsItem.summary.isNotBlank()) {
                                            Text(
                                                text = newsItem.summary,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = colors.textPrimary,
                                                maxLines = 3,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        // Haber sonrası fon etki kutusu
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(colors.summaryBg, RoundedCornerShape(8.dp))
                                                .border(1.dp, dirColor, RoundedCornerShape(8.dp))
                                                .padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Etkilenen Fonlar: ${newsItem.fundImpact.affectedFunds.joinToString(", ")}",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = colors.summaryText,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "İçerde Oku ▸",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = colors.storeBlue
                                                )
                                            }
                                            Text(
                                                text = newsItem.fundImpact.rationale,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = colors.summaryText
                                            )
                                        }
                                    }
                                }
                            }

                            // HABERLERİN SONRASINDA FON YÖNÜ ÖZET TABLOSU
                            if (uiState.newsFundSignals.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider(thickness = 1.dp, color = colors.borderColor)
                                Spacer(modifier = Modifier.height(14.dp))
                                NewsPostImpactSummaryBlock(signals = uiState.newsFundSignals)
                            }
                        }
                    }
                }
            }
        }

        item(key = "market_notes_section", contentType = "notes_header") {
            Text(
                text = "Kişisel Etiketlerim & Notlarım",
                fontFamily = PoppinsFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
            )
        }

        // TAG EKLE
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                SermayeTextField(
                    value = newTagInput,
                    onValueChange = { newTagInput = it },
                    label = "Tag Ekle",
                    placeholder = "Örn: #altın, #dolar, #bist100",
                    testTag = "market_tag_input"
                )
                Spacer(modifier = Modifier.height(10.dp))
                CrispSolidButton(
                    text = "EKLE",
                    containerColor = colors.storeBlue,
                    contentColor = PureWhite,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "market_add_tag_button",
                    onClick = {
                        if (newTagInput.trim().isEmpty()) {
                            onShowError("Lütfen bir tag yaz (Örn: #altın)")
                        } else {
                            onAddMarketTag(newTagInput) { newTagInput = "" }
                        }
                    }
                )
            }
        }

        if (tags.isEmpty()) {
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Kişisel takip etiketi eklemek istersen #altın yazıp ekleyebilirsin.",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        } else {
            items(
                items = tags,
                key = { "tag_${it.id}" },
                contentType = { "market_tag" }
            ) { tag ->
                val pricesForTag = remember(tagPrices, tag.id) {
                    tagPrices.filter { it.tagId == tag.id }
                }
                var priceInput by remember(tag.id) { mutableStateOf("") }

                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tag.tagName,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.storeBlue
                        )
                        IconButton(onClick = { onDeleteMarketTag(tag.id) }, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Etiketi sil", tint = colors.alertRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    SermayeTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it },
                        label = "Bugünkü fiyat ne?",
                        placeholder = "0",
                        isNumeric = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CrispSolidButton(
                        text = "EKLE",
                        containerColor = colors.selfGreen,
                        contentColor = PureWhite,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val parsed = CurrencyUtils.parsePositiveOrZero(priceInput) ?: 0.0
                            if (parsed <= 0.0) {
                                onShowError("Geçerli bir fiyat gir")
                            } else {
                                onAddTagPrice(tag.id, parsed) { priceInput = "" }
                            }
                        }
                    )

                    if (pricesForTag.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        val points = pricesForTag.map {
                            MonthlyPoint(
                                label = CurrencyUtils.formatShortDate(it.dateMillis),
                                totalWealth = it.price
                            )
                        }
                        CrispLineGrowthChart(
                            points = points,
                            lineColor = colors.fundOrange,
                            emptyText = ""
                        )
                    }
                }
            }
        }

        // NOT EKLE
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                SermayeTextField(
                    value = newNoteInput,
                    onValueChange = { newNoteInput = it },
                    label = "Piyasa Notu Ekle",
                    placeholder = "Örn: Dolar artıyor, mal almayı ertele",
                    singleLine = false,
                    testTag = "market_note_input"
                )
                Spacer(modifier = Modifier.height(10.dp))
                CrispSolidButton(
                    text = "NOT EKLE",
                    containerColor = colors.textPrimary,
                    contentColor = colors.cardBackground,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "market_add_note_button",
                    onClick = {
                        if (newNoteInput.trim().isEmpty()) {
                            onShowError("Not metni boş olamaz")
                        } else {
                            onAddMarketNote(newNoteInput) { newNoteInput = "" }
                        }
                    }
                )
            }
        }

        items(
            items = notes,
            key = { "note_${it.id}" },
            contentType = { "market_note" }
        ) { note ->
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = CurrencyUtils.formatDate(note.dateMillis),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.storeBlue
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = note.content,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary
                        )
                    }
                    IconButton(onClick = { onDeleteMarketNote(note.id) }, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Notu sil", tint = colors.alertRed)
                    }
                }
            }
        }

        item(key = "market_bottom_spacer", contentType = "spacer") { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }

    val selectedNews = uiState.selectedNewsArticle
    if (selectedNews != null) {
        InAppNewsReaderDialog(
            state = selectedNews,
            onDismiss = onCloseNewsArticle,
            onOpenExternalLink = { url ->
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                    onShowError("Dış bağlantı açılamadı.")
                }
            }
        )
    }

    val activeQuoteDialog = alertDialogQuote
    val activeEditRule = alertDialogRuleToEdit
    if (activeQuoteDialog != null) {
        AssetAlertThresholdDialog(
            assetName = activeQuoteDialog.name,
            symbol = activeQuoteDialog.symbol,
            currentPrice = activeQuoteDialog.price,
            currency = activeQuoteDialog.currency,
            existingRule = assetAlerts[activeQuoteDialog.id],
            onDismiss = { alertDialogQuote = null },
            onConfirmEnable = { pct ->
                onEnableAssetAlert(activeQuoteDialog, pct)
                alertDialogQuote = null
            },
            onDisable = {
                onDisableAssetAlert(activeQuoteDialog.id, activeQuoteDialog.name)
                alertDialogQuote = null
            }
        )
    } else if (activeEditRule != null) {
        val quoteSnapshot = allMarketQuotes.firstOrNull { it.id == activeEditRule.assetId }
        val syntheticQuote = quoteSnapshot ?: LiveAssetQuote(
            id = activeEditRule.assetId,
            name = activeEditRule.assetName,
            symbol = activeEditRule.symbol,
            price = activeEditRule.baselinePrice,
            currency = activeEditRule.currency,
            changePercent24h = null,
            category = MarketCategory.FUND,
            sourceName = "Alarm"
        )
        AssetAlertThresholdDialog(
            assetName = syntheticQuote.name,
            symbol = syntheticQuote.symbol,
            currentPrice = syntheticQuote.price,
            currency = syntheticQuote.currency,
            existingRule = activeEditRule,
            onDismiss = { alertDialogRuleToEdit = null },
            onConfirmEnable = { pct ->
                onEnableAssetAlert(syntheticQuote, pct)
                alertDialogRuleToEdit = null
            },
            onDisable = {
                onDisableAssetAlert(activeEditRule.assetId, activeEditRule.assetName)
                alertDialogRuleToEdit = null
            }
        )
    }
}

@Composable
private fun NewsPostImpactSummaryBlock(signals: List<FundMarketSignal>) {
    val colors = LocalSermayeColors.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "Bu Haberler Fonları Ne Yönde Etkiler?",
            fontFamily = PoppinsFontFamily,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        signals.forEach { sig ->
            val badgeColor = when {
                sig.netScore > 0 -> colors.selfGreen
                sig.netScore < 0 -> colors.alertRed
                else -> colors.fundOrange
            }
            val statusLabel = when {
                sig.netScore > 0 -> "Yükseliş Destekli ▲"
                sig.netScore < 0 -> "Düşüş Baskısı ▼"
                sig.mixedCount > 0 || sig.positiveCount > 0 -> "Dengeli / İzle ●"
                else -> "Nötr ●"
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, colors.borderColor, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = sig.fundName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "Olumlu: ${sig.positiveCount} • Olumsuz: ${sig.negativeCount} • İzle: ${sig.mixedCount}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.disclaimerText
                    )
                }
                Box(
                    modifier = Modifier
                        .background(badgeColor, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusLabel,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PureWhite
                    )
                }
            }
        }
    }
}

@Composable
private fun InAppNewsReaderDialog(
    state: SelectedNewsDetailState,
    onDismiss: () -> Unit,
    onOpenExternalLink: (String) -> Unit
) {
    val colors = LocalSermayeColors.current
    val item = state.item
    val dirColor = when (item.fundImpact.direction) {
        ImpactDirection.POSITIVE -> colors.selfGreen
        ImpactDirection.NEGATIVE -> colors.alertRed
        ImpactDirection.MIXED -> colors.fundOrange
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.title,
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                val meta = if (item.publishedAt.isNotBlank()) {
                    "${item.source} • ${item.publishedAt}"
                } else {
                    item.source
                }
                Text(
                    text = meta,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.storeBlue
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NewsCoverImage(
                    imageUrl = item.imageUrl,
                    headline = item.title,
                    affectedFunds = item.fundImpact.affectedFunds,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                )
                if (state.isLoadingBody) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = colors.storeBlue,
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "Haber metni yükleniyor...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }

                val displayText = when {
                    !state.bodyText.isNullOrBlank() -> state.bodyText
                    item.summary.isNotBlank() -> item.summary
                    else -> "Bu haber kaynağının tam metni uygulama içi özette sınırlıdır; başlık ve fon etki analizi aşağıdadır."
                }
                Text(
                    text = displayText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colors.summaryBg, RoundedCornerShape(10.dp))
                        .border(1.dp, dirColor, RoundedCornerShape(10.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(dirColor, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.fundImpact.direction.label,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                    Text(
                        text = "Etkilenen Fonlar: ${item.fundImpact.affectedFunds.joinToString(", ")}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.summaryText
                    )
                    Text(
                        text = item.fundImpact.rationale,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.summaryText
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            }
        },
        dismissButton = {
            if (item.link.isNotBlank()) {
                TextButton(onClick = { onOpenExternalLink(item.link) }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                        tint = colors.storeBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Kaynak", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.storeBlue)
                }
            }
        }
    )
}

@Composable
private fun LiveAssetRow(
    quote: LiveAssetQuote,
    isFund: Boolean,
    isFavorite: Boolean,
    alertRule: AssetPriceAlertRule?,
    onToggleFavorite: () -> Unit,
    onAlertClick: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val priceFormatted = CurrencyUtils.formatMoneyByCurrency(quote.price, quote.currency)
    val chg = quote.changePercent24h
    val displaySpark = remember(quote) { resolveDisplaySparkline(quote) }
    val sparkColor = when {
        displaySpark.size >= 2 && displaySpark.last() >= displaySpark.first() -> colors.selfGreen
        displaySpark.size >= 2 && displaySpark.last() < displaySpark.first() -> colors.alertRed
        (chg ?: 0.0) >= 0.0 -> colors.selfGreen
        else -> colors.alertRed
    }
    val categoryColor = when (quote.category) {
        MarketCategory.FUND -> colors.storeBlue
        MarketCategory.METAL -> colors.fundOrange
        MarketCategory.CRYPTO -> colors.selfGreen
        else -> colors.textPrimary
    }
    val hasAlert = alertRule?.enabled == true

    VaultCard(
        modifier = modifier.testTag("market_asset_${quote.id}"),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(categoryColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                            .border(1.dp, categoryColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = quote.category,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }
                    if (hasAlert && alertRule != null) {
                        Box(
                            modifier = Modifier
                                .background(colors.fundOrange.copy(alpha = 0.16f), RoundedCornerShape(6.dp))
                                .border(1.dp, colors.fundOrange, RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "±${CurrencyUtils.formatPercent(alertRule.thresholdPercent)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.fundOrange
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = quote.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = if (isFund) "${quote.symbol} • ${quote.sourceName}" else "${quote.symbol} • ${quote.sourceName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = priceFormatted,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                if (chg != null) {
                    val badgeBg = if (chg >= 0.0) colors.selfGreen else colors.alertRed
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .background(badgeBg, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = CurrencyUtils.formatSignedPercent(chg),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PureWhite
                        )
                    }
                }
            }
        }
        if (displaySpark.size >= 2) {
            Spacer(modifier = Modifier.height(8.dp))
            CrispMiniSparkline(
                prices = displaySpark,
                lineColor = sparkColor,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ShowChart,
                    contentDescription = null,
                    tint = colors.storeBlue,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Grafik & AI Tahmin ▸",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.storeBlue,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onAlertClick,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("alert_asset_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (hasAlert) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                        contentDescription = if (hasAlert) "${quote.name} fiyat bildirimini düzenle" else "${quote.name} için fiyat bildirimi aç",
                        tint = if (hasAlert) colors.fundOrange else colors.textPrimary
                    )
                }
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("fav_asset_${quote.id}")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                        contentDescription = if (isFavorite) "${quote.name} favorilerden çıkar" else "${quote.name} favorilere ekle",
                        tint = if (isFavorite) Color(0xFFF59E0B) else colors.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun MarketAiAgendaBox(text: String) {
    val colors = LocalSermayeColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.summaryBg, RoundedCornerShape(10.dp))
            .border(1.dp, colors.summaryBorder, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = colors.storeBlue
            )
            Text(
                text = "Gemini Gündem Özeti",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.storeBlue
            )
        }
        Text(
            text = text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.summaryText
        )
        Text(
            text = "Canlı piyasa verileri ve haber başlıklarına dayalı bilgilendirmedir; yatırım tavsiyesi değildir.",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.disclaimerText
        )
    }
}

@Composable
private fun SettingsContent(
    uiState: SermayeUiState,
    onSaveSettings: (
        userName: String,
        email: String,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) -> Unit,
    onToggleWeeklyReminder: (Boolean) -> Unit,
    onShowToast: (String, Boolean) -> Unit,
    onClearAllData: () -> Unit
) {
    val colors = LocalSermayeColors.current
    val context = LocalContext.current
    val profile = uiState.profile
    val summary = uiState.summary

    var nameInput by remember(profile.userName) { mutableStateOf(profile.userName) }
    var emailInput by remember(profile.email) { mutableStateOf(profile.email) }
    var incomeInput by remember(profile.monthlyIncome) {
        mutableStateOf(CurrencyUtils.formatEditableNumber(profile.monthlyIncome))
    }
    var storeRatio by remember(profile.storeRatio) { mutableIntStateOf(profile.storeRatio) }
    var fundRatio by remember(profile.fundRatio) { mutableIntStateOf(profile.fundRatio) }
    var selfRatio by remember(profile.selfRatio) { mutableIntStateOf(profile.selfRatio) }
    var targetAmountInput by remember(profile.storeTargetAmount) {
        mutableStateOf(CurrencyUtils.formatEditableNumber(profile.storeTargetAmount))
    }
    var targetDateMillis by remember(profile.storeTargetDateMillis) {
        mutableStateOf(profile.storeTargetDateMillis)
    }

    var deleteConfirmStep by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "Ayarlar",
                fontFamily = PoppinsFontFamily,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
            )
        }

        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SermayeTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = "Adın",
                        placeholder = "Örn: Mehmet"
                    )
                    SermayeTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = "E-posta",
                        placeholder = "Örn: mehmet@gmail.com"
                    )
                    SermayeTextField(
                        value = incomeInput,
                        onValueChange = { incomeInput = it },
                        label = "Aylık Kazanç",
                        placeholder = "0",
                        isNumeric = true,
                        suffixText = "TL"
                    )
                    AutoBalanceSplitSliders(
                        storeRatio = storeRatio,
                        fundRatio = fundRatio,
                        selfRatio = selfRatio,
                        previewAmount = CurrencyUtils.parsePositiveOrZero(incomeInput) ?: 0.0,
                        onRatiosChanged = { s, f, k ->
                            storeRatio = s
                            fundRatio = f
                            selfRatio = k
                        }
                    )
                    SermayeTextField(
                        value = targetAmountInput,
                        onValueChange = { targetAmountInput = it },
                        label = "Mağaza Açma Hedef Tutarı",
                        placeholder = "0",
                        isNumeric = true,
                        suffixText = "TL"
                    )
                    DatePickerSelectorRow(
                        label = "Hedef Tarih",
                        selectedDateMillis = targetDateMillis,
                        placeholder = "Takvimden seç",
                        onDateSelected = { targetDateMillis = it },
                        allowClear = true
                    )

                    CrispSolidButton(
                        text = "KAYDET",
                        containerColor = colors.selfGreen,
                        contentColor = PureWhite,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "settings_save_button",
                        onClick = {
                            if (nameInput.trim().isEmpty()) {
                                onShowToast("Adını yazman lazım", true)
                                return@CrispSolidButton
                            }
                            if (!CurrencyUtils.isValidEmail(emailInput)) {
                                onShowToast("E-posta doğru görünmüyor", true)
                                return@CrispSolidButton
                            }
                            onSaveSettings(
                                nameInput.trim(),
                                emailInput.trim(),
                                CurrencyUtils.parsePositiveOrZero(incomeInput) ?: 0.0,
                                storeRatio,
                                fundRatio,
                                selfRatio,
                                CurrencyUtils.parsePositiveOrZero(targetAmountInput) ?: 0.0,
                                targetDateMillis
                            )
                        }
                    )
                }
            }
        }

        // E-POSTA RAPORU + HAFTALIK HATIRLATMA
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                CrispSolidButton(
                    text = "Raporu E-postama Gönder",
                    containerColor = colors.storeBlue,
                    contentColor = PureWhite,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "settings_send_email_button",
                    onClick = {
                        val fundsText = if (summary.computedFunds.isEmpty()) {
                            "Aktif fon yok."
                        } else {
                            summary.computedFunds.joinToString("\n") { f ->
                                "- ${f.entity.fundType}: Yatırılan ${CurrencyUtils.formatTL(f.entity.investedAmount)}, " +
                                    "Güncel ${CurrencyUtils.formatTL(f.currentValue)}, Kar/Zarar ${CurrencyUtils.formatSignedTL(f.profitTL)}"
                            }
                        }

                        val body = """
                            SERMAYE - Aylık Raporum (${profile.userName})

                            KASALARIM:
                            - Mağaza Kasası: ${CurrencyUtils.formatTL(summary.storeBalance)}
                            - Fon Kasası (Toplam): ${CurrencyUtils.formatTL(summary.totalFundVault)}
                            - Kendine Kasası: ${CurrencyUtils.formatTL(summary.selfBalance)}
                            - TOPLAM SERVET: ${CurrencyUtils.formatTL(summary.totalWealth)}

                            FON PORTFÖYÜM:
                            $fundsText

                            AI ÖNERİSİ:
                            ${summary.aiAdvice.homeSummary}

                            Bu ayki işlem sayısı: ${summary.thisMonthTxCount}
                        """.trimIndent()

                        val recipient = profile.email.trim()
                        val uri = Uri.parse("mailto:${Uri.encode(recipient)}")
                        val emailIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                            putExtra(Intent.EXTRA_SUBJECT, "SERMAYE - Aylık Raporum")
                            putExtra(Intent.EXTRA_TEXT, body)
                        }
                        try {
                            context.startActivity(emailIntent)
                        } catch (_: Exception) {
                            onShowToast("Cihazda e-posta uygulaması bulunamadı.", true)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Haftalık Hatırlatma",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Switch(
                        checked = profile.weeklyReminderEnabled,
                        onCheckedChange = onToggleWeeklyReminder,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PureWhite,
                            checkedTrackColor = colors.selfGreen
                        )
                    )
                }
            }
        }

        // VERİLERİMİ SİL (2 AŞAMALI ONAY)
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                CrispSolidButton(
                    text = "Verilerimi Sil",
                    containerColor = colors.alertRed,
                    contentColor = PureWhite,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "settings_delete_all_button",
                    onClick = { deleteConfirmStep = 1 }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    if (deleteConfirmStep == 1) {
        AlertDialog(
            onDismissRequest = { deleteConfirmStep = 0 },
            containerColor = colors.cardBackground,
            title = {
                Text("1. Onay: Verileri Sil", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
            },
            text = {
                Text(
                    "Tüm verilerin silinecek, emin misin? Bu geri alınamaz.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(onClick = { deleteConfirmStep = 2 }) {
                    Text("Evet, Devam Et", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmStep = 0 }) {
                    Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                }
            }
        )
    } else if (deleteConfirmStep == 2) {
        AlertDialog(
            onDismissRequest = { deleteConfirmStep = 0 },
            containerColor = colors.cardBackground,
            title = {
                Text("2. Son Onay", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.alertRed)
            },
            text = {
                Text(
                    "Tüm kasalar, işlemler, fonlar ve kurulum bilgilerin kalıcı olarak temizlenecek. Onaylıyor musun?",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        deleteConfirmStep = 0
                        onClearAllData()
                    }
                ) {
                    Text("KALICI OLARAK SİL", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.alertRed)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmStep = 0 }) {
                    Text("Vazgeç", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                }
            }
        )
    }
}
