package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Immutable
data class SermayeColors(
    val background: Color,
    val cardBackground: Color,
    val textPrimary: Color,
    val borderColor: Color,
    val storeBlue: Color,
    val fundOrange: Color,
    val selfGreen: Color,
    val alertRed: Color,
    val summaryBg: Color,
    val summaryBorder: Color,
    val summaryText: Color,
    val disclaimerText: Color,
    val isDark: Boolean
)

val LightSermayeColors = SermayeColors(
    background = PureWhite,
    cardBackground = PureWhite,
    textPrimary = PureBlack,
    borderColor = PureBlack,
    storeBlue = StoreBlue,
    fundOrange = FundOrange,
    selfGreen = SelfGreen,
    alertRed = AlertRed,
    summaryBg = SummaryYellowLight,
    summaryBorder = PureBlack,
    summaryText = PureBlack,
    disclaimerText = DisclaimerGray,
    isDark = false
)

val DarkSermayeColors = SermayeColors(
    background = PureBlack,
    cardBackground = PureBlack,
    textPrimary = PureWhite,
    borderColor = PureWhite,
    storeBlue = StoreBlue,
    fundOrange = FundOrange,
    selfGreen = SelfGreen,
    alertRed = AlertRed,
    summaryBg = SummaryYellowDark,
    summaryBorder = SummaryYellowBorderDark,
    summaryText = PureWhite,
    disclaimerText = DisclaimerGrayDark,
    isDark = true
)

val LocalSermayeColors = staticCompositionLocalOf { LightSermayeColors }

private val SermayeLightScheme = lightColorScheme(
    primary = StoreBlue,
    onPrimary = PureWhite,
    secondary = FundOrange,
    onSecondary = PureWhite,
    tertiary = SelfGreen,
    onTertiary = PureWhite,
    error = AlertRed,
    onError = PureWhite,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = PureWhite,
    onSurfaceVariant = PureBlack,
    outline = PureBlack
)

private val SermayeDarkScheme = darkColorScheme(
    primary = StoreBlue,
    onPrimary = PureWhite,
    secondary = FundOrange,
    onSecondary = PureWhite,
    tertiary = SelfGreen,
    onTertiary = PureWhite,
    error = AlertRed,
    onError = PureWhite,
    background = PureBlack,
    onBackground = PureWhite,
    surface = PureBlack,
    onSurface = PureWhite,
    surfaceVariant = PureBlack,
    onSurfaceVariant = PureWhite,
    outline = PureWhite
)

@Composable
fun SermayeTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val sermayeColors = if (darkTheme) DarkSermayeColors else LightSermayeColors
    val materialScheme = if (darkTheme) SermayeDarkScheme else SermayeLightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !darkTheme
            insetsController.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalSermayeColors provides sermayeColors) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = SermayeTypography,
            content = content
        )
    }
}
