package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AutoBalanceSplitSliders
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.DatePickerSelectorRow
import com.example.ui.components.SermayeTextField
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils

@Composable
fun SetupScreen(
    onCompleteSetup: (
        userName: String,
        email: String,
        initialStore: Double,
        initialFund: Double,
        initialSelf: Double,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) -> Unit
) {
    val colors = LocalSermayeColors.current
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var storeInput by remember { mutableStateOf("") }
    var fundInput by remember { mutableStateOf("") }
    var selfInput by remember { mutableStateOf("") }
    var monthlyIncomeInput by remember { mutableStateOf("") }

    var storeRatio by remember { mutableIntStateOf(50) }
    var fundRatio by remember { mutableIntStateOf(40) }
    var selfRatio by remember { mutableIntStateOf(10) }

    var targetAmountInput by remember { mutableStateOf("") }
    var targetDateMillis by remember { mutableStateOf<Long?>(null) }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }

    val parsedMonthlyIncome = CurrencyUtils.parsePositiveOrZero(monthlyIncomeInput) ?: 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "SERMAYE'ye Hoş Geldin",
                fontFamily = PoppinsFontFamily,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Text(
                text = "3 dakikada kuralım, sonra paranı sen yönet.",
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary
            )

            // SORU 1: Adın ne?
            VaultCard {
                SermayeTextField(
                    value = nameInput,
                    onValueChange = {
                        nameInput = it
                        nameError = null
                    },
                    label = "1. Adın ne?",
                    placeholder = "Örn: Mehmet",
                    testTag = "setup_name_input"
                )
                if (nameError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = nameError!!,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.alertRed
                    )
                }
            }

            // SORU 2: E-postan ne?
            VaultCard {
                SermayeTextField(
                    value = emailInput,
                    onValueChange = {
                        emailInput = it
                        emailError = null
                    },
                    label = "2. E-postan ne? (İsteğe bağlı)",
                    placeholder = "Örn: mehmet@gmail.com",
                    testTag = "setup_email_input"
                )
                if (emailError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = emailError!!,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.alertRed
                    )
                }
            }

            // SORU 3: Şu an elinde ne kadar paran var?
            VaultCard {
                Text(
                    text = "3. Şu an elinde ne kadar paran var?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SermayeTextField(
                        value = storeInput,
                        onValueChange = { storeInput = it },
                        label = "Mağaza Kasası",
                        placeholder = "0",
                        isNumeric = true,
                        suffixText = "TL",
                        testTag = "setup_store_input"
                    )
                    SermayeTextField(
                        value = fundInput,
                        onValueChange = { fundInput = it },
                        label = "Fon Kasası",
                        placeholder = "0",
                        isNumeric = true,
                        suffixText = "TL",
                        testTag = "setup_fund_input"
                    )
                    SermayeTextField(
                        value = selfInput,
                        onValueChange = { selfInput = it },
                        label = "Kendine Kasası",
                        placeholder = "0",
                        isNumeric = true,
                        suffixText = "TL",
                        testTag = "setup_self_input"
                    )
                }
            }

            // SORU 4: Her ay eline ne kadar para geçiyor?
            VaultCard {
                SermayeTextField(
                    value = monthlyIncomeInput,
                    onValueChange = { monthlyIncomeInput = it },
                    label = "4. Her ay eline ne kadar para geçiyor?",
                    placeholder = "0",
                    isNumeric = true,
                    suffixText = "TL",
                    testTag = "setup_monthly_income_input"
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Aylık maaş, ek iş, her şey dahil. Boş bırakırsan 0 kabul edilir.",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            }

            // SORU 5: Paranı nasıl bölüştürelim?
            VaultCard {
                Text(
                    text = "5. Paranı nasıl bölüştürelim?",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                AutoBalanceSplitSliders(
                    storeRatio = storeRatio,
                    fundRatio = fundRatio,
                    selfRatio = selfRatio,
                    previewAmount = parsedMonthlyIncome,
                    onRatiosChanged = { s, f, k ->
                        storeRatio = s
                        fundRatio = f
                        selfRatio = k
                    }
                )
            }

            // SORU 6 (OPSİYONEL): Mağaza açmak için hedefin ne kadar?
            VaultCard {
                Text(
                    text = "6. Mağaza açmak için hedefin ne kadar? (Opsiyonel)",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                SermayeTextField(
                    value = targetAmountInput,
                    onValueChange = { targetAmountInput = it },
                    label = "Hedef Tutar",
                    placeholder = "0",
                    isNumeric = true,
                    suffixText = "TL",
                    testTag = "setup_target_amount_input"
                )
                Spacer(modifier = Modifier.height(12.dp))
                DatePickerSelectorRow(
                    label = "Hedef Tarih",
                    selectedDateMillis = targetDateMillis,
                    placeholder = "Takvimden seç (Opsiyonel)",
                    onDateSelected = { targetDateMillis = it },
                    allowClear = true
                )
            }

            CrispSolidButton(
                text = "BAŞLA - SERMAYEMİ KUR",
                containerColor = colors.selfGreen,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxWidth(),
                testTag = "setup_submit_button",
                onClick = {
                    val trimmedName = nameInput.trim()
                    val trimmedEmail = emailInput.trim()
                    var hasError = false
                    if (trimmedName.isEmpty()) {
                        nameError = "Adını yazman lazım"
                        hasError = true
                    }
                    if (!CurrencyUtils.isValidEmail(trimmedEmail)) {
                        emailError = "E-posta doğru görünmüyor"
                        hasError = true
                    }
                    if (hasError) return@CrispSolidButton

                    val sVal = CurrencyUtils.parsePositiveOrZero(storeInput) ?: 0.0
                    val fVal = CurrencyUtils.parsePositiveOrZero(fundInput) ?: 0.0
                    val kVal = CurrencyUtils.parsePositiveOrZero(selfInput) ?: 0.0
                    val mVal = CurrencyUtils.parsePositiveOrZero(monthlyIncomeInput) ?: 0.0
                    val tVal = CurrencyUtils.parsePositiveOrZero(targetAmountInput) ?: 0.0

                    onCompleteSetup(
                        trimmedName,
                        trimmedEmail,
                        sVal,
                        fVal,
                        kVal,
                        mVal,
                        storeRatio,
                        fundRatio,
                        selfRatio,
                        tVal,
                        targetDateMillis
                    )
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
