package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AssetPriceAlertRule
import com.example.data.local.FundEntity
import com.example.data.local.MarketNoteEntity
import com.example.data.local.MarketTagEntity
import com.example.data.local.TagPriceEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserProfile
import com.example.data.local.VaultType
import com.example.data.repo.AiCommentaryState
import com.example.data.repo.FirebaseAiAdvisorRepository
import com.example.data.repo.FundMarketSignal
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.LiveMarketSnapshot
import com.example.data.repo.LiveMarketUiState
import com.example.data.repo.MarketNewsItem
import com.example.data.repo.MarketNewsUiState
import com.example.data.repo.RepoResult
import com.example.data.repo.SermayeRepository
import com.example.domain.AiProfitPlan
import com.example.domain.AssetStatisticalForecast
import com.example.domain.BestScenarioResult
import com.example.domain.ChartRange
import com.example.domain.ComputedFund
import com.example.domain.FinanceEngine
import com.example.domain.FundOptionSpec
import com.example.domain.PortfolioSummary
import com.example.domain.PricePoint
import com.example.domain.RiskProfileMode
import com.example.domain.SimulationResult
import com.example.data.repo.LiveAssetQuote
import com.example.service.MarketPriceMonitorService
import com.example.util.CurrencyUtils
import com.example.util.MarketNotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.pow

enum class MainTab(val label: String) {
    HOME("Ana Sayfa"),
    FUNDS("Yatırım"),
    AI_ADVISOR("AI Danışman"),
    SIMULATION("Simülasyon"),
    MARKET_SETTINGS("Piyasa/Ayarlar")
}

enum class MarketSettingsSubTab(val label: String) {
    MARKET("Piyasa Takibi"),
    SETTINGS("Ayarlar")
}

enum class HomeModalSheet {
    ADD_INCOME,
    WITHDRAW,
    TRANSFER
}

data class ToastMessage(
    val text: String,
    val isError: Boolean = false,
    val id: Long = System.currentTimeMillis()
)

data class SimulationParams(
    val monthlyIncome: Double? = null,
    val monthlyReturnPercent: Double = 3.5,
    val months: Int = 12
)

data class SelectedNewsDetailState(
    val item: MarketNewsItem,
    val isLoadingBody: Boolean = false,
    val bodyText: String? = null
)

data class SelectedAssetDetailState(
    val id: String,
    val name: String,
    val symbol: String,
    val category: String,
    val currentPrice: Double,
    val currency: String,
    val changePercent24h: Double? = null,
    val sourceName: String = "Canlı",
    val historyKey: String = "",
    val selectedRange: ChartRange = ChartRange.THREE_MONTHS,
    val isLoadingHistory: Boolean = true,
    val historyPoints: List<PricePoint> = emptyList(),
    val historyError: String? = null,
    val statisticalForecast: AssetStatisticalForecast? = null,
    val aiForecastState: AiCommentaryState = AiCommentaryState.Idle,
    val ownedFundId: Long? = null,
    val ownedFund: ComputedFund? = null
)

data class RemoteMarketSearchState(
    val query: String = "",
    val isSearching: Boolean = false,
    val results: List<LiveAssetQuote> = emptyList()
)

data class SermayeUiState(
    val isLoaded: Boolean = false,
    val profile: UserProfile = UserProfile(),
    val summary: PortfolioSummary = FinanceEngine.buildPortfolioSummary(
        profile = UserProfile(),
        balances = com.example.data.local.VaultBalancesEntity(),
        transactions = emptyList(),
        funds = emptyList(),
        snapshots = emptyList()
    ),
    val transactions: List<TransactionEntity> = emptyList(),
    val marketTags: List<MarketTagEntity> = emptyList(),
    val tagPrices: List<TagPriceEntity> = emptyList(),
    val marketNotes: List<MarketNoteEntity> = emptyList(),
    val currentTab: MainTab = MainTab.HOME,
    val marketSettingsSubTab: MarketSettingsSubTab = MarketSettingsSubTab.MARKET,
    val showAllTransactions: Boolean = false,
    val showIncomeExpense: Boolean = false,
    val activeHomeSheet: HomeModalSheet? = null,
    val selectedRiskMode: RiskProfileMode = RiskProfileMode.BALANCED,
    val simulationParams: SimulationParams = SimulationParams(),
    val simulationResult: SimulationResult = SimulationResult(0.0, 0.0, 0.0, 0.0, 0.0, emptyList(), null),
    val bestScenarioResult: BestScenarioResult? = null,
    val aiCommentaryState: AiCommentaryState = AiCommentaryState.Idle,
    val aiProfitPlan: AiProfitPlan = FinanceEngine.buildAiProfitPlan(
        summary = FinanceEngine.buildPortfolioSummary(
            profile = UserProfile(),
            balances = com.example.data.local.VaultBalancesEntity(),
            transactions = emptyList(),
            funds = emptyList(),
            snapshots = emptyList()
        ),
        selectedRisk = RiskProfileMode.BALANCED
    ),
    val liveMarketState: LiveMarketUiState = LiveMarketUiState.Idle,
    val marketNewsState: MarketNewsUiState = MarketNewsUiState.Idle,
    val newsFundSignals: List<FundMarketSignal> = emptyList(),
    val marketAgendaAiState: AiCommentaryState = AiCommentaryState.Idle,
    val selectedNewsArticle: SelectedNewsDetailState? = null,
    val selectedAssetDetail: SelectedAssetDetailState? = null,
    val remoteSearchState: RemoteMarketSearchState = RemoteMarketSearchState(),
    val pendingInvestFundType: String? = null,
    val toastMessage: ToastMessage? = null,
    val showWeeklyReminder: Boolean = false
)

class SermayeViewModel(
    private val appContext: Context,
    private val repository: SermayeRepository,
    private val aiAdvisorRepository: FirebaseAiAdvisorRepository,
    private val liveMarketRepository: LiveMarketRepository
) : ViewModel() {

    private val currentTab = MutableStateFlow(MainTab.HOME)
    private val marketSettingsSubTab = MutableStateFlow(MarketSettingsSubTab.MARKET)
    private val showAllTransactions = MutableStateFlow(false)
    private val showIncomeExpense = MutableStateFlow(false)
    private val activeHomeSheet = MutableStateFlow<HomeModalSheet?>(null)
    private val selectedRiskMode = MutableStateFlow(RiskProfileMode.BALANCED)
    private val simulationParams = MutableStateFlow(SimulationParams())
    private val bestScenarioResult = MutableStateFlow<BestScenarioResult?>(null)
    private val aiCommentaryState = MutableStateFlow<AiCommentaryState>(AiCommentaryState.Idle)
    private val liveMarketState = MutableStateFlow<LiveMarketUiState>(LiveMarketUiState.Idle)
    private val marketNewsState = MutableStateFlow<MarketNewsUiState>(MarketNewsUiState.Idle)
    private val marketAgendaAiState = MutableStateFlow<AiCommentaryState>(AiCommentaryState.Idle)
    private val selectedNewsArticle = MutableStateFlow<SelectedNewsDetailState?>(null)
    private val selectedAssetDetail = MutableStateFlow<SelectedAssetDetailState?>(null)
    private val remoteSearchState = MutableStateFlow(RemoteMarketSearchState())
    private val pendingInvestFundType = MutableStateFlow<String?>(null)
    private val toastMessage = MutableStateFlow<ToastMessage?>(null)

    private var toastJob: Job? = null
    private var aiStreamJob: Job? = null
    private var marketFeedJob: Job? = null
    private var marketAgendaAiJob: Job? = null
    private var articleReaderJob: Job? = null
    private var assetHistoryJob: Job? = null
    private var assetAiForecastJob: Job? = null
    private var remoteSearchJob: Job? = null
    private val assetHistoryCache = mutableMapOf<String, Pair<Long, List<PricePoint>>>()
    private var hasInitializedStartupServices = false
    private var lastMarketFetchStartMs = 0L

    init {
        viewModelScope.launch {
            repository.userProfileFlow.collect { profile ->
                if (!hasInitializedStartupServices && profile.isSetupDone) {
                    hasInitializedStartupServices = true
                    val hasAnyAlerts = profile.marketAlertsEnabled || profile.assetAlerts.values.any { it.enabled }
                    if (hasAnyAlerts) {
                        MarketPriceMonitorService.schedule(appContext)
                    }
                    if (liveMarketState.value is LiveMarketUiState.Idle) {
                        refreshLiveMarketAndNews(triggerAlertCheck = hasAnyAlerts)
                    }
                }
            }
        }
    }

    private data class CoreDataBundle(
        val profile: UserProfile,
        val summary: PortfolioSummary,
        val transactions: List<TransactionEntity>,
        val tags: List<MarketTagEntity>,
        val tagPrices: List<TagPriceEntity>,
        val notes: List<MarketNoteEntity>
    )

    private val coreDataFlow = combine(
        repository.userProfileFlow,
        repository.balancesFlow,
        repository.transactionsFlow,
        repository.fundsFlow,
        repository.snapshotsFlow
    ) { profile, balances, transactions, funds, snapshots ->
        val summary = FinanceEngine.buildPortfolioSummary(
            profile = profile,
            balances = balances,
            transactions = transactions,
            funds = funds,
            snapshots = snapshots
        )
        Triple(profile, summary, transactions)
    }.combine(
        combine(
            repository.tagsFlow,
            repository.tagPricesFlow,
            repository.notesFlow
        ) { tags, prices, notes -> Triple(tags, prices, notes) }
    ) { (profile, summary, transactions), (tags, prices, notes) ->
        CoreDataBundle(profile, summary, transactions, tags, prices, notes)
    }

    private data class UiNavBundle(
        val tab: MainTab,
        val subTab: MarketSettingsSubTab,
        val allTx: Boolean,
        val incomeExpense: Boolean,
        val sheet: HomeModalSheet?,
        val risk: RiskProfileMode,
        val pendingInvestFund: String?
    )

    private val uiNavFlow = combine(
        combine(currentTab, marketSettingsSubTab, showAllTransactions, showIncomeExpense) { tab, subTab, allTx, incExp ->
            listOf(tab, subTab, allTx, incExp)
        },
        combine(activeHomeSheet, selectedRiskMode, pendingInvestFundType) { sheet, risk, pendingInvest ->
            Triple(sheet, risk, pendingInvest)
        }
    ) { left, (sheet, risk, pendingInvest) ->
        UiNavBundle(
            tab = left[0] as MainTab,
            subTab = left[1] as MarketSettingsSubTab,
            allTx = left[2] as Boolean,
            incomeExpense = left[3] as Boolean,
            sheet = sheet,
            risk = risk,
            pendingInvestFund = pendingInvest
        )
    }

    private data class MarketFeedBundle(
        val liveMarket: LiveMarketUiState,
        val marketNews: MarketNewsUiState,
        val marketAgendaAi: AiCommentaryState,
        val selectedArticle: SelectedNewsDetailState?,
        val selectedAsset: SelectedAssetDetailState?,
        val remoteSearch: RemoteMarketSearchState
    )

    private val marketFeedFlow = combine(
        combine(liveMarketState, marketNewsState, marketAgendaAiState) { live, news, agendaAi ->
            Triple(live, news, agendaAi)
        },
        combine(selectedNewsArticle, selectedAssetDetail, remoteSearchState) { article, asset, remoteSearch ->
            Triple(article, asset, remoteSearch)
        }
    ) { (live, news, agendaAi), (article, asset, remoteSearch) ->
        MarketFeedBundle(live, news, agendaAi, article, asset, remoteSearch)
    }

    val uiState: StateFlow<SermayeUiState> = combine(
        coreDataFlow,
        uiNavFlow,
        simulationParams,
        bestScenarioResult,
        aiCommentaryState,
        marketFeedFlow,
        toastMessage
    ) { arr ->
        val core = arr[0] as CoreDataBundle
        val nav = arr[1] as UiNavBundle
        val simParams = arr[2] as SimulationParams
        val bestScenario = arr[3] as BestScenarioResult?
        val aiState = arr[4] as AiCommentaryState
        val marketFeed = arr[5] as MarketFeedBundle
        val toast = arr[6] as ToastMessage?

        val newsItems = (marketFeed.marketNews as? MarketNewsUiState.Ready)?.items.orEmpty()
        val newsSignals = if (newsItems.isNotEmpty()) {
            LiveMarketRepository.aggregateFundSignals(newsItems)
        } else {
            emptyList()
        }
        val signalScoreMap = newsSignals.associate { it.fundName to it.netScore }
        val liveSnap = (marketFeed.liveMarket as? LiveMarketUiState.Ready)?.snapshot
        val assetChangesMap = liveSnap?.assets
            ?.mapNotNull { a -> a.changePercent24h?.let { a.id to it } }
            ?.toMap()
            ?: emptyMap()

        val aiProfitPlan = FinanceEngine.buildAiProfitPlan(
            summary = core.summary,
            selectedRisk = nav.risk,
            fundSignalScores = signalScoreMap,
            marketAssetChanges = assetChangesMap
        )

        val effectiveSimIncome = simParams.monthlyIncome
            ?: if (core.profile.monthlyIncome > 0.0) core.profile.monthlyIncome else 1000.0
        val simResult = FinanceEngine.simulateFutureValue(
            currentWealth = core.summary.totalWealth,
            currentFundVault = core.summary.totalFundVault,
            monthlyIncome = effectiveSimIncome,
            fundRatioPercent = core.profile.fundRatio,
            monthlyReturnPercent = simParams.monthlyReturnPercent,
            months = simParams.months,
            storeTargetAmount = core.profile.storeTargetAmount,
            storeBalance = core.summary.storeBalance,
            storeRatioPercent = core.profile.storeRatio
        )

        val todayDay = CurrencyUtils.currentEpochDay()
        val shouldShowReminder = core.profile.isSetupDone &&
            core.profile.weeklyReminderEnabled &&
            (todayDay - core.profile.lastReminderDismissedEpochDay) >= 7L

        val mergedSelectedAsset = marketFeed.selectedAsset?.let { detail ->
            val allLiveQuotes = (liveSnap?.assets.orEmpty() + liveSnap?.topFunds.orEmpty())
            val liveMatch = allLiveQuotes.firstOrNull { it.id == detail.id }
            val liveOwned = detail.ownedFundId?.let { fid ->
                core.summary.computedFunds.firstOrNull { it.entity.id == fid }
            }
            val updatedPrice = liveMatch?.price ?: liveOwned?.currentValue ?: detail.currentPrice
            val updatedChange = liveMatch?.changePercent24h ?: detail.changePercent24h
            val updatedForecast = if (detail.statisticalForecast != null &&
                updatedPrice > 0.0 &&
                kotlin.math.abs(updatedPrice - detail.statisticalForecast.currentPrice) > 0.01
            ) {
                FinanceEngine.buildAssetForecast(
                    points = detail.historyPoints,
                    currentPrice = updatedPrice,
                    currency = detail.currency,
                    fallbackMonthlyReturnPercent = liveOwned?.entity?.monthlyReturnPercent
                )
            } else {
                detail.statisticalForecast
            }
            detail.copy(
                currentPrice = updatedPrice,
                changePercent24h = updatedChange,
                ownedFund = liveOwned ?: detail.ownedFund,
                statisticalForecast = updatedForecast
            )
        }

        SermayeUiState(
            isLoaded = true,
            profile = core.profile,
            summary = core.summary,
            transactions = core.transactions,
            marketTags = core.tags,
            tagPrices = core.tagPrices,
            marketNotes = core.notes,
            currentTab = nav.tab,
            marketSettingsSubTab = nav.subTab,
            showAllTransactions = nav.allTx,
            showIncomeExpense = nav.incomeExpense,
            activeHomeSheet = nav.sheet,
            selectedRiskMode = nav.risk,
            simulationParams = simParams.copy(monthlyIncome = effectiveSimIncome),
            simulationResult = simResult,
            bestScenarioResult = bestScenario,
            aiCommentaryState = aiState,
            aiProfitPlan = aiProfitPlan,
            liveMarketState = marketFeed.liveMarket,
            marketNewsState = marketFeed.marketNews,
            newsFundSignals = newsSignals,
            marketAgendaAiState = marketFeed.marketAgendaAi,
            selectedNewsArticle = marketFeed.selectedArticle,
            selectedAssetDetail = mergedSelectedAsset,
            remoteSearchState = marketFeed.remoteSearch,
            pendingInvestFundType = nav.pendingInvestFund,
            toastMessage = toast,
            showWeeklyReminder = shouldShowReminder
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SermayeUiState(isLoaded = false)
    )

    fun selectTab(tab: MainTab) {
        showAllTransactions.value = false
        showIncomeExpense.value = false
        currentTab.value = tab
        if ((tab == MainTab.MARKET_SETTINGS || tab == MainTab.AI_ADVISOR || tab == MainTab.FUNDS) &&
            (liveMarketState.value is LiveMarketUiState.Idle || marketNewsState.value is MarketNewsUiState.Idle)
        ) {
            val profile = uiState.value.profile
            val hasAlerts = profile.marketAlertsEnabled || profile.assetAlerts.values.any { it.enabled }
            refreshLiveMarketAndNews(triggerAlertCheck = hasAlerts)
        }
    }

    fun openSettings() {
        showAllTransactions.value = false
        showIncomeExpense.value = false
        marketSettingsSubTab.value = MarketSettingsSubTab.SETTINGS
        currentTab.value = MainTab.MARKET_SETTINGS
    }

    fun openMarketPopular30() {
        showAllTransactions.value = false
        showIncomeExpense.value = false
        marketSettingsSubTab.value = MarketSettingsSubTab.MARKET
        selectTab(MainTab.MARKET_SETTINGS)
    }

    fun selectMarketSettingsSubTab(subTab: MarketSettingsSubTab) {
        marketSettingsSubTab.value = subTab
    }

    fun openAllTransactions() {
        showIncomeExpense.value = false
        showAllTransactions.value = true
    }

    fun closeAllTransactions() {
        showAllTransactions.value = false
    }

    fun openIncomeExpense() {
        showAllTransactions.value = false
        showIncomeExpense.value = true
    }

    fun closeIncomeExpense() {
        showIncomeExpense.value = false
    }

    fun openHomeSheet(sheet: HomeModalSheet) {
        activeHomeSheet.value = sheet
    }

    fun closeHomeSheet() {
        activeHomeSheet.value = null
    }

    fun toggleDarkMode(isDark: Boolean) {
        viewModelScope.launch { repository.setDarkMode(isDark) }
    }

    fun dismissWeeklyReminder() {
        viewModelScope.launch {
            repository.dismissWeeklyReminder(CurrencyUtils.currentEpochDay())
        }
    }

    fun setWeeklyReminderEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setWeeklyReminderEnabled(enabled)
            showToast(if (enabled) "Haftalık hatırlatma açıldı" else "Haftalık hatırlatma kapatıldı")
        }
    }

    fun completeSetup(
        userName: String,
        email: String,
        initialStore: Double,
        initialFund: Double,
        initialSelf: Double,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) {
        viewModelScope.launch {
            repository.completeSetup(
                userName = userName,
                email = email,
                initialStore = initialStore,
                initialFund = initialFund,
                initialSelf = initialSelf,
                monthlyIncome = monthlyIncome,
                storeRatio = storeRatio,
                fundRatio = fundRatio,
                selfRatio = selfRatio,
                storeTargetAmount = storeTargetAmount,
                storeTargetDateMillis = storeTargetDateMillis
            )
            simulationParams.value = SimulationParams(
                monthlyIncome = if (monthlyIncome > 0.0) monthlyIncome else 1000.0
            )
        }
    }

    fun addIncome(
        amount: Double,
        source: String,
        note: String,
        dateMillis: Long,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.addIncome(amount, source, note, dateMillis, storeRatio, fundRatio, selfRatio)) {
                is RepoResult.Success -> {
                    val (s, f, k) = res.data
                    activeHomeSheet.value = null
                    onSuccess()
                    showToast(
                        "✅ ${CurrencyUtils.formatTL(amount)} eklendi. " +
                            "Mağaza +${CurrencyUtils.formatTL(s)}, Fon +${CurrencyUtils.formatTL(f)}, Kendine +${CurrencyUtils.formatTL(k)}"
                    )
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun withdrawFromVault(
        vault: VaultType,
        amount: Double,
        category: String,
        note: String,
        dateMillis: Long,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.withdrawFromVault(vault, amount, category, note, dateMillis)) {
                is RepoResult.Success -> {
                    activeHomeSheet.value = null
                    onSuccess()
                    showToast("✅ ${CurrencyUtils.formatTL(amount)} çıkarıldı")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun transferBetweenVaults(
        from: VaultType,
        to: VaultType,
        amount: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.transferBetweenVaults(from, to, amount)) {
                is RepoResult.Success -> {
                    activeHomeSheet.value = null
                    onSuccess()
                    showToast("✅ ${CurrencyUtils.formatTL(amount)} transfer edildi")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            when (val res = repository.deleteTransactionAndReverse(tx)) {
                is RepoResult.Success -> showToast("✅ İşlem silindi ve kasa bakiyesi düzeltildi")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun investInFund(
        fundType: String,
        riskLabel: String,
        amount: Double,
        monthlyReturnPercent: Double,
        purchaseDateMillis: Long,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            when (val res = repository.investInFund(fundType, riskLabel, amount, monthlyReturnPercent, purchaseDateMillis)) {
                is RepoResult.Success -> {
                    onSuccess()
                    showToast("✅ $fundType yatırımı yapıldı (${CurrencyUtils.formatTL(amount)})")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun updateFundValue(fund: FundEntity, newValue: Double) {
        viewModelScope.launch {
            when (val res = repository.updateFundManualValue(fund, newValue)) {
                is RepoResult.Success -> showToast("✅ ${fund.fundType} değeri güncellendi")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun sellFund(fund: FundEntity, currentValue: Double) {
        viewModelScope.launch {
            when (val res = repository.sellFund(fund, currentValue)) {
                is RepoResult.Success -> showToast("✅ ${fund.fundType} satıldı (+${CurrencyUtils.formatTL(res.data)})")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun addMonthlyFundYield() {
        viewModelScope.launch {
            val lastYm = uiState.value.profile.lastMonthlyYieldAddedYm
            when (val res = repository.addMonthlyFundYield(lastYm)) {
                is RepoResult.Success -> showToast("✅ Bu ayın fon getirisi eklendi: +${CurrencyUtils.formatTL(res.data)}")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun selectRiskMode(mode: RiskProfileMode) {
        selectedRiskMode.value = mode
    }

    fun applyAiRiskAllocation(sellExistingFirst: Boolean) {
        viewModelScope.launch {
            val mode = selectedRiskMode.value
            when (val res = repository.applyAiRiskAllocation(mode, sellExistingFirst)) {
                is RepoResult.Success -> showToast("✅ ${mode.shortTitle} dağılımı uygulandı (${res.data} fon)")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun applySmartProfitPlan(sellExistingFirst: Boolean) {
        viewModelScope.launch {
            val plan = uiState.value.aiProfitPlan
            when (val res = repository.applyCustomAllocation(
                allocations = plan.smartAllocations,
                planLabel = plan.strategyTitle,
                sellExistingFirst = sellExistingFirst
            )) {
                is RepoResult.Success -> showToast("✅ Akıllı AI kâr planı uygulandı (${res.data} fon)")
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun requestGeminiAdvice() {
        val current = uiState.value
        val snapshot = (current.liveMarketState as? LiveMarketUiState.Ready)?.snapshot
        val news = (current.marketNewsState as? MarketNewsUiState.Ready)?.items.orEmpty()
        aiStreamJob?.cancel()
        aiStreamJob = viewModelScope.launch {
            aiAdvisorRepository.streamPersonalizedAdvice(
                profile = current.profile,
                summary = current.summary,
                selectedRisk = current.selectedRiskMode,
                profitPlan = current.aiProfitPlan,
                liveSnapshot = snapshot,
                news = news
            ).collect { state ->
                aiCommentaryState.value = state
            }
        }
    }

    fun updateSimulationParams(monthlyIncome: Double, monthlyReturnPercent: Double, months: Int) {
        simulationParams.value = SimulationParams(
            monthlyIncome = monthlyIncome,
            monthlyReturnPercent = monthlyReturnPercent,
            months = months
        )
        bestScenarioResult.value = null
    }

    fun findBestSimulationScenario() {
        val state = uiState.value
        val income = state.simulationParams.monthlyIncome ?: state.profile.monthlyIncome.coerceAtLeast(1000.0)
        bestScenarioResult.value = FinanceEngine.findBestScenario(
            currentWealth = state.summary.totalWealth,
            currentFundVault = state.summary.totalFundVault,
            monthlyIncome = income,
            months = state.simulationParams.months
        )
    }

    fun refreshLiveMarketAndNews(
        triggerAlertCheck: Boolean = false,
        sendImmediateSnapshotNotice: Boolean = false
    ) {
        val nowMs = System.currentTimeMillis()
        if (!sendImmediateSnapshotNotice &&
            marketFeedJob?.isActive == true &&
            (nowMs - lastMarketFetchStartMs) < 3_000L
        ) {
            return
        }
        lastMarketFetchStartMs = nowMs
        marketFeedJob?.cancel()
        marketFeedJob = viewModelScope.launch {
            if (liveMarketState.value !is LiveMarketUiState.Ready) {
                liveMarketState.value = LiveMarketUiState.Loading
            }
            if (marketNewsState.value !is MarketNewsUiState.Ready) {
                marketNewsState.value = MarketNewsUiState.Loading
            }

            val (marketRes, newsRes) = coroutineScope {
                val m = async { liveMarketRepository.fetchLiveMarket() }
                val n = async { liveMarketRepository.fetchMarketNews() }
                m.await() to n.await()
            }

            val snapshot = marketRes.getOrNull()
            if (snapshot != null) {
                liveMarketState.value = LiveMarketUiState.Ready(snapshot)
            } else if (liveMarketState.value !is LiveMarketUiState.Ready) {
                liveMarketState.value = LiveMarketUiState.Error(
                    marketRes.exceptionOrNull()?.localizedMessage
                        ?: "Canlı piyasa verileri alınamadı. İnternetini kontrol et."
                )
            }

            val newsItems = newsRes.getOrNull()
            if (newsItems != null) {
                marketNewsState.value = MarketNewsUiState.Ready(newsItems)
            } else if (marketNewsState.value !is MarketNewsUiState.Ready) {
                marketNewsState.value = MarketNewsUiState.Error(
                    newsRes.exceptionOrNull()?.localizedMessage
                        ?: "Gündem haberleri yüklenemedi."
                )
            }

            if (snapshot != null) {
                val profile = uiState.value.profile
                if (sendImmediateSnapshotNotice) {
                    if (!MarketNotificationHelper.hasNotificationPermission(appContext)) {
                        showToast("Bildirim izni verilmedi. Lütfen bildirim iznini aç.", isError = true)
                    } else {
                        val summaryLines = buildSnapshotNotificationLines(snapshot)
                        val posted = MarketNotificationHelper.postMarketNotification(
                            context = appContext,
                            notificationId = 1000,
                            title = "SERMAYE Canlı Piyasa Özeti",
                            body = summaryLines
                        )
                        seedBaselinePrices(snapshot)
                        if (posted) {
                            showToast("✅ Canlı piyasa bildirimi telefonuna gönderildi")
                        } else {
                            showToast("Bildirim gönderilemedi", isError = true)
                        }
                    }
                } else if (triggerAlertCheck && (profile.marketAlertsEnabled || profile.assetAlerts.values.any { it.enabled })) {
                    val sent = MarketPriceMonitorService.evaluateAndNotify(
                        context = appContext,
                        prefs = repository.preferencesStore(),
                        snapshot = snapshot,
                        thresholdPercent = profile.alertThresholdPercent,
                        lastGold = profile.lastAlertGoldPrice,
                        lastBtc = profile.lastAlertBtcPrice,
                        lastTopFund = profile.lastAlertTopFundPrice,
                        globalEnabled = profile.marketAlertsEnabled,
                        customRules = profile.assetAlerts.values.toList()
                    )
                    if (sent > 0) {
                        showToast("🔔 $sent adet fiyat hareketi bildirimi gönderildi")
                    }
                }
            } else if (sendImmediateSnapshotNotice) {
                showToast("Piyasa verisi alınamadığı için bildirim gönderilemedi", isError = true)
            }
        }
    }

    private fun buildSnapshotNotificationLines(snapshot: LiveMarketSnapshot): String {
        val parts = mutableListOf<String>()
        snapshot.assets.firstOrNull { it.id == "gram_altin" }?.let { gold ->
            val chg = gold.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
            parts.add("Gram Altın: ${CurrencyUtils.formatTL(gold.price)}$chg")
        }
        snapshot.assets.firstOrNull { it.id == "bitcoin" }?.let { btc ->
            val chg = btc.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
            parts.add("Bitcoin: ${CurrencyUtils.formatTL(btc.price)}$chg")
        }
        val topFund = snapshot.topFunds.firstOrNull { it.symbol == "GLD" }
            ?: snapshot.topFunds.firstOrNull { it.symbol == "SPY" }
            ?: snapshot.topFunds.firstOrNull()
        if (topFund != null) {
            val chg = topFund.changePercent24h?.let { " (${CurrencyUtils.formatSignedPercent(it)})" } ?: ""
            parts.add("${topFund.symbol}: ${CurrencyUtils.formatForeignPrice(topFund.price, topFund.currency)}$chg")
        }
        return if (parts.isEmpty()) "Güncel piyasa verileri hazır." else parts.joinToString(" • ")
    }

    private suspend fun seedBaselinePrices(snapshot: LiveMarketSnapshot) {
        val gold = snapshot.assets.firstOrNull { it.id == "gram_altin" }?.price ?: 0.0
        val btc = snapshot.assets.firstOrNull { it.id == "bitcoin" }?.price ?: 0.0
        val topFund = (snapshot.topFunds.firstOrNull { it.symbol == "GLD" }
            ?: snapshot.topFunds.firstOrNull { it.symbol == "SPY" }
            ?: snapshot.topFunds.firstOrNull())?.price ?: 0.0
        repository.saveLastAlertPrices(gold, btc, topFund)
    }

    fun openNewsArticle(item: MarketNewsItem) {
        articleReaderJob?.cancel()
        selectedNewsArticle.value = SelectedNewsDetailState(item = item, isLoadingBody = true, bodyText = null)
        articleReaderJob = viewModelScope.launch {
            val body = liveMarketRepository.fetchArticleBodyText(item.link)
            if (selectedNewsArticle.value?.item == item) {
                selectedNewsArticle.value = SelectedNewsDetailState(
                    item = item,
                    isLoadingBody = false,
                    bodyText = body
                )
            }
        }
    }

    fun closeNewsArticle() {
        articleReaderJob?.cancel()
        selectedNewsArticle.value = null
    }

    fun openLiveAssetDetail(quote: LiveAssetQuote) {
        openAssetDetailInternal(
            id = quote.id,
            name = quote.name,
            symbol = quote.symbol,
            category = quote.category,
            currentPrice = quote.price,
            currency = quote.currency,
            changePercent24h = quote.changePercent24h,
            sourceName = quote.sourceName,
            historyKey = quote.historyKey,
            ownedFund = null,
            sparklinePrices = quote.sparklinePrices
        )
    }

    fun openUserFundDetail(fund: ComputedFund) {
        val benchmarkId = LiveMarketRepository.resolveBenchmarkQuoteIdForFundName(fund.entity.fundType)
        val snap = (liveMarketState.value as? LiveMarketUiState.Ready)?.snapshot
        val benchmarkQuote = (snap?.assets.orEmpty() + snap?.topFunds.orEmpty())
            .firstOrNull { it.id == benchmarkId }

        openAssetDetailInternal(
            id = benchmarkQuote?.id ?: benchmarkId,
            name = fund.entity.fundType,
            symbol = benchmarkQuote?.symbol ?: fund.entity.riskLabel,
            category = "Yatırımım (${fund.entity.riskLabel})",
            currentPrice = benchmarkQuote?.price ?: fund.currentValue,
            currency = benchmarkQuote?.currency ?: "TL",
            changePercent24h = benchmarkQuote?.changePercent24h ?: fund.profitPercent,
            sourceName = benchmarkQuote?.sourceName ?: "Fon Hesabı",
            historyKey = benchmarkQuote?.historyKey.orEmpty(),
            ownedFund = fund,
            fallbackMonthlyRate = fund.entity.monthlyReturnPercent,
            sparklinePrices = benchmarkQuote?.sparklinePrices.orEmpty()
        )
    }

    fun openFundOptionSetDetail(option: FundOptionSpec) {
        val benchmarkId = LiveMarketRepository.resolveBenchmarkQuoteIdForFundName(option.name)
        val snap = (liveMarketState.value as? LiveMarketUiState.Ready)?.snapshot
        val benchmarkQuote = (snap?.assets.orEmpty() + snap?.topFunds.orEmpty())
            .firstOrNull { it.id == benchmarkId }

        openAssetDetailInternal(
            id = benchmarkQuote?.id ?: benchmarkId,
            name = option.name,
            symbol = benchmarkQuote?.symbol ?: option.riskLabel,
            category = "Yatırım Seti (${option.riskLabel})",
            currentPrice = benchmarkQuote?.price ?: 1000.0,
            currency = benchmarkQuote?.currency ?: "TL",
            changePercent24h = benchmarkQuote?.changePercent24h ?: option.defaultMonthlyReturnPercent,
            sourceName = benchmarkQuote?.sourceName ?: "Gösterge Fon",
            historyKey = benchmarkQuote?.historyKey.orEmpty(),
            ownedFund = null,
            fallbackMonthlyRate = option.defaultMonthlyReturnPercent,
            sparklinePrices = benchmarkQuote?.sparklinePrices.orEmpty()
        )
    }

    private fun openAssetDetailInternal(
        id: String,
        name: String,
        symbol: String,
        category: String,
        currentPrice: Double,
        currency: String,
        changePercent24h: Double?,
        sourceName: String,
        historyKey: String,
        ownedFund: ComputedFund?,
        fallbackMonthlyRate: Double? = ownedFund?.entity?.monthlyReturnPercent,
        sparklinePrices: List<Double> = emptyList()
    ) {
        assetHistoryJob?.cancel()
        assetAiForecastJob?.cancel()

        val initialState = SelectedAssetDetailState(
            id = id,
            name = name,
            symbol = symbol,
            category = category,
            currentPrice = currentPrice,
            currency = currency,
            changePercent24h = changePercent24h,
            sourceName = sourceName,
            historyKey = historyKey,
            selectedRange = ChartRange.THREE_MONTHS,
            isLoadingHistory = true,
            ownedFundId = ownedFund?.entity?.id,
            ownedFund = ownedFund
        )
        selectedAssetDetail.value = initialState

        assetHistoryJob = viewModelScope.launch {
            val now = System.currentTimeMillis()
            val cached = assetHistoryCache[id]
            val fetchedPoints: List<PricePoint> = if (cached != null && (now - cached.first) < 5 * 60_000L) {
                cached.second
            } else {
                val res = liveMarketRepository.fetchAssetHistory(id, symbol, currentPrice, historyKey)
                val fetched = res.getOrNull().orEmpty()
                if (fetched.size >= 2) {
                    assetHistoryCache[id] = now to fetched
                }
                fetched
            }

            var usedFallbackNote: String? = null
            val points: List<PricePoint> = if (fetchedPoints.size >= 2) {
                fetchedPoints
            } else {
                usedFallbackNote = when {
                    fallbackMonthlyRate != null ->
                        "Canlı geçmiş seri şu an alınamadı; aylık %${CurrencyUtils.formatEditableNumber(fallbackMonthlyRate)} bileşik performans eğrisi gösteriliyor."
                    sparklinePrices.size >= 2 ->
                        "Yıllık seri geçici olarak alınamadı; son piyasa fiyat trendi gösteriliyor."
                    else ->
                        "Yıllık seri geçici olarak alınamadı; güncel 24s değişim trendi gösteriliyor."
                }
                buildFallbackHistoryPoints(
                    currentPrice = currentPrice,
                    changePercent24h = changePercent24h,
                    fallbackMonthlyRate = fallbackMonthlyRate,
                    sparklinePrices = sparklinePrices,
                    nowMillis = now
                )
            }

            val statForecast = FinanceEngine.buildAssetForecast(
                points = points,
                currentPrice = currentPrice,
                currency = currency,
                fallbackMonthlyReturnPercent = fallbackMonthlyRate ?: ownedFund?.entity?.monthlyReturnPercent
            )

            val updated = selectedAssetDetail.value
            if (updated != null && updated.id == id && updated.ownedFundId == ownedFund?.entity?.id) {
                val withData = updated.copy(
                    isLoadingHistory = false,
                    historyPoints = points,
                    historyError = usedFallbackNote,
                    statisticalForecast = statForecast
                )
                selectedAssetDetail.value = withData
                streamForecastForDetail(withData)
            }
        }
    }

    private fun buildFallbackHistoryPoints(
        currentPrice: Double,
        changePercent24h: Double?,
        fallbackMonthlyRate: Double?,
        sparklinePrices: List<Double>,
        nowMillis: Long
    ): List<PricePoint> {
        val dayMs = 24L * 60L * 60L * 1000L
        if (sparklinePrices.size >= 2) {
            val stepDays = maxOf(1L, 30L / sparklinePrices.size.coerceAtLeast(2))
            val total = sparklinePrices.size
            return sparklinePrices.mapIndexed { idx, p ->
                val ts = nowMillis - (total - 1 - idx).toLong() * stepDays * dayMs
                PricePoint(ts, CurrencyUtils.formatDayMonth(ts), p)
            }
        }
        val safeEnd = currentPrice.takeIf { it > 0.0 } ?: 1000.0
        if (fallbackMonthlyRate != null) {
            val monthly = (fallbackMonthlyRate / 100.0).coerceIn(-0.5, 0.5)
            // Build 365-day trajectory ending cleanly at safeEnd
            val steps = 72
            return (0..steps).map { idx ->
                val progressFromEnd = (steps - idx).toDouble() / steps.toDouble()
                val monthsBack = progressFromEnd * 12.0
                val factor = (1.0 + monthly).pow(monthsBack).coerceAtLeast(0.05)
                val price = safeEnd / factor
                val ts = nowMillis - ((steps - idx).toLong() * 5L * dayMs)
                PricePoint(ts, CurrencyUtils.formatDayMonth(ts), price)
            }
        }
        val chg = changePercent24h ?: 0.0
        val denom = (1.0 + chg / 100.0).takeIf { it > 0.05 } ?: 1.0
        val prev = safeEnd / denom
        val offsets = listOf(0.0, 0.3, 0.65, 1.0)
        return offsets.mapIndexed { idx, f ->
            val ts = nowMillis - (offsets.lastIndex - idx).toLong() * dayMs
            val p = prev + (safeEnd - prev) * f
            PricePoint(ts, CurrencyUtils.formatDayMonth(ts), p)
        }
    }

    fun selectAssetChartRange(range: ChartRange) {
        val current = selectedAssetDetail.value ?: return
        selectedAssetDetail.value = current.copy(selectedRange = range)
    }

    fun regenerateSelectedAssetAiForecast() {
        val current = selectedAssetDetail.value ?: return
        streamForecastForDetail(current)
    }

    private fun streamForecastForDetail(detail: SelectedAssetDetailState) {
        val statForecast = detail.statisticalForecast ?: FinanceEngine.buildAssetForecast(
            points = detail.historyPoints,
            currentPrice = detail.currentPrice,
            currency = detail.currency,
            fallbackMonthlyReturnPercent = detail.ownedFund?.entity?.monthlyReturnPercent
        )
        val allNews = (marketNewsState.value as? MarketNewsUiState.Ready)?.items.orEmpty()
        val relevantNews = allNews.filter { item ->
            val txt = (item.title + " " + item.summary + " " + item.fundImpact.affectedFunds.joinToString(" ")).lowercase()
            when {
                detail.name.contains("Altın", ignoreCase = true) || detail.id.contains("altin") || detail.symbol in listOf("GLD", "ZGOLD.IS", "GC=F") ->
                    txt.contains("altın") || txt.contains("ons") || txt.contains("gld")
                detail.name.contains("Bitcoin", ignoreCase = true) || detail.id == "bitcoin" || detail.symbol == "IBIT" || detail.name.contains("Ethereum", ignoreCase = true) || detail.name.contains("Solana", ignoreCase = true) ->
                    txt.contains("bitcoin") || txt.contains("kripto") || txt.contains("btc") || txt.contains("coin")
                detail.name.contains("BIST", ignoreCase = true) || detail.name.contains("Hisse", ignoreCase = true) || detail.symbol in listOf("XU100.IS", "SPY", "QQQ", "TUR") ->
                    txt.contains("borsa") || txt.contains("bist") || txt.contains("hisse") || txt.contains("endeks")
                else -> true
            }
        }.ifEmpty { allNews.take(3) }

        val holdingSummary = detail.ownedFund?.let { f ->
            "Yatırılan ${CurrencyUtils.formatTL(f.entity.investedAmount)}, Güncel Değer ${CurrencyUtils.formatTL(f.currentValue)}, " +
                "Kâr/Zarar ${CurrencyUtils.formatSignedTL(f.profitTL)} (${CurrencyUtils.formatSignedPercent(f.profitPercent)}), " +
                "Aylık Getiri Beklentisi %${f.entity.monthlyReturnPercent}"
        }

        assetAiForecastJob?.cancel()
        assetAiForecastJob = viewModelScope.launch {
            aiAdvisorRepository.streamAssetForecast(
                assetName = detail.name,
                symbol = detail.symbol,
                category = detail.category,
                currentPrice = detail.currentPrice,
                currency = detail.currency,
                change24hPercent = detail.changePercent24h,
                statForecast = statForecast,
                relevantNews = relevantNews,
                userHoldingSummary = holdingSummary
            ).collect { aiState ->
                val active = selectedAssetDetail.value
                if (active != null && active.id == detail.id && active.ownedFundId == detail.ownedFundId) {
                    selectedAssetDetail.value = active.copy(aiForecastState = aiState)
                }
            }
        }
    }

    fun closeAssetDetail() {
        assetHistoryJob?.cancel()
        assetAiForecastJob?.cancel()
        selectedAssetDetail.value = null
    }

    fun openFundsToInvest(suggestedFundType: String) {
        closeAssetDetail()
        pendingInvestFundType.value = suggestedFundType
        selectTab(MainTab.FUNDS)
    }

    fun consumePendingInvestFundType() {
        pendingInvestFundType.value = null
    }

    fun searchRemoteMarket(rawQuery: String) {
        val trimmed = rawQuery.trim()
        remoteSearchJob?.cancel()
        if (trimmed.length < 2) {
            remoteSearchState.value = RemoteMarketSearchState()
            return
        }
        remoteSearchState.value = RemoteMarketSearchState(
            query = trimmed,
            isSearching = true,
            results = emptyList()
        )
        remoteSearchJob = viewModelScope.launch {
            delay(450L)
            val res = liveMarketRepository.searchRemoteMarketAssets(trimmed)
            val items = res.getOrNull().orEmpty()
            if (remoteSearchState.value.query == trimmed) {
                remoteSearchState.value = RemoteMarketSearchState(
                    query = trimmed,
                    isSearching = false,
                    results = items
                )
            }
        }
    }

    fun clearRemoteMarketSearch() {
        remoteSearchJob?.cancel()
        remoteSearchState.value = RemoteMarketSearchState()
    }

    fun summarizeMarketAgendaWithAi() {
        val current = uiState.value
        val snapshot = (current.liveMarketState as? LiveMarketUiState.Ready)?.snapshot
        val news: List<MarketNewsItem> = (current.marketNewsState as? MarketNewsUiState.Ready)?.items.orEmpty()
        marketAgendaAiJob?.cancel()
        marketAgendaAiJob = viewModelScope.launch {
            aiAdvisorRepository.streamMarketAgendaSummary(
                snapshot = snapshot,
                news = news,
                signals = current.newsFundSignals,
                summary = if (current.profile.isSetupDone) current.summary else null
            ).collect { state ->
                marketAgendaAiState.value = state
            }
        }
    }

    fun setMarketAlertsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setMarketAlertsEnabled(enabled)
            if (enabled) {
                MarketPriceMonitorService.schedule(appContext)
                val snapshot = (liveMarketState.value as? LiveMarketUiState.Ready)?.snapshot
                if (snapshot != null) {
                    seedBaselinePrices(snapshot)
                }
                showToast("🔔 Altın, Bitcoin ve fon fiyat bildirimleri açıldı")
            } else {
                val hasCustom = uiState.value.profile.assetAlerts.values.any { it.enabled }
                if (!hasCustom) {
                    MarketPriceMonitorService.cancel(appContext)
                }
                showToast("Genel piyasa bildirimleri kapatıldı")
            }
        }
    }

    fun setAlertThresholdPercent(threshold: Double) {
        viewModelScope.launch {
            repository.setAlertThresholdPercent(threshold)
            showToast("Bildirim eşiği ${CurrencyUtils.formatPercent(threshold)} olarak ayarlandı")
        }
    }

    fun toggleFavoriteAsset(assetId: String, assetName: String) {
        viewModelScope.launch {
            val added = repository.toggleFavoriteAsset(assetId)
            showToast(
                if (added) "⭐ $assetName favorilere eklendi"
                else "$assetName favorilerden çıkarıldı"
            )
        }
    }

    fun enableAssetPriceAlert(
        assetId: String,
        assetName: String,
        symbol: String,
        currentPrice: Double,
        currency: String,
        thresholdPercent: Double
    ) {
        viewModelScope.launch {
            val safePct = thresholdPercent.coerceIn(0.1, 100.0)
            val snap = (liveMarketState.value as? LiveMarketUiState.Ready)?.snapshot
            val livePrice = (snap?.assets.orEmpty() + snap?.topFunds.orEmpty())
                .firstOrNull { it.id == assetId }
                ?.price
                ?.takeIf { it > 0.0 }
                ?: currentPrice.coerceAtLeast(0.0)
            repository.saveAssetAlert(
                AssetPriceAlertRule(
                    assetId = assetId,
                    assetName = assetName,
                    symbol = symbol,
                    currency = currency,
                    thresholdPercent = safePct,
                    baselinePrice = livePrice,
                    enabled = true
                )
            )
            MarketPriceMonitorService.schedule(appContext)
            showToast("🔔 $assetName için ±${CurrencyUtils.formatPercent(safePct)} değişimde bildirim açıldı")
        }
    }

    fun disableAssetPriceAlert(assetId: String, assetName: String) {
        viewModelScope.launch {
            repository.removeAssetAlert(assetId)
            val profile = uiState.value.profile
            val remainingEnabled = profile.assetAlerts.filterKeys { it != assetId }.values.any { it.enabled }
            if (!profile.marketAlertsEnabled && !remainingEnabled) {
                MarketPriceMonitorService.cancel(appContext)
            }
            showToast("🔕 $assetName fiyat bildirimi kapatıldı")
        }
    }

    fun addMarketTag(rawTag: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            when (val res = repository.addMarketTag(rawTag)) {
                is RepoResult.Success -> {
                    onSuccess()
                    showToast("✅ Etiket eklendi")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun deleteMarketTag(tagId: Long) {
        viewModelScope.launch {
            repository.deleteMarketTag(tagId)
            showToast("✅ Etiket silindi")
        }
    }

    fun addTagPrice(tagId: Long, price: Double, onSuccess: () -> Unit) {
        viewModelScope.launch {
            when (val res = repository.addTagPrice(tagId, price)) {
                is RepoResult.Success -> {
                    onSuccess()
                    showToast("✅ Fiyat kaydedildi")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun addMarketNote(content: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            when (val res = repository.addMarketNote(content)) {
                is RepoResult.Success -> {
                    onSuccess()
                    showToast("✅ Not kaydedildi")
                }
                is RepoResult.Error -> showToast(res.message, isError = true)
            }
        }
    }

    fun deleteMarketNote(noteId: Long) {
        viewModelScope.launch {
            repository.deleteMarketNote(noteId)
            showToast("✅ Not silindi")
        }
    }

    fun saveSettings(
        userName: String,
        email: String,
        monthlyIncome: Double,
        storeRatio: Int,
        fundRatio: Int,
        selfRatio: Int,
        storeTargetAmount: Double,
        storeTargetDateMillis: Long?
    ) {
        viewModelScope.launch {
            repository.updateSettingsProfile(
                userName = userName,
                email = email,
                monthlyIncome = monthlyIncome,
                storeRatio = storeRatio,
                fundRatio = fundRatio,
                selfRatio = selfRatio,
                storeTargetAmount = storeTargetAmount,
                storeTargetDateMillis = storeTargetDateMillis
            )
            showToast("✅ Ayarlar kaydedildi")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            marketFeedJob?.cancel()
            marketAgendaAiJob?.cancel()
            articleReaderJob?.cancel()
            assetHistoryJob?.cancel()
            assetAiForecastJob?.cancel()
            remoteSearchJob?.cancel()
            assetHistoryCache.clear()
            MarketPriceMonitorService.cancel(appContext)
            repository.clearAllData()
            hasInitializedStartupServices = false
            simulationParams.value = SimulationParams()
            currentTab.value = MainTab.HOME
            showAllTransactions.value = false
            showIncomeExpense.value = false
            activeHomeSheet.value = null
            bestScenarioResult.value = null
            aiCommentaryState.value = AiCommentaryState.Idle
            liveMarketState.value = LiveMarketUiState.Idle
            marketNewsState.value = MarketNewsUiState.Idle
            marketAgendaAiState.value = AiCommentaryState.Idle
            selectedNewsArticle.value = null
            selectedAssetDetail.value = null
            remoteSearchState.value = RemoteMarketSearchState()
            pendingInvestFundType.value = null
            showToast("✅ Tüm veriler silindi")
        }
    }

    fun showToast(message: String, isError: Boolean = false) {
        toastJob?.cancel()
        toastMessage.value = ToastMessage(text = message, isError = isError)
        toastJob = viewModelScope.launch {
            delay(3000L)
            toastMessage.value = null
        }
    }

    class Factory(
        private val appContext: Context,
        private val repository: SermayeRepository,
        private val aiAdvisorRepository: FirebaseAiAdvisorRepository,
        private val liveMarketRepository: LiveMarketRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SermayeViewModel(appContext, repository, aiAdvisorRepository, liveMarketRepository) as T
        }
    }
}
