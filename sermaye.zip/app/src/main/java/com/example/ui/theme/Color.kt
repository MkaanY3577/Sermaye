package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureWhite = Color(0xFFFFFFFF)
val PureBlack = Color(0xFF000000)

val StoreBlue = Color(0xFF2563EB)
val FundOrange = Color(0xFFF97316)
val SelfGreen = Color(0xFF16A34A)
val AlertRed = Color(0xFFDC2626)

val SummaryYellowLight = Color(0xFFFEF9C3)
val SummaryYellowDark = Color(0xFF422006)
val SummaryYellowBorderDark = Color(0xFFFACC15)

val DisclaimerGray = Color(0xFF52525B)
val DisclaimerGrayDark = Color(0xFFD4D4D8)
