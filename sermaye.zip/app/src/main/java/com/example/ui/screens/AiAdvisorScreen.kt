package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repo.AiCommentaryState
import com.example.domain.AVAILABLE_FUND_OPTIONS
import com.example.domain.RiskProfileMode
import com.example.ui.SermayeUiState
import com.example.ui.components.CrispMiniSparkline
import com.example.ui.components.CrispPieAllocationChart
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlin.math.pow

@Composable
fun AiAdvisorScreen(
    uiState: SermayeUiState,
    onSelectRiskMode: (RiskProfileMode) -> Unit,
    onApplyRiskAllocation: (sellExistingFirst: Boolean) -> Unit,
    onApplySmartProfitPlan: (sellExistingFirst: Boolean) -> Unit,
    onRequestGeminiAdvice: () -> Unit
) {
    val colors = LocalSermayeColors.current
    val summary = uiState.summary
    val advice = summary.aiAdvice
    val selectedMode = uiState.selectedRiskMode
    val profitPlan = uiState.aiProfitPlan

    var showSellExistingDialog by remember { mutableStateOf(false) }
    var applyingSmartPlan by remember { mutableStateOf(false) }

    val sliceColors = listOf(colors.storeBlue, colors.fundOrange, colors.selfGreen, colors.alertRed)
    val smartPieSlices = remember(profitPlan.smartAllocations, colors) {
        profitPlan.smartAllocations.mapIndexed { idx, (name, pct) ->
            Triple(name, pct, sliceColors[idx % sliceColors.size])
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "🤖 AI Kâr & Fon Danışmanın",
                fontFamily = PoppinsFontFamily,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .padding(top = 12.dp)
            )
        }

        // KÂR OPTİMİZASYON KARTI (MEVCUT VS AI PLANI TL FARKI)
        item {
            VaultCard(
                modifier = Modifier.widthIn(max = 600.dp),
                backgroundColor = colors.summaryBg,
                borderColor = colors.summaryBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = profitPlan.strategyTitle,
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.summaryText,
                        modifier = Modifier.weight(1f)
                    )
                    if (profitPlan.monthlyProfitBoostTL > 0.0) {
                        Box(
                            modifier = Modifier
                                .background(colors.selfGreen, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "+${CurrencyUtils.formatTL(profitPlan.monthlyProfitBoostTL)}/ay",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = profitPlan.strategySummary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.storeBlue
                )

                if (summary.totalFundVault > 0.0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(colors.cardBackground, RoundedCornerShape(8.dp))
                                .border(1.dp, colors.borderColor, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "Mevcut Aylık Getiri",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.disclaimerText
                            )
                            Text(
                                text = CurrencyUtils.formatTL(profitPlan.currentMonthlyProfitTL),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .background(colors.cardBackground, RoundedCornerShape(8.dp))
                                .border(1.dp, colors.selfGreen, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "AI Hedef Aylık",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.selfGreen
                            )
                            Text(
                                text = CurrencyUtils.formatTL(profitPlan.projectedMonthlyProfitTL),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.selfGreen
                            )
                        }
                    }
                    if (profitPlan.yearlyCompoundBoostTL > 0.0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "12 Aylık Bileşik Ek Kazanç Farkı: +${CurrencyUtils.formatTL(profitPlan.yearlyCompoundBoostTL)}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.selfGreen
                        )
                    }
                }

                if (profitPlan.actionableSteps.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(thickness = 1.dp, color = colors.summaryBorder)
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        profitPlan.actionableSteps.forEach { step ->
                            Text(
                                text = "• $step",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.summaryText
                            )
                        }
                    }
                }
            }
        }

        // DETERMINİSTİK KURALLAR
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "Gerçek Verilerine Göre Risk & Kasa Kontrolleri",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    advice.alerts.forEach { ruleText ->
                        Text(
                            text = "• $ruleText",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary
                        )
                    }
                }
            }
        }

        // HAFTALIK PERFORMANS KARTI (gerçek snapshot verisi)
        if (summary.totalWealth > 0.0) {
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Haftalık Fon Özeti",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = advice.weeklyPerformanceText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                }
            }
        }

        // 3 RİSK MODU + CANLI PİYASA UYUMLU AKILLI DAĞILIM + TL KARŞILIĞI
        if (summary.totalWealth > 0.0) {
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Risk Modu & Akıllı Kâr Dağılımı",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        RiskProfileMode.entries.forEach { mode ->
                            val isSelected = mode == selectedMode
                            val weightedMonthlyReturn = remember(mode) {
                                mode.allocations.sumOf { (fundName, pct) ->
                                    val rate = AVAILABLE_FUND_OPTIONS.firstOrNull { it.name == fundName }
                                        ?.defaultMonthlyReturnPercent ?: 3.5
                                    rate * (pct / 100.0)
                                }
                            }
                            val compoundCurve = remember(mode, weightedMonthlyReturn) {
                                val r = weightedMonthlyReturn / 100.0
                                (0..12).map { m -> 100.0 * (1.0 + r).pow(m.toDouble()) }
                            }
                            val modeAccent = when (mode) {
                                RiskProfileMode.LOW -> colors.selfGreen
                                RiskProfileMode.BALANCED -> colors.storeBlue
                                RiskProfileMode.AGGRESSIVE -> colors.fundOrange
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) colors.summaryBg else colors.cardBackground)
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) modeAccent else colors.borderColor,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onSelectRiskMode(mode) }
                                    .padding(12.dp)
                                    .testTag("risk_mode_${mode.name}"),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = mode.title,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(modeAccent, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "+%${CurrencyUtils.formatEditableNumber(weightedMonthlyReturn)}/ay",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PureWhite
                                        )
                                    }
                                }

                                // Dağılım Oran Çubuğu
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                        .border(1.dp, colors.borderColor, RoundedCornerShape(5.dp))
                                ) {
                                    mode.allocations.forEachIndexed { idx, (_, pct) ->
                                        Box(
                                            modifier = Modifier
                                                .weight(pct.toFloat().coerceAtLeast(1f))
                                                .height(10.dp)
                                                .background(sliceColors[idx % sliceColors.size])
                                        )
                                    }
                                }

                                Text(
                                    text = mode.allocations.joinToString(" • ") { (n, p) ->
                                        "${n.removeSuffix(" Fonu")} %$p"
                                    },
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = colors.disclaimerText
                                )

                                // 12 Aylık Büyüme Grafiği
                                CrispMiniSparkline(
                                    prices = compoundCurve,
                                    lineColor = modeAccent,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "${selectedMode.description} (Canlı haber ve hedef tarihine göre ağırlıklar optimize edildi)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.storeBlue
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    CrispPieAllocationChart(slices = smartPieSlices)

                    Spacer(modifier = Modifier.height(14.dp))
                    val baseFund = summary.totalFundVault
                    val tlLine = profitPlan.smartAllocations.joinToString(", ") { (name, pct) ->
                        val shortName = name.removeSuffix(" Fonu")
                        "$shortName'na ${CurrencyUtils.formatTL(CurrencyUtils.round2(baseFund * pct / 100.0))}"
                    }
                    Text(
                        text = "Fon kasan ${CurrencyUtils.formatTL(baseFund)} için akıllı dağılım: $tlLine",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    CrispSolidButton(
                        text = "AKILLI KÂR PLANINI UYGULA",
                        containerColor = colors.selfGreen,
                        contentColor = PureWhite,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "ai_apply_smart_profit_button",
                        onClick = {
                            if (summary.computedFunds.isNotEmpty()) {
                                applyingSmartPlan = true
                                showSellExistingDialog = true
                            } else {
                                onApplySmartProfitPlan(false)
                            }
                        }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CrispSolidButton(
                        text = "SABİT RİSK MODUNU UYGULA",
                        containerColor = colors.fundOrange,
                        contentColor = PureWhite,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "ai_apply_recommendation_button",
                        onClick = {
                            if (summary.computedFunds.isNotEmpty()) {
                                applyingSmartPlan = false
                                showSellExistingDialog = true
                            } else {
                                onApplyRiskAllocation(false)
                            }
                        }
                    )
                }
            }

            // CANLI GEMINI AI YORUM KARTI
            item {
                VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                    Text(
                        text = "Canlı Gemini AI Kâr Stratejisi",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    when (val state = uiState.aiCommentaryState) {
                        AiCommentaryState.Idle -> {
                            Text(
                                text = "Portföyünü, boştaki nakdini, canlı altın/Bitcoin/fon fiyatlarını ve güncel ekonomi haberlerini Gemini AI ile tek planda birleştir.",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                        }
                        AiCommentaryState.Loading -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(color = colors.storeBlue)
                                Text(
                                    text = "Canlı piyasa + portföy kâr analizi hazırlanıyor...",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                            }
                        }
                        is AiCommentaryState.Streaming -> {
                            Text(
                                text = state.text,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                        }
                        is AiCommentaryState.Success -> {
                            Text(
                                text = state.text,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                        }
                        is AiCommentaryState.Error -> {
                            Text(
                                text = state.message,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.alertRed
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    CrispSolidButton(
                        text = "CANLI KÂR STRATEJİSİ AL",
                        containerColor = colors.storeBlue,
                        contentColor = PureWhite,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "ai_request_gemini_button",
                        onClick = onRequestGeminiAdvice
                    )
                }
            }
        }

        // Eğitim amaçlıdır notu (12sp tek istisna)
        item {
            Text(
                text = "Bu eğitim amaçlıdır, yatırım tavsiyesi değildir.",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.disclaimerText,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
    }

    if (showSellExistingDialog) {
        AlertDialog(
            onDismissRequest = { showSellExistingDialog = false },
            containerColor = colors.cardBackground,
            title = {
                Text("Mevcut Fonlar", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
            },
            text = {
                Text(
                    text = "Mevcut fonların var, önce onları satmak ister misin? " +
                        "Evet dersen mevcut fonlar satılıp tüm parayla yeni kâr planı kurulacak; Hayır dersen sadece boştaki paran kullanılacak.",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSellExistingDialog = false
                        if (applyingSmartPlan) onApplySmartProfitPlan(true) else onApplyRiskAllocation(true)
                    }
                ) {
                    Text("Evet, Sat ve Uygula", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = colors.selfGreen)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showSellExistingDialog = false
                        if (applyingSmartPlan) onApplySmartProfitPlan(false) else onApplyRiskAllocation(false)
                    }
                ) {
                    Text("Sadece Boştakiyle Uygula", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = colors.textPrimary)
                }
            }
        )
    }
}
