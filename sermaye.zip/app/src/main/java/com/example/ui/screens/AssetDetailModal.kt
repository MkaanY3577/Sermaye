package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.data.local.AssetPriceAlertRule
import com.example.data.repo.AiCommentaryState
import com.example.domain.AssetForecastHorizon
import com.example.domain.ChartRange
import com.example.domain.ComputedFund
import com.example.ui.SelectedAssetDetailState
import com.example.ui.components.AssetAlertThresholdDialog
import com.example.ui.components.CrispAssetHistoryChart
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.LiveClockBadge
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlinx.coroutines.delay

@Composable
fun AssetDetailModal(
    state: SelectedAssetDetailState,
    isFavorite: Boolean = false,
    activeAlertRule: AssetPriceAlertRule? = null,
    onDismiss: () -> Unit,
    onSelectRange: (ChartRange) -> Unit,
    onRefreshLive: () -> Unit,
    onRegenerateAiForecast: () -> Unit,
    onQuickInvestSuggestedFund: (String) -> Unit,
    onUpdateOwnedFund: (ComputedFund) -> Unit,
    onSellOwnedFund: (ComputedFund) -> Unit,
    onToggleFavorite: () -> Unit = {},
    onEnableAlert: (Double) -> Unit = {},
    onDisableAlert: () -> Unit = {},
    onShowError: (String) -> Unit = {}
) {
    val colors = LocalSermayeColors.current
    val context = LocalContext.current
    var showAlertDialog by remember { mutableStateOf(false) }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            showAlertDialog = true
        } else {
            onShowError("Telefon bildirimi için bildirim izni vermen gerekiyor.")
        }
    }

    fun openAlertDialogWithPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                showAlertDialog = true
            } else {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            showAlertDialog = true
        }
    }

    // Automatic 20s live price refresh while inspecting asset detail (clock is isolated in LiveClockBadge)
    LaunchedEffect(state.id) {
        while (true) {
            delay(20_000L)
            onRefreshLive()
        }
    }

    val filteredPoints = remember(state.historyPoints, state.selectedRange) {
        val pts = state.historyPoints
        if (pts.size < 2) {
            pts
        } else {
            val cutoff = pts.last().timestampMillis - state.selectedRange.days.toLong() * 24L * 60L * 60L * 1000L
            val slice = pts.filter { it.timestampMillis >= cutoff }
            if (slice.size >= 2) slice else pts.takeLast(minOf(pts.size, 15))
        }
    }

    val chg = state.changePercent24h
    val chgColor = when {
        chg == null -> colors.storeBlue
        chg >= 0.0 -> colors.selfGreen
        else -> colors.alertRed
    }

    val suggestedFundType = remember(state.id, state.name, state.symbol) {
        when {
            state.name.contains("Altın", ignoreCase = true) ||
                state.id.contains("altin") ||
                state.symbol in listOf("GLD", "ZGOLD.IS", "GC=F") -> "Altın Fonu"
            state.name.contains("Bitcoin", ignoreCase = true) ||
                state.name.contains("Ethereum", ignoreCase = true) ||
                state.name.contains("Solana", ignoreCase = true) ||
                state.symbol == "IBIT" -> "Bitcoin Fonu"
            state.name.contains("BIST", ignoreCase = true) ||
                state.name.contains("Hisse", ignoreCase = true) ||
                state.symbol in listOf("XU100.IS", "SPY", "QQQ", "TUR") -> "Hisse Senedi Fonu"
            state.name.contains("Eurobond", ignoreCase = true) ||
                state.id in listOf("usd", "eur") ||
                state.symbol == "EMB" -> "Eurobond Fonu"
            state.name.contains("Gümüş", ignoreCase = true) ||
                state.symbol == "GMSTR.IS" -> "Katılım Fonu"
            else -> "Para Piyasası Fonu"
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BackHandler { onDismiss() }

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = colors.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                // TOP BAR
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("asset_detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri dön",
                            tint = colors.textPrimary
                        )
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        Text(
                            text = state.name,
                            fontFamily = PoppinsFontFamily,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${state.symbol} • ${state.category}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.storeBlue,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    val hasAlert = activeAlertRule?.enabled == true
                    IconButton(
                        onClick = { openAlertDialogWithPermission() },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("asset_detail_alert_button")
                    ) {
                        Icon(
                            imageVector = if (hasAlert) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                            contentDescription = "Fiyat bildirimi ayarla",
                            tint = if (hasAlert) colors.fundOrange else colors.textPrimary
                        )
                    }
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("asset_detail_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarOutline,
                            contentDescription = if (isFavorite) "Favorilerden çıkar" else "Favorilere ekle",
                            tint = if (isFavorite) Color(0xFFF59E0B) else colors.textPrimary
                        )
                    }
                    IconButton(
                        onClick = onRefreshLive,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("asset_detail_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Canlı fiyatı yenile",
                            tint = colors.storeBlue
                        )
                    }
                }
                HorizontalDivider(thickness = 1.dp, color = colors.borderColor)

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    item { Spacer(modifier = Modifier.height(4.dp)) }

                    // 1. CANLI DEĞER VE POZİSYON KARTI
                    item {
                        VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                LiveClockBadge(
                                    prefix = "Canlı •",
                                    suffix = "TSİ"
                                )
                                if (chg != null) {
                                    Box(
                                        modifier = Modifier
                                            .background(chgColor, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = CurrencyUtils.formatSignedPercent(chg),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PureWhite
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = CurrencyUtils.formatMoneyByCurrency(state.currentPrice, state.currency),
                                fontFamily = PoppinsFontFamily,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                modifier = Modifier.testTag("asset_detail_live_price")
                            )
                            Text(
                                text = "Kaynak: ${state.sourceName} • Her 20 saniyede canlı güncellenir",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.disclaimerText
                            )

                            val owned = state.ownedFund
                            if (owned != null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(colors.summaryBg, RoundedCornerShape(10.dp))
                                        .border(1.dp, colors.summaryBorder, RoundedCornerShape(10.dp))
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Senin Fon Pozisyonun",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.summaryText
                                    )
                                    Text(
                                        text = "Yatırılan: ${CurrencyUtils.formatTL(owned.entity.investedAmount)} • " +
                                            "Güncel Değer: ${CurrencyUtils.formatTL(owned.currentValue)}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.summaryText
                                    )
                                    Text(
                                        text = "Kar/Zarar: ${CurrencyUtils.formatSignedTL(owned.profitTL)} " +
                                            "(${CurrencyUtils.formatSignedPercent(owned.profitPercent)})",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (owned.profitTL >= 0.0) colors.selfGreen else colors.alertRed
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { onUpdateOwnedFund(owned) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, colors.borderColor)
                                    ) {
                                        Text(
                                            text = "Değeri Güncelle",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    OutlinedButton(
                                        onClick = { onSellOwnedFund(owned) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, colors.alertRed)
                                    ) {
                                        Text(
                                            text = "Fon'dan Çık",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.alertRed,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.height(12.dp))
                                CrispSolidButton(
                                    text = "$suggestedFundType Olarak Yatır",
                                    containerColor = colors.fundOrange,
                                    contentColor = PureWhite,
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "asset_detail_quick_invest_button",
                                    onClick = { onQuickInvestSuggestedFund(suggestedFundType) }
                                )
                            }
                        }
                    }

                    // 2. CANLI TARİHSEL GRAFİK + 1A / 3A / 6A / 1Y SEÇİCİ
                    item {
                        VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                            Text(
                                text = "Fiyat & Performans Grafiği",
                                fontFamily = PoppinsFontFamily,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                ChartRange.entries.forEach { range ->
                                    val selected = state.selectedRange == range
                                    OutlinedButton(
                                        onClick = { onSelectRange(range) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("chart_range_${range.name}"),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, colors.borderColor),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (selected) colors.textPrimary else colors.cardBackground,
                                            contentColor = if (selected) colors.cardBackground else colors.textPrimary
                                        )
                                    ) {
                                        Text(
                                            text = range.label,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            if (state.isLoadingHistory) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(175.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(26.dp),
                                        color = colors.storeBlue,
                                        strokeWidth = 3.dp
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "Canlı grafik verileri yükleniyor...",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary
                                    )
                                }
                            } else {
                                if (state.historyError != null && filteredPoints.size >= 2) {
                                    Text(
                                        text = state.historyError,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.storeBlue
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                }
                                CrispAssetHistoryChart(
                                    points = filteredPoints,
                                    currency = state.currency,
                                    lineColor = chgColor,
                                    emptyText = state.historyError ?: "Bu dönem için grafik verisi yok."
                                )
                            }
                        }
                    }

                    // 3. 1 AYLIK, 3 AYLIK, 6 AYLIK, 12 AYLIK SAYISAL DEĞİŞİM TAHMİNİ
                    state.statisticalForecast?.let { forecast ->
                        item {
                            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                                Text(
                                    text = "Gelecek Tahmini (1 • 3 • 6 • 12 Ay)",
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${forecast.trendSignal} • Aylık Trend Hızı: ${CurrencyUtils.formatSignedPercent(forecast.realizedMonthlyDriftPercent)} • " +
                                        "Oynaklık: %${forecast.monthlyVolatilityPercent}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.storeBlue
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                val firstRow = forecast.horizons.take(2)
                                val secondRow = forecast.horizons.drop(2).take(2)
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        firstRow.forEach { horizon ->
                                            ForecastHorizonCard(
                                                horizon = horizon,
                                                currency = forecast.currency,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                    if (secondRow.isNotEmpty()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            secondRow.forEach { horizon ->
                                                ForecastHorizonCard(
                                                    horizon = horizon,
                                                    currency = forecast.currency,
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 4. GEMINI AI TAHMİN & STRATEJİ YORUMU
                    item {
                        VaultCard(
                            modifier = Modifier.widthIn(max = 600.dp),
                            backgroundColor = colors.summaryBg,
                            borderColor = colors.summaryBorder
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = colors.storeBlue
                                )
                                Text(
                                    text = "AI Tarafından 1A / 6A / 12A Tahmini",
                                    fontFamily = PoppinsFontFamily,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.summaryText
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            when (val aiState = state.aiForecastState) {
                                AiCommentaryState.Idle -> {
                                    Text(
                                        text = "Grafik verileri hazır olduğunda AI 1 aylık, 6 aylık ve 12 aylık tahmin analizi burada akacak.",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.summaryText
                                    )
                                }
                                AiCommentaryState.Loading -> {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(22.dp),
                                            color = colors.storeBlue,
                                            strokeWidth = 2.dp
                                        )
                                        Text(
                                            text = "Gemini AI 1, 6 ve 12 aylık beklentiyi hesaplıyor...",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.summaryText
                                        )
                                    }
                                }
                                is AiCommentaryState.Streaming -> {
                                    Text(
                                        text = aiState.text,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.summaryText
                                    )
                                }
                                is AiCommentaryState.Success -> {
                                    Text(
                                        text = aiState.text,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = colors.summaryText
                                    )
                                }
                                is AiCommentaryState.Error -> {
                                    Text(
                                        text = aiState.message,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.alertRed
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            CrispSolidButton(
                                text = "AI TAHMİNİNİ YENİLE",
                                containerColor = colors.storeBlue,
                                contentColor = PureWhite,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "asset_detail_ai_regenerate_button",
                                onClick = onRegenerateAiForecast
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Tarihsel fiyatlar ve canlı verilere dayalı eğitim amaçlı analizdir; yatırım tavsiyesi değildir.",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.disclaimerText
                            )
                        }
                    }

                    item { Spacer(modifier = Modifier.height(20.dp)) }
                }
            }
        }
    }

    if (showAlertDialog) {
        AssetAlertThresholdDialog(
            assetName = state.name,
            symbol = state.symbol,
            currentPrice = state.currentPrice,
            currency = state.currency,
            existingRule = activeAlertRule,
            onDismiss = { showAlertDialog = false },
            onConfirmEnable = { pct ->
                onEnableAlert(pct)
                showAlertDialog = false
            },
            onDisable = {
                onDisableAlert()
                showAlertDialog = false
            }
        )
    }
}

@Composable
private fun ForecastHorizonCard(
    horizon: AssetForecastHorizon,
    currency: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val pctColor = if (horizon.projectedChangePercent >= 0.0) colors.selfGreen else colors.alertRed
    Column(
        modifier = modifier
            .background(colors.cardBackground, RoundedCornerShape(10.dp))
            .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = horizon.horizonLabel,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        Text(
            text = CurrencyUtils.formatSignedPercent(horizon.projectedChangePercent),
            fontFamily = PoppinsFontFamily,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = pctColor
        )
        Text(
            text = "~${CurrencyUtils.formatMoneyByCurrency(horizon.projectedPrice, currency)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "Alt ${CurrencyUtils.formatSignedPercent(horizon.conservativePercent)} / Üst ${CurrencyUtils.formatSignedPercent(horizon.optimisticPercent)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = colors.disclaimerText
        )
    }
}
