package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SermayeUiState
import com.example.ui.components.CrispLineGrowthChart
import com.example.ui.components.CrispSolidButton
import com.example.ui.components.VaultCard
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun SimulationScreen(
    uiState: SermayeUiState,
    onUpdateParams: (monthlyIncome: Double, monthlyReturnPercent: Double, months: Int) -> Unit,
    onFindBestScenario: () -> Unit
) {
    val colors = LocalSermayeColors.current
    val params = uiState.simulationParams
    val currentIncome = params.monthlyIncome ?: 1000.0
    val currentReturn = params.monthlyReturnPercent
    val currentMonths = params.months
    val simResult = uiState.simulationResult

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "Geleceğini Gör",
                fontFamily = PoppinsFontFamily,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .padding(top = 12.dp)
            )
        }

        // BÜYÜK SONUÇ KARTI
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "$currentMonths. ayda ${CurrencyUtils.formatTL(simResult.futureValue)} olursun",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.selfGreen
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Ana Para (Mevcut + Aylık Birikim): ${CurrencyUtils.formatTL(simResult.totalPrincipal)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                Text(
                    text = "Fon Bileşik Getirisi: +${CurrencyUtils.formatTL(simResult.totalInterestEarned)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.fundOrange
                )
                Text(
                    text = "Fon Kasası (%${uiState.profile.fundRatio}): ${CurrencyUtils.formatTL(simResult.projectedFundVault)} • " +
                        "Diğer Kasalar: ${CurrencyUtils.formatTL(simResult.projectedOtherVaults)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                val goalLine = when {
                    uiState.profile.storeTargetAmount <= 0.0 ->
                        "Ayarlar'dan Mağaza Hedef Tutarı eklersen ulaşma süreni burada hesaplarım."
                    simResult.monthsToGoal == 0.0 ->
                        "Bu senaryoda mağaza açma hedefine zaten ulaşmış durumdasın!"
                    simResult.monthsToGoal != null ->
                        "Bu senaryoda mağaza açmaya ${max(1, simResult.monthsToGoal.roundToInt())} ayda ulaşırsın."
                    else ->
                        "Mağaza hedefine ulaşım süresi için aylık kazanç ve mağaza oranını artır."
                }
                Text(
                    text = goalLine,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
        }

        // 3 SLIDER
        item {
            val profileIncome = uiState.profile.monthlyIncome
            val maxIncomeDouble = ceil(maxOf(50000.0, maxOf(profileIncome, currentIncome) * 2.0) / 5000.0) * 5000.0
            val maxIncomeFloat = maxIncomeDouble.toFloat()
            val incomeStep = if (maxIncomeFloat > 100000f) 1000f else 500f

            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                // Slider 1: Aylık Kazanç (500 TL - dinamik üst sınır)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Aylık Kazanç", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    Text(CurrencyUtils.formatTL(currentIncome), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.storeBlue)
                }
                Slider(
                    value = currentIncome.toFloat().coerceIn(500f, maxIncomeFloat),
                    onValueChange = {
                        val snapped = ((it / incomeStep).roundToInt() * incomeStep.toDouble())
                            .coerceIn(500.0, maxIncomeDouble)
                        onUpdateParams(snapped, currentReturn, currentMonths)
                    },
                    valueRange = 500f..maxIncomeFloat,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.storeBlue,
                        activeTrackColor = colors.storeBlue,
                        inactiveTrackColor = colors.borderColor
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Slider 2: Fon Getirisi (%1 - %10)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Aylık Fon Getirisi", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    Text(CurrencyUtils.formatPercent(currentReturn), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.fundOrange)
                }
                Slider(
                    value = currentReturn.toFloat().coerceIn(1f, 10f),
                    onValueChange = {
                        val snapped = ((it * 2f).roundToInt() / 2.0).coerceIn(1.0, 10.0)
                        onUpdateParams(currentIncome, snapped, currentMonths)
                    },
                    valueRange = 1f..10f,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.fundOrange,
                        activeTrackColor = colors.fundOrange,
                        inactiveTrackColor = colors.borderColor
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Slider 3: Süre (6 - 36 Ay)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Süre", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                    Text("$currentMonths Ay", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = colors.selfGreen)
                }
                Slider(
                    value = currentMonths.toFloat().coerceIn(6f, 36f),
                    onValueChange = {
                        onUpdateParams(currentIncome, currentReturn, it.roundToInt().coerceIn(6, 36))
                    },
                    valueRange = 6f..36f,
                    colors = SliderDefaults.colors(
                        thumbColor = colors.selfGreen,
                        activeTrackColor = colors.selfGreen,
                        inactiveTrackColor = colors.borderColor
                    )
                )
            }
        }

        // GRAFİK
        item {
            VaultCard(modifier = Modifier.widthIn(max = 600.dp)) {
                Text(
                    text = "Bileşik Büyüme Grafiği",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(10.dp))
                CrispLineGrowthChart(
                    points = simResult.monthlyPoints,
                    lineColor = colors.selfGreen,
                    emptyText = "Hesaplanıyor..."
                )
            }
        }

        // AI EN İYİ SENARYOYU BUL
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CrispSolidButton(
                    text = "AI EN İYİ SENARYOYU BUL",
                    containerColor = colors.storeBlue,
                    contentColor = PureWhite,
                    onClick = onFindBestScenario,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "simulation_best_scenario_button"
                )

                val best = uiState.bestScenarioResult
                if (best != null) {
                    VaultCard(
                        backgroundColor = colors.summaryBg,
                        borderColor = colors.summaryBorder
                    ) {
                        Text(
                            text = "En iyi senaryo (100 kombinasyon tarandı): Fon %${best.fundRatioPercent}, " +
                                "Getiri ${CurrencyUtils.formatPercent(best.monthlyReturnPercent)} ile ${best.months}. ayda " +
                                "${CurrencyUtils.formatTL(best.projectedTotal)} olursun.",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.summaryText
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
