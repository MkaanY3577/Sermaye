package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.local.AssetPriceAlertRule
import com.example.data.repo.LiveAssetQuote
import com.example.domain.FinanceEngine
import androidx.compose.ui.geometry.CornerRadius
import com.example.domain.MonthlyCashflowBar
import com.example.domain.MonthlyPoint
import com.example.domain.PricePoint
import com.example.ui.ToastMessage
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.util.CurrencyUtils
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun VaultCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color? = null,
    borderColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = LocalSermayeColors.current
    val bg = backgroundColor ?: colors.cardBackground
    val border = borderColor ?: colors.borderColor
    val cardModifier = if (onClick != null) {
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    } else {
        modifier.fillMaxWidth()
    }
    Card(
        modifier = cardModifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, border),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content
        )
    }
}

@Composable
fun CrispSolidButton(
    text: String,
    containerColor: Color,
    contentColor: Color = PureWhite,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(56.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor,
            disabledContentColor = contentColor
        ),
        border = BorderStroke(1.dp, LocalSermayeColors.current.borderColor),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        Text(
            text = text,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun SermayeTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    isNumeric: Boolean = false,
    singleLine: Boolean = true,
    maxLength: Int? = null,
    suffixText: String? = null,
    testTag: String = ""
) {
    val colors = LocalSermayeColors.current
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = { raw ->
                val processed = if (isNumeric) CurrencyUtils.sanitizeDecimalInput(raw) else raw
                val finalVal = if (maxLength != null) processed.take(maxLength) else processed
                onValueChange(finalVal)
            },
            placeholder = {
                Text(
                    text = placeholder,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            },
            suffix = if (suffixText != null) {
                {
                    Text(
                        text = suffixText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            } else null,
            singleLine = singleLine,
            keyboardOptions = KeyboardOptions(
                keyboardType = if (isNumeric) KeyboardType.Decimal else KeyboardType.Text
            ),
            textStyle = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            ),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = colors.cardBackground,
                unfocusedContainerColor = colors.cardBackground,
                focusedBorderColor = colors.borderColor,
                unfocusedBorderColor = colors.borderColor,
                focusedTextColor = colors.textPrimary,
                unfocusedTextColor = colors.textPrimary,
                cursorColor = colors.storeBlue
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
        )
    }
}

@Composable
fun AutoBalanceSplitSliders(
    storeRatio: Int,
    fundRatio: Int,
    selfRatio: Int,
    previewAmount: Double,
    onRatiosChanged: (Int, Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val currentTriple = Triple(storeRatio, fundRatio, selfRatio)

    val storeTL = CurrencyUtils.round2(previewAmount * (storeRatio / 100.0))
    val fundTL = CurrencyUtils.round2(previewAmount * (fundRatio / 100.0))
    val selfTL = CurrencyUtils.round2(previewAmount - storeTL - fundTL)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SingleRatioSlider(
            label = "Mağaza Kasası",
            percent = storeRatio,
            accentColor = colors.storeBlue,
            onValueChange = { newVal ->
                val next = FinanceEngine.rebalanceRatios(0, newVal, currentTriple)
                onRatiosChanged(next.first, next.second, next.third)
            }
        )
        SingleRatioSlider(
            label = "Fon Kasası",
            percent = fundRatio,
            accentColor = colors.fundOrange,
            onValueChange = { newVal ->
                val next = FinanceEngine.rebalanceRatios(1, newVal, currentTriple)
                onRatiosChanged(next.first, next.second, next.third)
            }
        )
        SingleRatioSlider(
            label = "Kendine Kasası",
            percent = selfRatio,
            accentColor = colors.selfGreen,
            onValueChange = { newVal ->
                val next = FinanceEngine.rebalanceRatios(2, newVal, currentTriple)
                onRatiosChanged(next.first, next.second, next.third)
            }
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.summaryBg, RoundedCornerShape(10.dp))
                .border(1.dp, colors.summaryBorder, RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            val baseLabel = if (previewAmount > 0.0) CurrencyUtils.formatTL(previewAmount) else "1.000,00 TL"
            val sLabel = if (previewAmount > 0.0) CurrencyUtils.formatTL(storeTL) else CurrencyUtils.formatTL(1000.0 * storeRatio / 100.0)
            val fLabel = if (previewAmount > 0.0) CurrencyUtils.formatTL(fundTL) else CurrencyUtils.formatTL(1000.0 * fundRatio / 100.0)
            val kLabel = if (previewAmount > 0.0) CurrencyUtils.formatTL(selfTL) else CurrencyUtils.formatTL(1000.0 * selfRatio / 100.0)

            Text(
                text = "$baseLabel gelirse: Mağaza'ya $sLabel, Fon'a $fLabel, Kendine'ye $kLabel gider.",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.summaryText
            )
        }
    }
}

@Composable
private fun SingleRatioSlider(
    label: String,
    percent: Int,
    accentColor: Color,
    onValueChange: (Int) -> Unit
) {
    val colors = LocalSermayeColors.current
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
            Text(
                text = "%$percent",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }
        Slider(
            value = percent.toFloat(),
            onValueChange = { onValueChange(it.roundToInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = colors.borderColor
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerSelectorRow(
    label: String,
    selectedDateMillis: Long?,
    placeholder: String = "Tarih seç",
    onDateSelected: (Long?) -> Unit,
    allowClear: Boolean = false
) {
    val colors = LocalSermayeColors.current
    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = colors.textPrimary
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = { showDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, colors.borderColor),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = colors.cardBackground,
                    contentColor = colors.textPrimary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "Takvim",
                    tint = colors.textPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = selectedDateMillis?.let { CurrencyUtils.formatDate(it) } ?: placeholder,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            if (allowClear && selectedDateMillis != null) {
                OutlinedButton(
                    onClick = { onDateSelected(null) },
                    modifier = Modifier.height(52.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, colors.borderColor)
                ) {
                    Text("Temizle", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.alertRed)
                }
            }
        }
    }

    if (showDialog) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = selectedDateMillis ?: System.currentTimeMillis()
        )
        DatePickerDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDateSelected(state.selectedDateMillis ?: System.currentTimeMillis())
                        showDialog = false
                    }
                ) {
                    Text("Seç", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("İptal", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        ) {
            DatePicker(state = state)
        }
    }
}

@Composable
fun TopToastBanner(toast: ToastMessage?) {
    val colors = LocalSermayeColors.current
    AnimatedVisibility(
        visible = toast != null,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut()
    ) {
        if (toast != null) {
            val bg = if (toast.isError) colors.alertRed else colors.selfGreen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(bg, RoundedCornerShape(10.dp))
                    .border(1.dp, colors.borderColor, RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Text(
                    text = toast.text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureWhite
                )
            }
        }
    }
}

@Composable
fun CrispLineGrowthChart(
    points: List<MonthlyPoint>,
    lineColor: Color,
    emptyText: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    if (points.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(170.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emptyText,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }
        return
    }

    val minVal = points.minOf { it.totalWealth }
    val maxVal = points.maxOf { it.totalWealth }
    val span = (maxVal - minVal).takeIf { it > 0.01 } ?: 1.0

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "En Yüksek: ${CurrencyUtils.formatTL(maxVal)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            Text(
                text = "Güncel: ${CurrencyUtils.formatTL(points.last().totalWealth)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = lineColor
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(vertical = 8.dp)
        ) {
            val leftPad = 12.dp.toPx()
            val rightPad = 12.dp.toPx()
            val topPad = 12.dp.toPx()
            val bottomPad = 16.dp.toPx()
            val chartW = (size.width - leftPad - rightPad).coerceAtLeast(1f)
            val chartH = (size.height - topPad - bottomPad).coerceAtLeast(1f)

            // Baseline axis
            drawLine(
                color = colors.borderColor,
                start = Offset(leftPad, topPad + chartH),
                end = Offset(leftPad + chartW, topPad + chartH),
                strokeWidth = 2.dp.toPx()
            )

            val coords = points.mapIndexed { idx, pt ->
                val x = if (points.size == 1) {
                    leftPad + chartW / 2f
                } else {
                    leftPad + (idx.toFloat() / (points.size - 1)) * chartW
                }
                val normY = ((pt.totalWealth - minVal) / span).toFloat().coerceIn(0f, 1f)
                val y = topPad + chartH - (normY * chartH)
                Offset(x, y)
            }

            if (coords.size >= 2) {
                val fillPath = Path().apply {
                    moveTo(coords.first().x, topPad + chartH)
                    coords.forEach { pt -> lineTo(pt.x, pt.y) }
                    lineTo(coords.last().x, topPad + chartH)
                    close()
                }
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.28f), lineColor.copy(alpha = 0.02f)),
                        startY = topPad,
                        endY = topPad + chartH
                    )
                )

                val path = Path().apply {
                    moveTo(coords.first().x, coords.first().y)
                    for (i in 1 until coords.size) {
                        lineTo(coords[i].x, coords[i].y)
                    }
                }
                drawPath(
                    path = path,
                    color = lineColor,
                    style = Stroke(
                        width = 3.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            coords.forEachIndexed { idx, pt ->
                val isLast = idx == coords.lastIndex
                drawCircle(
                    color = if (isLast) lineColor.copy(alpha = 0.25f) else colors.borderColor,
                    radius = if (isLast) 9.dp.toPx() else 5.5.dp.toPx(),
                    center = pt
                )
                drawCircle(
                    color = lineColor,
                    radius = if (isLast) 5.dp.toPx() else 3.5.dp.toPx(),
                    center = pt
                )
            }
        }

        // Crisp x-axis labels (first, middle, last)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = points.first().label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            if (points.size >= 3) {
                Text(
                    text = points[points.size / 2].label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            if (points.size >= 2) {
                Text(
                    text = points.last().label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
        }
    }
}

@Composable
fun CrispPieAllocationChart(
    slices: List<Triple<String, Int, Color>>,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier.size(144.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                var startAngle = -90f
                val total = slices.sumOf { it.second }.coerceAtLeast(1)
                val ringWidth = 26.dp.toPx()
                slices.forEach { (_, pct, sliceColor) ->
                    val sweep = (pct.toFloat() / total.toFloat()) * 360f
                    drawArc(
                        color = sliceColor,
                        startAngle = startAngle,
                        sweepAngle = (sweep - 2f).coerceAtLeast(1f),
                        useCenter = false,
                        size = Size(size.width, size.height),
                        style = Stroke(width = ringWidth, cap = StrokeCap.Butt)
                    )
                    startAngle += sweep
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "%100",
                    fontFamily = PoppinsFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "Sepet",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            slices.forEach { (name, pct, sliceColor) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(sliceColor, RoundedCornerShape(4.dp))
                            .border(1.dp, colors.borderColor, RoundedCornerShape(4.dp))
                    )
                    Text(
                        text = "$name (%$pct)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun CrispAssetHistoryChart(
    points: List<PricePoint>,
    currency: String,
    lineColor: Color,
    emptyText: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    if (points.size < 2) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(170.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emptyText,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }
        return
    }

    // Evenly downsample if > 72 points so the polyline stays crisp and fast
    val sampled = remember(points) {
        if (points.size <= 72) {
            points
        } else {
            val step = (points.size - 1).toDouble() / 71.0
            (0 until 72).map { idx ->
                val srcIdx = if (idx == 71) points.lastIndex else (idx * step).roundToInt().coerceIn(0, points.lastIndex)
                points[srcIdx]
            }
        }
    }

    val minVal = sampled.minOf { it.price }
    val maxVal = sampled.maxOf { it.price }
    val firstVal = sampled.first().price
    val lastVal = sampled.last().price
    val periodPct = if (firstVal > 0.0) ((lastVal - firstVal) / firstVal) * 100.0 else 0.0
    val rawSpan = maxVal - minVal
    val hasSpan = rawSpan > (maxVal * 1e-9).coerceAtLeast(1e-9)
    val span = if (hasSpan) rawSpan else 1.0
    val periodColor = if (periodPct >= 0.0) colors.selfGreen else colors.alertRed

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "En Yüksek: ${CurrencyUtils.formatMoneyByCurrency(maxVal, currency)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Text(
                    text = "En Düşük: ${CurrencyUtils.formatMoneyByCurrency(minVal, currency)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.disclaimerText
                )
            }
            Box(
                modifier = Modifier
                    .background(periodColor, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = CurrencyUtils.formatSignedPercent(periodPct),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = PureWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
                .padding(vertical = 8.dp)
        ) {
            val leftPad = 10.dp.toPx()
            val rightPad = 10.dp.toPx()
            val topPad = 12.dp.toPx()
            val bottomPad = 12.dp.toPx()
            val chartW = (size.width - leftPad - rightPad).coerceAtLeast(1f)
            val chartH = (size.height - topPad - bottomPad).coerceAtLeast(1f)

            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
            drawLine(
                color = colors.borderColor.copy(alpha = 0.4f),
                start = Offset(leftPad, topPad),
                end = Offset(leftPad + chartW, topPad),
                strokeWidth = 1.dp.toPx(),
                pathEffect = dash
            )
            drawLine(
                color = colors.borderColor,
                start = Offset(leftPad, topPad + chartH),
                end = Offset(leftPad + chartW, topPad + chartH),
                strokeWidth = 2.dp.toPx()
            )

            val coords = sampled.mapIndexed { idx, pt ->
                val x = leftPad + (idx.toFloat() / (sampled.size - 1)) * chartW
                val normY = if (hasSpan) ((pt.price - minVal) / span).toFloat().coerceIn(0f, 1f) else 0.5f
                val y = topPad + chartH - (normY * chartH)
                Offset(x, y)
            }

            val fillPath = Path().apply {
                moveTo(coords.first().x, topPad + chartH)
                coords.forEach { pt -> lineTo(pt.x, pt.y) }
                lineTo(coords.last().x, topPad + chartH)
                close()
            }
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(lineColor.copy(alpha = 0.28f), lineColor.copy(alpha = 0.02f)),
                    startY = topPad,
                    endY = topPad + chartH
                )
            )

            val path = Path().apply {
                moveTo(coords.first().x, coords.first().y)
                for (i in 1 until coords.size) {
                    lineTo(coords[i].x, coords[i].y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(
                    width = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )

            // Crisp start and glowing live-end markers
            drawCircle(
                color = lineColor.copy(alpha = 0.25f),
                radius = 10.dp.toPx(),
                center = coords.last()
            )
            listOf(coords.first(), coords.last()).forEach { pt ->
                drawCircle(
                    color = colors.borderColor,
                    radius = 6.dp.toPx(),
                    center = pt
                )
                drawCircle(
                    color = lineColor,
                    radius = 4.dp.toPx(),
                    center = pt
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = sampled.first().label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            if (sampled.size >= 3) {
                Text(
                    text = sampled[sampled.size / 2].label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            }
            Text(
                text = sampled.last().label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }
    }
}

@Composable
fun CrispMiniSparkline(
    prices: List<Double>,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    if (prices.size < 2) return
    val normalizedPoints = remember(prices) {
        val maxPts = 24
        val sampled = if (prices.size <= maxPts) {
            prices
        } else {
            val step = (prices.size - 1).toDouble() / (maxPts - 1).toDouble()
            List(maxPts) { idx ->
                val src = if (idx == maxPts - 1) prices.lastIndex else (idx * step).roundToInt().coerceIn(0, prices.lastIndex)
                prices[src]
            }
        }
        val minVal = sampled.min()
        val maxVal = sampled.max()
        val rawSpan = maxVal - minVal
        val hasSpan = rawSpan > (maxVal * 1e-9).coerceAtLeast(1e-9)
        val span = if (hasSpan) rawSpan else 1.0
        FloatArray(sampled.size) { idx ->
            if (hasSpan) ((sampled[idx] - minVal) / span).toFloat().coerceIn(0f, 1f) else 0.5f
        }
    }

    Canvas(
        modifier = modifier
            .height(42.dp)
            .background(colors.summaryBg.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
            .border(1.dp, colors.borderColor.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        val count = normalizedPoints.size
        if (count < 2) return@Canvas
        val w = size.width.coerceAtLeast(1f)
        val h = size.height.coerceAtLeast(1f)
        val denom = (count - 1).toFloat()

        val fillPath = Path()
        val strokePath = Path()
        var lastX = 0f
        var lastY = h * 0.5f

        for (i in 0 until count) {
            val x = (i / denom) * w
            val y = h - normalizedPoints[i] * h
            if (i == 0) {
                fillPath.moveTo(x, h)
                fillPath.lineTo(x, y)
                strokePath.moveTo(x, y)
            } else {
                fillPath.lineTo(x, y)
                strokePath.lineTo(x, y)
            }
            if (i == count - 1) {
                lastX = x
                lastY = y
            }
        }
        fillPath.lineTo(lastX, h)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(lineColor.copy(alpha = 0.25f), lineColor.copy(alpha = 0.02f)),
                startY = 0f,
                endY = h
            )
        )
        drawPath(
            path = strokePath,
            color = lineColor,
            style = Stroke(
                width = 2.5.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
        val lastCenter = Offset(lastX, lastY)
        drawCircle(
            color = lineColor.copy(alpha = 0.28f),
            radius = 6.dp.toPx(),
            center = lastCenter
        )
        drawCircle(
            color = lineColor,
            radius = 3.5.dp.toPx(),
            center = lastCenter
        )
    }
}

fun resolveDisplaySparkline(quote: LiveAssetQuote): List<Double> {
    if (quote.sparklinePrices.size >= 2) return quote.sparklinePrices
    val current = quote.price
    if (current <= 0.0) return emptyList()
    val chg = quote.changePercent24h ?: 0.0
    val denom = (1.0 + chg / 100.0).takeIf { it > 0.05 } ?: 1.0
    val prev = current / denom
    val mid1 = prev + (current - prev) * 0.35
    val mid2 = prev + (current - prev) * 0.72
    return listOf(prev, mid1, mid2, current)
}

@Composable
fun NewsCoverImage(
    imageUrl: String?,
    headline: String,
    affectedFunds: List<String>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val fallbackDrawable = remember(headline, affectedFunds) {
        val text = (headline + " " + affectedFunds.joinToString(" ")).lowercase()
        if (text.contains("altın") || text.contains("gümüş") || text.contains("maden") || text.contains("emtia")) {
            R.drawable.img_news_gold
        } else {
            R.drawable.img_news_market
        }
    }

    if (imageUrl.isNullOrBlank()) {
        Image(
            painter = painterResource(id = fallbackDrawable),
            contentDescription = headline,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(RoundedCornerShape(10.dp))
        )
    } else {
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(context)
                .data(imageUrl)
                .size(640, 360)
                .crossfade(true)
                .build(),
            contentDescription = headline,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(RoundedCornerShape(10.dp)),
            loading = {
                Image(
                    painter = painterResource(id = fallbackDrawable),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            },
            error = {
                Image(
                    painter = painterResource(id = fallbackDrawable),
                    contentDescription = headline,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        )
    }
}

@Composable
fun LiveClockBadge(
    prefix: String,
    suffix: String = "",
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    var liveClockMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            liveClockMillis = System.currentTimeMillis()
        }
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Schedule,
            contentDescription = null,
            tint = colors.storeBlue,
            modifier = Modifier.size(18.dp)
        )
        val timeFormatted = CurrencyUtils.formatIstanbulTimeWithSeconds(liveClockMillis)
        val fullText = if (suffix.isNotEmpty()) "$prefix $timeFormatted $suffix" else "$prefix $timeFormatted"
        Text(
            text = fullText,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = colors.storeBlue,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssetAlertThresholdDialog(
    assetName: String,
    symbol: String,
    currentPrice: Double,
    currency: String,
    existingRule: AssetPriceAlertRule?,
    onDismiss: () -> Unit,
    onConfirmEnable: (Double) -> Unit,
    onDisable: () -> Unit
) {
    val colors = LocalSermayeColors.current
    val initialPct = existingRule?.thresholdPercent ?: 2.0
    var thresholdInput by remember(assetName, existingRule) {
        mutableStateOf(CurrencyUtils.formatEditableNumber(initialPct))
    }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val presetThresholds = listOf(0.5, 1.0, 2.0, 3.0, 5.0, 10.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.cardBackground,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = colors.fundOrange
                )
                Column {
                    Text(
                        text = "$assetName Bildirimi",
                        fontFamily = PoppinsFontFamily,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "$symbol • Güncel: ${CurrencyUtils.formatMoneyByCurrency(currentPrice, currency)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.storeBlue
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Yüzde kaçlık bir değişimde telefonuna bildirim almak istersin?",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetThresholds.forEach { pct ->
                        val parsedCurrent = CurrencyUtils.parsePositiveOrZero(thresholdInput)
                        val isSelected = parsedCurrent != null && kotlin.math.abs(parsedCurrent - pct) < 0.01
                        OutlinedButton(
                            onClick = {
                                thresholdInput = CurrencyUtils.formatEditableNumber(pct)
                                errorMsg = null
                            },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("asset_alert_preset_$pct"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, colors.borderColor),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isSelected) colors.fundOrange else colors.cardBackground,
                                contentColor = if (isSelected) PureWhite else colors.textPrimary
                            )
                        ) {
                            Text(
                                text = "±${CurrencyUtils.formatPercent(pct)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                SermayeTextField(
                    value = thresholdInput,
                    onValueChange = {
                        thresholdInput = it
                        errorMsg = null
                    },
                    label = "Özel Değişim Oranı (%)",
                    placeholder = "Örn: 2",
                    isNumeric = true,
                    suffixText = "%",
                    testTag = "asset_alert_custom_input"
                )
                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.alertRed
                    )
                }
                if (existingRule != null && existingRule.enabled) {
                    Text(
                        text = "Şu an ±${CurrencyUtils.formatPercent(existingRule.thresholdPercent)} değişimde bildirim aktif.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.selfGreen
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (existingRule != null && existingRule.enabled) {
                    TextButton(
                        onClick = onDisable,
                        modifier = Modifier.testTag("asset_alert_disable_button")
                    ) {
                        Text(
                            text = "Kapat",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.alertRed
                        )
                    }
                }
                TextButton(
                    onClick = {
                        val parsed = CurrencyUtils.parsePositiveOrZero(thresholdInput)
                        if (parsed == null || parsed < 0.1 || parsed > 100.0) {
                            errorMsg = "Lütfen %0,1 ile %100 arasında bir oran gir."
                        } else {
                            onConfirmEnable(parsed)
                        }
                    },
                    modifier = Modifier.testTag("asset_alert_confirm_button")
                ) {
                    Text(
                        text = if (existingRule?.enabled == true) "Güncelle" else "Bildirimi Aç",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.selfGreen
                    )
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
            }
        }
    )
}

@Composable
fun CrispCashflowBarChart(
    bars: List<MonthlyCashflowBar>,
    incomeColor: Color,
    expenseColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val hasAnyMovement = remember(bars) { bars.any { it.income > 0.0 || it.expense > 0.0 } }
    if (bars.isEmpty() || !hasAnyMovement) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(150.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Henüz gelir veya gider kaydı yok. İşlem eklediğinde aylık karşılaştırma grafiği burada oluşacak.",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.disclaimerText
            )
        }
        return
    }

    val maxBarValue = remember(bars) {
        bars.maxOf { kotlin.math.max(it.income, it.expense) }.coerceAtLeast(1.0)
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).background(incomeColor, RoundedCornerShape(3.dp)))
                    Text("Gelir", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = incomeColor)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(10.dp).background(expenseColor, RoundedCornerShape(3.dp)))
                    Text("Gider", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = expenseColor)
                }
            }
            Text(
                text = "Tepe: ${CurrencyUtils.formatTL(maxBarValue)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .padding(top = 6.dp)
        ) {
            val w = size.width
            val h = size.height
            val groupCount = bars.size.coerceAtLeast(1)
            val groupWidth = w / groupCount
            val barWidth = (groupWidth * 0.28f).coerceIn(8.dp.toPx(), 24.dp.toPx())
            val barGap = (barWidth * 0.35f).coerceAtLeast(3.dp.toPx())
            val baselineY = h - 4.dp.toPx()
            val usableH = (baselineY - 6.dp.toPx()).coerceAtLeast(20f)

            // Horizontal subtle grid lines
            for (step in 1..3) {
                val y = baselineY - (usableH * step / 3f)
                drawLine(
                    color = colors.borderColor.copy(alpha = 0.25f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.dp.toPx()
                )
            }
            // Baseline
            drawLine(
                color = colors.borderColor,
                start = Offset(0f, baselineY),
                end = Offset(w, baselineY),
                strokeWidth = 1.5.dp.toPx()
            )

            bars.forEachIndexed { idx, bar ->
                val centerX = groupWidth * idx + groupWidth / 2f
                val incH = ((bar.income / maxBarValue).toFloat().coerceIn(0f, 1f)) * usableH
                val expH = ((bar.expense / maxBarValue).toFloat().coerceIn(0f, 1f)) * usableH

                val incLeft = centerX - barGap / 2f - barWidth
                val expLeft = centerX + barGap / 2f
                val corner = CornerRadius(4.dp.toPx(), 4.dp.toPx())

                if (bar.income > 0.0) {
                    val drawH = kotlin.math.max(4.dp.toPx(), incH)
                    drawRoundRect(
                        color = incomeColor,
                        topLeft = Offset(incLeft, baselineY - drawH),
                        size = Size(barWidth, drawH),
                        cornerRadius = corner
                    )
                }
                if (bar.expense > 0.0) {
                    val drawH = kotlin.math.max(4.dp.toPx(), expH)
                    drawRoundRect(
                        color = expenseColor,
                        topLeft = Offset(expLeft, baselineY - drawH),
                        size = Size(barWidth, drawH),
                        cornerRadius = corner
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            bars.forEach { bar ->
                Text(
                    text = bar.label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary,
                    maxLines = 1
                )
            }
        }
    }
}

enum class HomeSectionCursor {
    VAULT_HOME,
    INCOME_EXPENSE,
    ALL_TRANSACTIONS
}

@Composable
fun SermayeHomeTopCursorBar(
    active: HomeSectionCursor,
    monthNetCashflow: Double,
    onSelectHome: () -> Unit,
    onSelectIncomeExpense: () -> Unit,
    onSelectAllTransactions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    val netDotColor = when {
        monthNetCashflow > 0.0 -> colors.selfGreen
        monthNetCashflow < 0.0 -> colors.alertRed
        else -> colors.storeBlue
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(colors.cardBackground, RoundedCornerShape(12.dp))
            .border(1.dp, colors.borderColor, RoundedCornerShape(12.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TopCursorTab(
            label = "Kasa Özeti",
            selected = active == HomeSectionCursor.VAULT_HOME,
            dotColor = null,
            activeBg = colors.textPrimary,
            activeContent = colors.cardBackground,
            indicatorColor = colors.storeBlue,
            onClick = onSelectHome,
            testTag = "top_cursor_home",
            modifier = Modifier.weight(1f)
        )
        TopCursorTab(
            label = "Gelir & Gider",
            selected = active == HomeSectionCursor.INCOME_EXPENSE,
            dotColor = netDotColor,
            activeBg = colors.selfGreen,
            activeContent = PureWhite,
            indicatorColor = netDotColor,
            onClick = onSelectIncomeExpense,
            testTag = "top_cursor_income_expense",
            modifier = Modifier.weight(1.18f)
        )
        TopCursorTab(
            label = "Hareketler",
            selected = active == HomeSectionCursor.ALL_TRANSACTIONS,
            dotColor = null,
            activeBg = colors.storeBlue,
            activeContent = PureWhite,
            indicatorColor = colors.storeBlue,
            onClick = onSelectAllTransactions,
            testTag = "top_cursor_all_tx",
            modifier = Modifier.weight(0.95f)
        )
    }
}

@Composable
private fun TopCursorTab(
    label: String,
    selected: Boolean,
    dotColor: Color?,
    activeBg: Color,
    activeContent: Color,
    indicatorColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val colors = LocalSermayeColors.current
    Column(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) activeBg else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 10.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (dotColor != null) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = if (selected) PureWhite else dotColor,
                            shape = RoundedCornerShape(50)
                        )
                )
            }
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) activeContent else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth(0.58f)
                .height(3.dp)
                .background(
                    color = if (selected) PureWhite.copy(alpha = 0.9f) else indicatorColor.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(2.dp)
                )
        )
    }
}




