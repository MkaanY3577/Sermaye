package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

object CurrencyUtils {
    private val turkishLocale = Locale.forLanguageTag("tr-TR")
    private val istanbulTimeZone = java.util.TimeZone.getTimeZone("Europe/Istanbul")

    private val symbols = DecimalFormatSymbols(turkishLocale).apply {
        groupingSeparator = '.'
        decimalSeparator = ','
    }

    private val moneyFormatter = DecimalFormat("#,##0.00", symbols)
    private val percentFormatter = DecimalFormat("0.00", symbols)
    private val dateFormatter = SimpleDateFormat("d MMM yyyy", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val shortDateFormatter = SimpleDateFormat("dd.MM.yyyy", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val yearMonthFormatter = SimpleDateFormat("yyyy-MM", Locale.US).apply {
        timeZone = istanbulTimeZone
    }
    private val monthShortFormatter = SimpleDateFormat("MMM", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val istanbulTimeSecFormatter = SimpleDateFormat("HH:mm:ss", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val istanbulDateTimeFormatter = SimpleDateFormat("d MMM • HH:mm", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val dayMonthFormatter = SimpleDateFormat("d MMM", turkishLocale).apply {
        timeZone = istanbulTimeZone
    }
    private val rssDatePatterns = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "EEE, dd MMM yyyy HH:mm Z",
        "dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd HH:mm:ss"
    )

    private val fourDecimalFormatter = DecimalFormat("#,##0.0000", symbols)
    private val sixDecimalFormatter = DecimalFormat("#,##0.000000", symbols)

    private fun formatDynamicAmount(amount: Double): String {
        val a = abs(amount)
        return when {
            a == 0.0 -> "0,00"
            a < 0.000001 -> "0,00"
            a < 0.01 -> sixDecimalFormatter.format(amount)
            a < 1.0 -> fourDecimalFormatter.format(amount)
            else -> moneyFormatter.format(amount)
        }
    }

    fun formatTL(amount: Double): String {
        val clean = if (abs(amount) < 0.000001) 0.0 else amount
        return "${formatDynamicAmount(clean)} TL"
    }

    fun formatSignedTL(amount: Double): String {
        val clean = if (abs(amount) < 0.005) 0.0 else amount
        val prefix = if (clean > 0) "+" else if (clean < 0) "-" else ""
        return "$prefix${moneyFormatter.format(abs(clean))} TL"
    }

    fun formatPercent(value: Double): String {
        return "%${percentFormatter.format(value)}"
    }

    fun formatForeignPrice(price: Double, currency: String): String {
        val clean = if (abs(price) < 0.000001) 0.0 else price
        return "${formatDynamicAmount(clean)} $currency"
    }

    fun formatMoneyByCurrency(amount: Double, currency: String): String {
        return if (currency.equals("TL", ignoreCase = true) || currency.equals("TRY", ignoreCase = true)) {
            formatTL(amount)
        } else {
            formatForeignPrice(amount, currency)
        }
    }

    fun formatDayMonth(millis: Long): String = synchronized(dayMonthFormatter) { dayMonthFormatter.format(Date(millis)) }

    fun formatEditableNumber(value: Double): String {
        if (value <= 0.0) return ""
        val rounded = round2(value)
        return if (abs(rounded - rounded.toLong().toDouble()) < 0.0001) {
            rounded.toLong().toString()
        } else {
            val formatted = "%.2f".format(Locale.US, rounded).trimEnd('0').trimEnd('.')
            formatted.replace('.', ',')
        }
    }

    fun formatSignedPercent(value: Double): String {
        val prefix = if (value > 0) "+" else if (value < 0) "-" else ""
        return "$prefix%${percentFormatter.format(abs(value))}"
    }

    fun formatDate(millis: Long): String = synchronized(dateFormatter) { dateFormatter.format(Date(millis)) }

    fun formatShortDate(millis: Long): String = synchronized(shortDateFormatter) { shortDateFormatter.format(Date(millis)) }

    fun formatIstanbulTimeWithSeconds(millis: Long = System.currentTimeMillis()): String =
        synchronized(istanbulTimeSecFormatter) { istanbulTimeSecFormatter.format(Date(millis)) }

    fun formatIstanbulDateTime(millis: Long): String =
        synchronized(istanbulDateTimeFormatter) { istanbulDateTimeFormatter.format(Date(millis)) }

    fun parseRssPubDateToIstanbul(rawPubDate: String): Pair<Long, String> {
        val cleaned = rawPubDate.trim()
        if (cleaned.isEmpty()) return 0L to ""
        for (pattern in rssDatePatterns) {
            try {
                val parser = SimpleDateFormat(pattern, Locale.ENGLISH)
                if (!pattern.contains("Z") && !pattern.contains("z") && !pattern.contains("X")) {
                    parser.timeZone = java.util.TimeZone.getTimeZone("GMT")
                }
                val parsed = parser.parse(cleaned)
                if (parsed != null) {
                    val millis = parsed.time
                    return millis to formatIstanbulDateTime(millis)
                }
            } catch (_: Exception) {
                // try next pattern
            }
        }
        return 0L to ""
    }

    fun currentYearMonth(millis: Long = System.currentTimeMillis()): String =
        synchronized(yearMonthFormatter) { yearMonthFormatter.format(Date(millis)) }

    fun monthShortName(millis: Long): String = synchronized(monthShortFormatter) {
        monthShortFormatter.format(Date(millis))
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(turkishLocale) else it.toString() }
    }

    fun currentEpochDay(millis: Long = System.currentTimeMillis()): Long =
        millis / (24L * 60L * 60L * 1000L)

    fun round2(value: Double): Double = (value * 100.0).roundToLong() / 100.0

    /**
     * Parses user input supporting digits with '.' or ',' decimal separator, rejecting negatives.
     */
    fun parsePositiveOrZero(raw: String): Double? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return 0.0
        val normalized = if (trimmed.contains(",") && trimmed.contains(".")) {
            trimmed.replace(".", "").replace(",", ".")
        } else if (trimmed.contains(",")) {
            trimmed.replace(",", ".")
        } else {
            trimmed
        }
        val parsed = normalized.toDoubleOrNull() ?: return null
        return if (parsed < 0.0) null else round2(parsed)
    }

    fun sanitizeDecimalInput(input: String): String {
        val filtered = StringBuilder()
        var hasSeparator = false
        var decimalCount = 0
        for (ch in input) {
            if (ch.isDigit()) {
                if (!hasSeparator || decimalCount < 2) {
                    filtered.append(ch)
                    if (hasSeparator) decimalCount++
                }
            } else if ((ch == ',' || ch == '.') && !hasSeparator) {
                filtered.append(',')
                hasSeparator = true
            }
        }
        return filtered.toString()
    }

    private val emailRegex = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    fun isValidEmail(email: String): Boolean {
        val trimmed = email.trim()
        if (trimmed.isEmpty()) return true
        return emailRegex.matches(trimmed)
    }

    fun startOfMonthMillis(millis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun formatRelativeDays(dateMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val diffDays = ((nowMillis - dateMillis) / (24L * 60L * 60L * 1000L)).toInt()
        return when {
            diffDays <= 0 -> "Bugün"
            diffDays == 1 -> "1 gün önce"
            else -> "$diffDays gün önce"
        }
    }
}
