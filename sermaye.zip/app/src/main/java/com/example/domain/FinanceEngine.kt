package com.example.domain

import android.util.Log
import com.example.data.local.FundEntity
import com.example.data.local.FundSnapshotEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.UserProfile
import com.example.data.local.VaultBalancesEntity
import com.example.data.repo.LiveAssetQuote
import com.example.util.CurrencyUtils
import java.text.Collator
import java.util.Calendar
import java.util.Locale
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val MATH_TAG = "SermayeMath"
private const val DAY_MILLIS = 24L * 60L * 60L * 1000L
private const val MONTH_MILLIS = 30L * DAY_MILLIS

data class FundOptionSpec(
    val name: String,
    val riskLabel: String,
    val defaultMonthlyReturnPercent: Double
)

val AVAILABLE_FUND_OPTIONS = listOf(
    FundOptionSpec("Para Piyasası Fonu", "Düşük Risk", 3.2),
    FundOptionSpec("Altın Fonu", "Orta Risk", 3.8),
    FundOptionSpec("Hisse Senedi Fonu", "Yüksek Risk", 4.5),
    FundOptionSpec("Eurobond Fonu", "Orta Risk", 3.0),
    FundOptionSpec("Katılım Fonu", "Orta Risk", 3.5),
    FundOptionSpec("Bitcoin Fonu", "Çok Yüksek Risk", 6.0)
)

data class ComputedFund(
    val entity: FundEntity,
    val currentValue: Double,
    val profitTL: Double,
    val profitPercent: Double,
    val monthsElapsedFromPurchase: Int,
    val monthsElapsedFromBase: Int
)

data class MonthlyPoint(
    val label: String,
    val totalWealth: Double
)

enum class RiskProfileMode(
    val title: String,
    val shortTitle: String,
    val description: String,
    val allocations: List<Pair<String, Int>>
) {
    LOW(
        title = "Düşük Riskli - Güvenli",
        shortTitle = "Düşük Riskli",
        description = "Paran güvende kalsın, küçük küçük büyüsün.",
        allocations = listOf(
            "Para Piyasası Fonu" to 70,
            "Altın Fonu" to 30
        )
    ),
    BALANCED(
        title = "Dengeli - Orta",
        shortTitle = "Dengeli",
        description = "Hem güvenli hem büyüme.",
        allocations = listOf(
            "Para Piyasası Fonu" to 50,
            "Altın Fonu" to 30,
            "Hisse Senedi Fonu" to 20
        )
    ),
    AGGRESSIVE(
        title = "Agresif Büyüme - Riskli",
        shortTitle = "Agresif Büyüme",
        description = "Hızlı büyüme istiyorsun, ama riskin de yüksek.",
        allocations = listOf(
            "Hisse Senedi Fonu" to 40,
            "Bitcoin Fonu" to 30,
            "Altın Fonu" to 20,
            "Para Piyasası Fonu" to 10
        )
    )
}

data class AiRuleAdvice(
    val homeSummary: String,
    val alerts: List<String>,
    val weeklyPerformanceText: String,
    val fundSharePercent: Double,
    val monthsToStoreGoal: Double?,
    val bestFundName: String?,
    val weakestFundName: String?
)

data class PortfolioSummary(
    val storeBalance: Double,
    val idleFundCash: Double,
    val lockedFundValue: Double,
    val totalFundVault: Double,
    val selfBalance: Double,
    val totalWealth: Double,
    val thisMonthNetChange: Double,
    val thisMonthIncome: Double,
    val thisMonthExpense: Double = 0.0,
    val thisMonthTxCount: Int,
    val totalFundReturnTL: Double,
    val computedFunds: List<ComputedFund>,
    val growthSeries: List<MonthlyPoint>,
    val aiAdvice: AiRuleAdvice
)

enum class CashflowPeriod(val label: String, val monthsBack: Int?) {
    THIS_MONTH("Bu Ay", 0),
    THREE_MONTHS("Son 3 Ay", 2),
    SIX_MONTHS("Son 6 Ay", 5),
    ALL("Tümü", null)
}

data class CashflowCategoryStat(
    val category: String,
    val amount: Double,
    val sharePercent: Double,
    val count: Int
)

data class MonthlyCashflowBar(
    val label: String,
    val income: Double,
    val expense: Double
)

enum class InvestmentSortOption(val label: String) {
    DEFAULT("İlk Sıra (Önerilen)"),
    TOP_GAINERS("En Çok Yükselen ▲"),
    TOP_LOSERS("En Çok Düşen ▼"),
    PRICE_DESC("Fiyat: Yüksek → Düşük"),
    PRICE_ASC("Fiyat: Düşük → Yüksek"),
    NAME_ASC("İsim: A → Z")
}

data class IncomeExpenseReport(
    val period: CashflowPeriod,
    val totalIncome: Double,
    val totalExpense: Double,
    val netCashflow: Double,
    val savingsRatePercent: Double,
    val incomeCount: Int,
    val expenseCount: Int,
    val incomeCategories: List<CashflowCategoryStat>,
    val expenseCategories: List<CashflowCategoryStat>,
    val monthlyBars: List<MonthlyCashflowBar>,
    val periodTransactions: List<TransactionEntity>
)

data class SimulationResult(
    val futureValue: Double,
    val totalPrincipal: Double,
    val totalInterestEarned: Double,
    val projectedFundVault: Double,
    val projectedOtherVaults: Double,
    val monthlyPoints: List<MonthlyPoint>,
    val monthsToGoal: Double?
)

data class BestScenarioResult(
    val fundRatioPercent: Int,
    val monthlyReturnPercent: Double,
    val months: Int,
    val projectedTotal: Double
)

data class AiProfitPlan(
    val strategyTitle: String,
    val strategySummary: String,
    val currentMonthlyProfitTL: Double,
    val projectedMonthlyProfitTL: Double,
    val monthlyProfitBoostTL: Double,
    val yearlyCompoundBoostTL: Double,
    val idleCashOpportunityMonthlyTL: Double,
    val smartWeightedMonthlyReturnPercent: Double,
    val smartAllocations: List<Pair<String, Int>>,
    val actionableSteps: List<String>
)

enum class ChartRange(val label: String, val days: Int) {
    ONE_MONTH("1A", 30),
    THREE_MONTHS("3A", 90),
    SIX_MONTHS("6A", 180),
    ONE_YEAR("1Y", 365)
}

data class PricePoint(
    val timestampMillis: Long,
    val label: String,
    val price: Double
)

data class AssetForecastHorizon(
    val horizonLabel: String,
    val months: Int,
    val projectedChangePercent: Double,
    val projectedPrice: Double,
    val conservativePercent: Double,
    val optimisticPercent: Double
)

data class AssetStatisticalForecast(
    val currency: String,
    val currentPrice: Double,
    val change1MPercent: Double?,
    val change6MPercent: Double?,
    val change12MPercent: Double?,
    val realizedMonthlyDriftPercent: Double,
    val monthlyVolatilityPercent: Double,
    val trendSignal: String,
    val horizons: List<AssetForecastHorizon>
)

object FinanceEngine {

    fun computeFundMetrics(fund: FundEntity, nowMillis: Long = System.currentTimeMillis()): ComputedFund {
        val baseAmount = fund.manualOverrideValue ?: fund.investedAmount
        val baseDate = fund.manualOverrideDateMillis ?: fund.purchaseDateMillis

        val monthsFromBase = max(0, ((nowMillis - baseDate) / MONTH_MILLIS).toInt())
        val monthsFromPurchase = max(0, ((nowMillis - fund.purchaseDateMillis) / MONTH_MILLIS).toInt())

        val rate = fund.monthlyReturnPercent / 100.0
        val currentValue = CurrencyUtils.round2(baseAmount * (1.0 + rate).pow(monthsFromBase.toDouble()))
        val profit = CurrencyUtils.round2(currentValue - fund.investedAmount)
        val profitPercent = if (fund.investedAmount > 0.0) {
            CurrencyUtils.round2((profit / fund.investedAmount) * 100.0)
        } else {
            0.0
        }

        logMath(
            "Fon=${fund.fundType}, Yatirilan=${fund.investedAmount}, Baz=${baseAmount}, " +
                "Oran=%${fund.monthlyReturnPercent}, GecenAy=$monthsFromBase, Guncel=$currentValue, Kar=$profit (%$profitPercent)"
        )

        return ComputedFund(
            entity = fund,
            currentValue = currentValue,
            profitTL = profit,
            profitPercent = profitPercent,
            monthsElapsedFromPurchase = monthsFromPurchase,
            monthsElapsedFromBase = monthsFromBase
        )
    }

    fun computeOneMonthYield(fund: ComputedFund): Double {
        val rate = fund.entity.monthlyReturnPercent / 100.0
        val yieldAmount = CurrencyUtils.round2(fund.currentValue * rate)
        logMath("Aylik Getiri: Fon=${fund.entity.fundType}, Deger=${fund.currentValue}, Getiri=$yieldAmount")
        return max(0.0, yieldAmount)
    }

    private fun logMath(msg: String) {
        try {
            Log.d(MATH_TAG, msg)
        } catch (_: Throwable) {
            // Ignored in local JVM unit tests
        }
    }

    fun buildPortfolioSummary(
        profile: UserProfile,
        balances: VaultBalancesEntity,
        transactions: List<TransactionEntity>,
        funds: List<FundEntity>,
        snapshots: List<FundSnapshotEntity>,
        nowMillis: Long = System.currentTimeMillis()
    ): PortfolioSummary {
        val computedFunds = funds.map { computeFundMetrics(it, nowMillis) }
        val lockedFundValue = CurrencyUtils.round2(computedFunds.sumOf { it.currentValue })
        val totalFundReturnTL = CurrencyUtils.round2(computedFunds.sumOf { it.profitTL })
        val idleFundCash = CurrencyUtils.round2(balances.idleFundCash)
        val totalFundVault = CurrencyUtils.round2(idleFundCash + lockedFundValue)
        val storeBalance = CurrencyUtils.round2(balances.storeBalance)
        val selfBalance = CurrencyUtils.round2(balances.selfBalance)
        val totalWealth = CurrencyUtils.round2(storeBalance + totalFundVault + selfBalance)

        val monthStart = CurrencyUtils.startOfMonthMillis(nowMillis)
        val monthTxs = transactions.filter { it.dateMillis >= monthStart }
        val thisMonthIncome = CurrencyUtils.round2(
            monthTxs.filter { it.type == TransactionType.INPUT.name || it.type == TransactionType.FUND_YIELD.name }
                .sumOf { it.amount }
        )
        val thisMonthExpense = CurrencyUtils.round2(
            monthTxs.filter { it.type == TransactionType.EXPENSE.name }
                .sumOf { it.amount }
        )
        val thisMonthNetChange = CurrencyUtils.round2(thisMonthIncome - thisMonthExpense + totalFundReturnTL)

        val growthSeries = build12MonthGrowthSeries(
            transactions = transactions,
            currentTotalWealth = totalWealth,
            totalFundReturnTL = totalFundReturnTL,
            nowMillis = nowMillis
        )

        val aiAdvice = evaluateDeterministicAiRules(
            profile = profile,
            storeBalance = storeBalance,
            totalFundVault = totalFundVault,
            totalWealth = totalWealth,
            thisMonthIncome = thisMonthIncome,
            totalFundReturnTL = totalFundReturnTL,
            computedFunds = computedFunds,
            snapshots = snapshots,
            nowMillis = nowMillis
        )

        return PortfolioSummary(
            storeBalance = storeBalance,
            idleFundCash = idleFundCash,
            lockedFundValue = lockedFundValue,
            totalFundVault = totalFundVault,
            selfBalance = selfBalance,
            totalWealth = totalWealth,
            thisMonthNetChange = thisMonthNetChange,
            thisMonthIncome = thisMonthIncome,
            thisMonthExpense = thisMonthExpense,
            thisMonthTxCount = monthTxs.size,
            totalFundReturnTL = totalFundReturnTL,
            computedFunds = computedFunds,
            growthSeries = growthSeries,
            aiAdvice = aiAdvice
        )
    }

    private fun build12MonthGrowthSeries(
        transactions: List<TransactionEntity>,
        currentTotalWealth: Double,
        totalFundReturnTL: Double,
        nowMillis: Long
    ): List<MonthlyPoint> {
        if (transactions.isEmpty()) return emptyList()

        val sorted = transactions.sortedBy { it.dateMillis }
        val points = mutableListOf<MonthlyPoint>()

        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val monthEnds = mutableListOf<Long>()
        val monthLabels = mutableListOf<String>()

        for (i in 11 downTo 0) {
            val c = (cal.clone() as Calendar).apply {
                add(Calendar.MONTH, -i)
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            }
            monthEnds.add(c.timeInMillis)
            monthLabels.add(CurrencyUtils.monthShortName(c.timeInMillis))
        }

        val earliestTxDate = sorted.first().dateMillis
        for (idx in monthEnds.indices) {
            val endMillis = monthEnds[idx]
            if (endMillis < earliestTxDate && idx < 11) {
                continue
            }
            if (idx == 11) {
                points.add(MonthlyPoint(label = monthLabels[idx], totalWealth = currentTotalWealth))
                continue
            }
            val txsUpToEnd = sorted.filter { it.dateMillis <= endMillis }
            val netContributions = txsUpToEnd.sumOf { tx ->
                when (tx.type) {
                    TransactionType.INPUT.name, TransactionType.FUND_YIELD.name -> tx.amount
                    TransactionType.EXPENSE.name -> -tx.amount
                    else -> 0.0
                }
            }
            val netWorthAtEnd = CurrencyUtils.round2(max(0.0, netContributions))
            points.add(MonthlyPoint(label = monthLabels[idx], totalWealth = netWorthAtEnd))
        }

        return points
    }

    private fun evaluateDeterministicAiRules(
        profile: UserProfile,
        storeBalance: Double,
        totalFundVault: Double,
        totalWealth: Double,
        thisMonthIncome: Double,
        totalFundReturnTL: Double,
        computedFunds: List<ComputedFund>,
        snapshots: List<FundSnapshotEntity>,
        nowMillis: Long
    ): AiRuleAdvice {
        if (totalWealth <= 0.0 && computedFunds.isEmpty()) {
            return AiRuleAdvice(
                homeSummary = "Henüz veri yok, önce para ekle, ben sana özet çıkarayım.",
                alerts = listOf(
                    "Önce para ekle, sana öneri vereyim. Şu an hesap yapacak verin yok. Para ekleyince buraya gel, sana özel plan çıkarayım."
                ),
                weeklyPerformanceText = "Henüz haftalık fon verisi oluşmadı.",
                fundSharePercent = 0.0,
                monthsToStoreGoal = null,
                bestFundName = null,
                weakestFundName = null
            )
        }

        val alerts = mutableListOf<String>()
        val fundSharePercent = if (totalWealth > 0.0) {
            CurrencyUtils.round2((totalFundVault / totalWealth) * 100.0)
        } else {
            0.0
        }

        // Rule 1: Fund Vault / Total Wealth < 20%
        if (totalWealth > 0.0 && fundSharePercent < 20.0) {
            alerts.add(
                "Fon kasan toplam servetinin ${CurrencyUtils.formatPercent(fundSharePercent)}'i kadar, " +
                    "bu çok düşük. Önce fon kasanı güçlendir. Önümüzdeki 2 ay fon oranını %50'ye çıkarmanı öneririm."
            )
        }

        // Rule 2: Any fund losing for >= 2 months
        computedFunds.filter { it.profitTL < 0.0 && it.monthsElapsedFromPurchase >= 2 }.forEach { losing ->
            alerts.add(
                "${losing.entity.fundType} 2 aydır zarar ediyor (${CurrencyUtils.formatSignedTL(losing.profitTL)}, " +
                    "${CurrencyUtils.formatSignedPercent(losing.profitPercent)}). %50 kadarını Altın Fonu'na kaydırmayı düşün. " +
                    "Zarar eden fonda ısrar etme."
            )
        }

        // Rule 3: Any fund > 10% profit
        computedFunds.filter { it.profitPercent > 10.0 }.forEach { winner ->
            alerts.add(
                "${winner.entity.fundType} çok iyi gidiyor (${CurrencyUtils.formatSignedTL(winner.profitTL)}). " +
                    "Karının bir kısmını alıp boştaki paraya eklemeyi düşünebilirsin."
            )
        }

        // Rule 4 & 5: Store Goal months remaining = (Hedef Tutar - Mağaza Kasası) / Aylık Mağaza Payı
        val monthlyStoreShare = CurrencyUtils.round2(profile.monthlyIncome * (profile.storeRatio / 100.0))
        val monthsToStoreGoal: Double? = if (profile.storeTargetAmount > 0.0) {
            val remaining = max(0.0, profile.storeTargetAmount - storeBalance)
            if (remaining <= 0.0) {
                0.0
            } else if (monthlyStoreShare > 0.0) {
                CurrencyUtils.round2(remaining / monthlyStoreShare)
            } else {
                null
            }
        } else {
            null
        }

        if (monthsToStoreGoal != null && monthsToStoreGoal > 0.0) {
            val roundedMonths = max(1, monthsToStoreGoal.roundToInt())
            if (monthsToStoreGoal < 2.0) {
                alerts.add(
                    "Mağaza açmana $roundedMonths ay kaldı, paranı riskli fona koyma, Para Piyasası Fonu'nda likit tut. " +
                        "Çünkü yakında paraya ihtiyacın olacak."
                )
            } else if (monthsToStoreGoal > 12.0) {
                alerts.add(
                    "Mağaza açmana daha $roundedMonths ay var, paranı uzun vadeli fonlarda değerlendirebilirsin."
                )
            }
        } else if (profile.storeTargetAmount > 0.0 && storeBalance >= profile.storeTargetAmount) {
            alerts.add("Tebrikler! Mağaza açma hedef tutarına ulaştın (${CurrencyUtils.formatTL(profile.storeTargetAmount)}).")
        }

        if (alerts.isEmpty()) {
            alerts.add(
                "Portföy dağılımın dengeli görünüyor. Fon oranın ${CurrencyUtils.formatPercent(fundSharePercent)} seviyesinde."
            )
        }

        val bestFund = computedFunds.maxByOrNull { it.profitTL }
        val weakestFund = computedFunds.minByOrNull { it.profitTL }

        // Weekly performance = Today Total Fund Value - 7 Days Ago Total Fund Value
        val todayDay = CurrencyUtils.currentEpochDay(nowMillis)
        val weekAgoDay = todayDay - 7L
        val baselineSnapshot = snapshots.lastOrNull { it.epochDay <= weekAgoDay } ?: snapshots.firstOrNull()
        val weeklyPerformanceText = if (baselineSnapshot != null && computedFunds.isNotEmpty()) {
            val weeklyDiff = CurrencyUtils.round2(totalFundVault - baselineSnapshot.totalFundValue)
            val weakNote = if (weakestFund != null && weakestFund != bestFund) {
                ", ${weakestFund.entity.fundType} zayıf kaldı (${CurrencyUtils.formatSignedTL(weakestFund.profitTL)})."
            } else {
                "."
            }
            "Bu hafta fonların ${CurrencyUtils.formatSignedTL(weeklyDiff)} değişti$weakNote"
        } else if (computedFunds.isNotEmpty()) {
            "Bu hafta fonların toplam getirisi ${CurrencyUtils.formatSignedTL(totalFundReturnTL)}."
        } else {
            "Haftalık fon karşılaştırması için önce fon yatırımı yap."
        }

        // Home 2-sentence deterministic summary
        val sentence1 = "Bu ay ${CurrencyUtils.formatTL(thisMonthIncome)} kazandın, " +
            "fonların ${CurrencyUtils.formatSignedTL(totalFundReturnTL)} getirdi."
        val sentence2 = when {
            profile.storeTargetAmount <= 0.0 ->
                "Toplam servetinin ${CurrencyUtils.formatPercent(fundSharePercent)}'i fon kasasında."
            storeBalance >= profile.storeTargetAmount ->
                "Mağaza açma hedefine ulaştın!"
            monthsToStoreGoal != null ->
                "Mağaza hedefine ${max(1, monthsToStoreGoal.roundToInt())} ay kaldı."
            else ->
                "Mağaza hedefine kalan tutar ${CurrencyUtils.formatTL(profile.storeTargetAmount - storeBalance)}."
        }

        return AiRuleAdvice(
            homeSummary = "$sentence1 $sentence2",
            alerts = alerts,
            weeklyPerformanceText = weeklyPerformanceText,
            fundSharePercent = fundSharePercent,
            monthsToStoreGoal = monthsToStoreGoal,
            bestFundName = bestFund?.entity?.fundType,
            weakestFundName = weakestFund?.entity?.fundType
        )
    }

    /**
     * Compound future value for total wealth:
     * Fund Vault = MonthlyFundInvest * (((1 + r)^n - 1) / r) + CurrentFundVault * (1 + r)^n
     * Other Vaults (Store + Self) = CurrentOtherVaults + MonthlyOtherSavings * n
     * Total Future Wealth = Fund Vault + Other Vaults (always >= currentWealth + monthlyIncome * n)
     */
    fun simulateFutureValue(
        currentWealth: Double,
        currentFundVault: Double,
        monthlyIncome: Double,
        fundRatioPercent: Int,
        monthlyReturnPercent: Double,
        months: Int,
        storeTargetAmount: Double,
        storeBalance: Double,
        storeRatioPercent: Int
    ): SimulationResult {
        val r = monthlyReturnPercent / 100.0
        val cleanFundRatio = fundRatioPercent.coerceIn(0, 100)
        val monthlyFundInvest = monthlyIncome * (cleanFundRatio / 100.0)
        val monthlyOtherSavings = monthlyIncome - monthlyFundInvest
        val baseFund = currentFundVault.coerceIn(0.0, currentWealth)
        val baseOther = max(0.0, currentWealth - baseFund)
        val points = mutableListOf<MonthlyPoint>()

        var lastFundVal = baseFund
        var lastOtherVal = baseOther

        for (m in 0..months) {
            val fundFuture = if (r <= 0.0) {
                baseFund + monthlyFundInvest * m
            } else {
                val factor = (1.0 + r).pow(m.toDouble())
                monthlyFundInvest * ((factor - 1.0) / r) + baseFund * factor
            }
            val otherFuture = baseOther + monthlyOtherSavings * m
            val totalAtMonth = CurrencyUtils.round2(fundFuture + otherFuture)
            if (m == months) {
                lastFundVal = CurrencyUtils.round2(fundFuture)
                lastOtherVal = CurrencyUtils.round2(otherFuture)
            }
            points.add(MonthlyPoint(label = "$m. Ay", totalWealth = totalAtMonth))
        }

        val finalValue = points.lastOrNull()?.totalWealth ?: currentWealth
        val totalPrincipal = CurrencyUtils.round2(currentWealth + monthlyIncome * months)
        val totalInterestEarned = CurrencyUtils.round2(max(0.0, finalValue - totalPrincipal))

        val monthlyStoreSavings = CurrencyUtils.round2(monthlyIncome * (storeRatioPercent / 100.0))
        val monthsToGoal = if (storeTargetAmount > 0.0) {
            val remaining = max(0.0, storeTargetAmount - storeBalance)
            if (remaining <= 0.0) 0.0
            else if (monthlyStoreSavings > 0.0) CurrencyUtils.round2(remaining / monthlyStoreSavings)
            else null
        } else null

        return SimulationResult(
            futureValue = finalValue,
            totalPrincipal = totalPrincipal,
            totalInterestEarned = totalInterestEarned,
            projectedFundVault = lastFundVal,
            projectedOtherVaults = lastOtherVal,
            monthlyPoints = points,
            monthsToGoal = monthsToGoal
        )
    }

    /**
     * Tests 100 combinations (10 fund ratios 10%..60% x 10 returns 1%..10%) using the exact same total wealth formula.
     */
    fun findBestScenario(
        currentWealth: Double,
        currentFundVault: Double,
        monthlyIncome: Double,
        months: Int
    ): BestScenarioResult {
        val ratioCandidates = listOf(10, 15, 20, 25, 30, 35, 40, 45, 50, 60)
        val returnCandidates = listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0)

        val baseFund = currentFundVault.coerceIn(0.0, currentWealth)
        val baseOther = max(0.0, currentWealth - baseFund)

        var bestRatio = 60
        var bestReturn = 10.0
        var bestFV = -1.0

        for (ratio in ratioCandidates) {
            val monthlyFundInvest = monthlyIncome * (ratio / 100.0)
            val monthlyOtherSavings = monthlyIncome - monthlyFundInvest
            for (ret in returnCandidates) {
                val r = ret / 100.0
                val factor = (1.0 + r).pow(months.toDouble())
                val fundFuture = monthlyFundInvest * ((factor - 1.0) / r) + baseFund * factor
                val otherFuture = baseOther + monthlyOtherSavings * months
                val totalFV = fundFuture + otherFuture
                if (totalFV > bestFV) {
                    bestFV = totalFV
                    bestRatio = ratio
                    bestReturn = ret
                }
            }
        }

        return BestScenarioResult(
            fundRatioPercent = bestRatio,
            monthlyReturnPercent = bestReturn,
            months = months,
            projectedTotal = CurrencyUtils.round2(bestFV)
        )
    }

    /**
     * Rebalances 3 percentage sliders so Store + Fund + Self ALWAYS equals 100.
     * Index: 0 = Store, 1 = Fund, 2 = Self.
     */
    fun rebalanceRatios(changedIndex: Int, requestedValue: Int, current: Triple<Int, Int, Int>): Triple<Int, Int, Int> {
        val clamped = requestedValue.coerceIn(0, 100)
        val remaining = 100 - clamped
        val arr = intArrayOf(current.first, current.second, current.third)
        arr[changedIndex] = clamped

        val otherIndices = (0..2).filter { it != changedIndex }
        val i1 = otherIndices[0]
        val i2 = otherIndices[1]
        val oldOtherSum = arr[i1] + arr[i2]

        if (oldOtherSum == 0) {
            arr[i1] = remaining / 2
            arr[i2] = remaining - arr[i1]
        } else {
            arr[i1] = floor(remaining * (arr[i1].toDouble() / oldOtherSum)).toInt().coerceIn(0, remaining)
            arr[i2] = remaining - arr[i1]
        }

        return Triple(arr[0], arr[1], arr[2])
    }

    /**
     * Profit-maximizing AI planner: combines user's exact vault balances, active funds,
     * store-goal urgency, idle cash opportunity cost, and live market/news signals.
     */
    fun buildAiProfitPlan(
        summary: PortfolioSummary,
        selectedRisk: RiskProfileMode,
        fundSignalScores: Map<String, Int> = emptyMap(),
        marketAssetChanges: Map<String, Double> = emptyMap()
    ): AiProfitPlan {
        val totalFund = summary.totalFundVault
        val currentMonthlyProfit = CurrencyUtils.round2(
            summary.computedFunds.sumOf { f ->
                f.currentValue * (f.entity.monthlyReturnPercent / 100.0)
            }
        )
        val idleOpportunityMonthly = CurrencyUtils.round2(summary.idleFundCash * 0.032)

        // Start from selected risk weights and dynamically tilt using live news + market signals
        val baseWeights = linkedMapOf(
            "Para Piyasası Fonu" to 0,
            "Altın Fonu" to 0,
            "Hisse Senedi Fonu" to 0,
            "Eurobond Fonu" to 0,
            "Bitcoin Fonu" to 0
        )
        selectedRisk.allocations.forEach { (name, pct) ->
            baseWeights[name] = (baseWeights[name] ?: 0) + pct
        }

        val monthsToGoal = summary.aiAdvice.monthsToStoreGoal
        val nearStoreGoal = monthsToGoal != null && monthsToGoal > 0.0 && monthsToGoal < 3.0

        if (nearStoreGoal) {
            // Preserve store liquidity when opening goal is imminent
            baseWeights["Para Piyasası Fonu"] = (baseWeights["Para Piyasası Fonu"] ?: 0) + 25
            baseWeights["Bitcoin Fonu"] = max(0, (baseWeights["Bitcoin Fonu"] ?: 0) - 20)
            baseWeights["Hisse Senedi Fonu"] = max(5, (baseWeights["Hisse Senedi Fonu"] ?: 0) - 5)
        } else {
            // Apply live news & market momentum tilts capped responsibly per risk profile
            val goldSig = fundSignalScores["Altın Fonu"] ?: 0
            val btcSig = fundSignalScores["Bitcoin Fonu"] ?: 0
            val stockSig = fundSignalScores["Hisse Senedi Fonu"] ?: 0
            val moneySig = fundSignalScores["Para Piyasası Fonu"] ?: 0
            val euroSig = fundSignalScores["Eurobond Fonu"] ?: 0

            val btcChg = marketAssetChanges["bitcoin"] ?: 0.0
            val goldChg = marketAssetChanges["gram_altin"] ?: 0.0

            if (goldSig > 0 || goldChg >= 0.8) {
                baseWeights["Altın Fonu"] = (baseWeights["Altın Fonu"] ?: 0) + 10
            }
            if (stockSig > 0) {
                baseWeights["Hisse Senedi Fonu"] = (baseWeights["Hisse Senedi Fonu"] ?: 0) + 8
            } else if (stockSig < 0) {
                baseWeights["Hisse Senedi Fonu"] = max(0, (baseWeights["Hisse Senedi Fonu"] ?: 0) - 8)
                baseWeights["Para Piyasası Fonu"] = (baseWeights["Para Piyasası Fonu"] ?: 0) + 8
            }
            if (selectedRisk != RiskProfileMode.LOW && (btcSig > 0 || btcChg >= 1.5)) {
                baseWeights["Bitcoin Fonu"] = (baseWeights["Bitcoin Fonu"] ?: 0) + 8
            } else if (btcSig < 0 || btcChg <= -2.5) {
                val trim = minOf(10, baseWeights["Bitcoin Fonu"] ?: 0)
                baseWeights["Bitcoin Fonu"] = (baseWeights["Bitcoin Fonu"] ?: 0) - trim
                baseWeights["Altın Fonu"] = (baseWeights["Altın Fonu"] ?: 0) + trim
            }
            if (moneySig > 0) {
                baseWeights["Para Piyasası Fonu"] = (baseWeights["Para Piyasası Fonu"] ?: 0) + 5
            }
            if (euroSig > 0) {
                baseWeights["Eurobond Fonu"] = (baseWeights["Eurobond Fonu"] ?: 0) + 8
            }
        }

        // Trim any losing funds held by user so AI steers capital away from 2+ month losers
        summary.computedFunds
            .filter { it.profitTL < 0.0 && it.monthsElapsedFromPurchase >= 2 }
            .forEach { loser ->
                val cur = baseWeights[loser.entity.fundType] ?: 0
                if (cur > 10) {
                    val shift = cur / 2
                    baseWeights[loser.entity.fundType] = cur - shift
                    baseWeights["Para Piyasası Fonu"] = (baseWeights["Para Piyasası Fonu"] ?: 0) + shift
                }
            }

        // Normalize positive entries so total ALWAYS equals 100%
        val positiveEntries = baseWeights.filterValues { it > 0 }.toList()
        val rawSum = positiveEntries.sumOf { it.second }.coerceAtLeast(1)
        val normalized = mutableListOf<Pair<String, Int>>()
        var assigned = 0
        positiveEntries.forEachIndexed { idx, (name, rawVal) ->
            val pct = if (idx == positiveEntries.lastIndex) {
                max(0, 100 - assigned)
            } else {
                val scaled = floor((rawVal.toDouble() / rawSum.toDouble()) * 100.0).toInt()
                assigned += scaled
                scaled
            }
            if (pct > 0) {
                normalized.add(name to pct)
            }
        }
        val smartAllocations = if (normalized.isEmpty()) selectedRisk.allocations else normalized

        val rateByFund = AVAILABLE_FUND_OPTIONS.associate { it.name to it.defaultMonthlyReturnPercent }
        val weightedRatePercent = CurrencyUtils.round2(
            smartAllocations.sumOf { (name, pct) ->
                (rateByFund[name] ?: 3.5) * (pct / 100.0)
            }
        )

        val projectedMonthlyProfit = CurrencyUtils.round2(totalFund * (weightedRatePercent / 100.0))
        val monthlyBoost = CurrencyUtils.round2(max(0.0, projectedMonthlyProfit - currentMonthlyProfit))

        // 12-month compound projection comparison
        val currentEffRate = if (totalFund > 0.0) currentMonthlyProfit / totalFund else 0.0
        val current12mWealth = totalFund * (1.0 + currentEffRate).pow(12.0)
        val projected12mWealth = totalFund * (1.0 + weightedRatePercent / 100.0).pow(12.0)
        val yearlyCompoundBoost = CurrencyUtils.round2(max(0.0, projected12mWealth - current12mWealth))

        val steps = mutableListOf<String>()
        if (summary.idleFundCash > 0.0) {
            steps.add(
                "Boştaki ${CurrencyUtils.formatTL(summary.idleFundCash)} nakdin şu an 0 TL üretiyor. " +
                    "Bunu hemen plana bağlarsan en az ${CurrencyUtils.formatTL(idleOpportunityMonthly)}/ay ek kâr başlatırsın."
            )
        }
        if (monthlyBoost > 0.0) {
            steps.add(
                "Önerilen akıllı dağılıma geçerek aylık beklenen fon kârını " +
                    "${CurrencyUtils.formatTL(currentMonthlyProfit)}'den ${CurrencyUtils.formatTL(projectedMonthlyProfit)}'ye çıkarabilirsin " +
                    "(12 ayda bileşik +${CurrencyUtils.formatTL(yearlyCompoundBoost)} fark)."
            )
        } else if (totalFund > 0.0) {
            steps.add(
                "Mevcut fonların zaten yüksek verimle (${CurrencyUtils.formatTL(currentMonthlyProfit)}/ay) çalışıyor; " +
                    "yeni nakit girdikçe boştaki parayı sıfırda bırakma."
            )
        }
        val winners = summary.computedFunds.filter { it.profitPercent >= 10.0 }
        if (winners.isNotEmpty()) {
            val topWinner = winners.maxBy { it.profitPercent }
            val takeProfit = CurrencyUtils.round2(topWinner.profitTL * 0.30)
            steps.add(
                "${topWinner.entity.fundType} %${CurrencyUtils.round2(topWinner.profitPercent)} kârda. " +
                    "Kazancının %30'unu (${CurrencyUtils.formatTL(takeProfit)}) realize edip güvenli fona kilitleyerek kârı koru."
            )
        }
        if (nearStoreGoal) {
            val goalMonths = monthsToGoal ?: 1.0
            steps.add(
                "Mağaza hedefine ${max(1, goalMonths.roundToInt())} ay kaldı: Ana sermayeyi riske atma, ağırlığı Para Piyasası Fonu'nda tut."
            )
        }
        val hasSignals = fundSignalScores.values.any { it != 0 }
        if (hasSignals) {
            val bestSignal = fundSignalScores.maxByOrNull { it.value }
            if (bestSignal != null && bestSignal.value > 0) {
                steps.add(
                    "Canlı haber akışı ${bestSignal.key} lehine (+${bestSignal.value} olumlu sinyal) dönmüş durumda; ağırlık buna göre artırıldı."
                )
            }
        }

        val strategyTitle = when {
            nearStoreGoal -> "Hedef Koruma + Likit Getiri Planı"
            hasSignals -> "${selectedRisk.shortTitle} + Canlı Piyasa Uyumlu Kâr Planı"
            else -> "${selectedRisk.shortTitle} Kâr Optimizasyon Planı"
        }
        val strategySummary = if (totalFund <= 0.0) {
            "Fon kasan şu an 0,00 TL. Fon kasana para ekleyince AI kâr planı gerçek getiri farkını hesaplayacak."
        } else {
            "Tahmini aylık getiri ${CurrencyUtils.formatPercent(weightedRatePercent)} • Aylık beklenen kazanç ${CurrencyUtils.formatTL(projectedMonthlyProfit)}"
        }

        return AiProfitPlan(
            strategyTitle = strategyTitle,
            strategySummary = strategySummary,
            currentMonthlyProfitTL = currentMonthlyProfit,
            projectedMonthlyProfitTL = projectedMonthlyProfit,
            monthlyProfitBoostTL = monthlyBoost,
            yearlyCompoundBoostTL = yearlyCompoundBoost,
            idleCashOpportunityMonthlyTL = idleOpportunityMonthly,
            smartWeightedMonthlyReturnPercent = weightedRatePercent,
            smartAllocations = smartAllocations,
            actionableSteps = steps
        )
    }

    /**
     * Builds deterministic statistical 1, 3, 6, and 12-month projections from real historical prices
     * using damped blended momentum and realized daily volatility.
     */
    fun buildAssetForecast(
        points: List<PricePoint>,
        currentPrice: Double,
        currency: String,
        fallbackMonthlyReturnPercent: Double? = null
    ): AssetStatisticalForecast {
        val sorted = points.filter { it.price > 0.0 }.sortedBy { it.timestampMillis }
        val effectiveCurrent = if (currentPrice > 0.0) currentPrice else sorted.lastOrNull()?.price ?: 0.0

        if (sorted.size < 5 || effectiveCurrent <= 0.0) {
            val baseMonthly = (fallbackMonthlyReturnPercent ?: 3.2).coerceIn(-10.0, 12.0)
            val vol = 2.0
            val horizons = listOf(1, 3, 6, 12).map { m ->
                val projPct = CurrencyUtils.round2((((1.0 + baseMonthly / 100.0).pow(m.toDouble())) - 1.0) * 100.0)
                val band = CurrencyUtils.round2(vol * sqrt(m.toDouble()))
                AssetForecastHorizon(
                    horizonLabel = "$m Aylık",
                    months = m,
                    projectedChangePercent = projPct,
                    projectedPrice = CurrencyUtils.round2(effectiveCurrent * (1.0 + projPct / 100.0)),
                    conservativePercent = CurrencyUtils.round2(projPct - band),
                    optimisticPercent = CurrencyUtils.round2(projPct + band)
                )
            }
            return AssetStatisticalForecast(
                currency = currency,
                currentPrice = effectiveCurrent,
                change1MPercent = null,
                change6MPercent = null,
                change12MPercent = null,
                realizedMonthlyDriftPercent = CurrencyUtils.round2(baseMonthly),
                monthlyVolatilityPercent = vol,
                trendSignal = if (baseMonthly >= 2.0) "Pozitif Sabit Getiri ▲" else "Yatay / İzle ●",
                horizons = horizons
            )
        }

        val lastTs = sorted.last().timestampMillis
        fun changeSinceDaysAgo(days: Int): Double? {
            val targetTs = lastTs - days.toLong() * DAY_MILLIS
            val basePoint = sorted.firstOrNull { it.timestampMillis >= targetTs } ?: return null
            if (basePoint.timestampMillis > lastTs - (days / 2L) * DAY_MILLIS) return null
            if (basePoint.price <= 0.0) return null
            return CurrencyUtils.round2(((effectiveCurrent - basePoint.price) / basePoint.price) * 100.0)
        }

        val change1M = changeSinceDaysAgo(30)
        val change3M = changeSinceDaysAgo(90)
        val change6M = changeSinceDaysAgo(180)
        val change12M = if (sorted.first().price > 0.0 &&
            (lastTs - sorted.first().timestampMillis) >= 200L * DAY_MILLIS
        ) {
            CurrencyUtils.round2(((effectiveCurrent - sorted.first().price) / sorted.first().price) * 100.0)
        } else {
            changeSinceDaysAgo(350)
        }

        // Convert multi-horizon cumulative returns to monthly equivalent rates with safe bounds
        val monthlySamples = mutableListOf<Pair<Double, Double>>() // rate to weight
        change1M?.let { pct ->
            val r = (1.0 + pct / 100.0).coerceAtLeast(0.5) - 1.0
            monthlySamples.add((r * 100.0).coerceIn(-12.0, 12.0) to 0.25)
        }
        change3M?.let { pct ->
            val r = (1.0 + pct / 100.0).coerceAtLeast(0.3).pow(1.0 / 3.0) - 1.0
            monthlySamples.add((r * 100.0).coerceIn(-10.0, 10.0) to 0.30)
        }
        change6M?.let { pct ->
            val r = (1.0 + pct / 100.0).coerceAtLeast(0.2).pow(1.0 / 6.0) - 1.0
            monthlySamples.add((r * 100.0).coerceIn(-9.0, 9.0) to 0.25)
        }
        change12M?.let { pct ->
            val r = (1.0 + pct / 100.0).coerceAtLeast(0.1).pow(1.0 / 12.0) - 1.0
            monthlySamples.add((r * 100.0).coerceIn(-8.0, 8.0) to 0.20)
        }

        val totalW = monthlySamples.sumOf { it.second }.coerceAtLeast(1.0)
        val rawMonthlyDrift = if (monthlySamples.isEmpty()) {
            fallbackMonthlyReturnPercent ?: 2.0
        } else {
            monthlySamples.sumOf { it.first * it.second } / totalW
        }
        val monthlyDrift = CurrencyUtils.round2(rawMonthlyDrift.coerceIn(-9.0, 9.0))

        // Daily volatility -> scaled monthly volatility
        val dailyReturns = (1 until sorted.size).mapNotNull { i ->
            val prev = sorted[i - 1].price
            val curr = sorted[i].price
            if (prev > 0.0) (curr - prev) / prev else null
        }
        val meanDaily = if (dailyReturns.isNotEmpty()) dailyReturns.average() else 0.0
        val variance = if (dailyReturns.size > 1) {
            dailyReturns.sumOf { (it - meanDaily) * (it - meanDaily) } / (dailyReturns.size - 1)
        } else 0.0002
        val dailyStd = sqrt(variance)
        val monthlyVol = CurrencyUtils.round2((dailyStd * sqrt(25.0) * 100.0).coerceIn(0.8, 28.0))

        val trendSignal = when {
            monthlyDrift >= 3.5 && (change1M ?: 0.0) >= 0.0 -> "Güçlü Yükseliş Trendi ▲"
            monthlyDrift >= 1.0 -> "Pozitif Yönlü Eğilim ▲"
            monthlyDrift <= -1.5 -> "Zayıf / Düşüş Baskısı ▼"
            else -> "Yatay / Dengeli Seyir ●"
        }

        // Apply slight mean-reversion damping over longer horizons (6m / 12m) for realism
        val horizons = listOf(1, 3, 6, 12).map { m ->
            val damping = when (m) {
                1 -> 1.0
                3 -> 0.92
                6 -> 0.84
                else -> 0.75
            }
            val effMonthly = (monthlyDrift * damping) / 100.0
            val projPct = CurrencyUtils.round2((((1.0 + effMonthly).pow(m.toDouble())) - 1.0) * 100.0)
            val projPrice = CurrencyUtils.round2(max(0.01, effectiveCurrent * (1.0 + projPct / 100.0)))
            val band = CurrencyUtils.round2(monthlyVol * sqrt(m.toDouble()) * 0.70)
            AssetForecastHorizon(
                horizonLabel = "$m Aylık",
                months = m,
                projectedChangePercent = projPct,
                projectedPrice = projPrice,
                conservativePercent = CurrencyUtils.round2(projPct - band),
                optimisticPercent = CurrencyUtils.round2(projPct + band)
            )
        }

        return AssetStatisticalForecast(
            currency = currency,
            currentPrice = effectiveCurrent,
            change1MPercent = change1M,
            change6MPercent = change6M,
            change12MPercent = change12M,
            realizedMonthlyDriftPercent = monthlyDrift,
            monthlyVolatilityPercent = monthlyVol,
            trendSignal = trendSignal,
            horizons = horizons
        )
    }

    fun buildIncomeExpenseReport(
        transactions: List<TransactionEntity>,
        period: CashflowPeriod,
        nowMillis: Long = System.currentTimeMillis()
    ): IncomeExpenseReport {
        val periodStartMillis = if (period.monthsBack != null) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = nowMillis
                add(Calendar.MONTH, -period.monthsBack)
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            cal.timeInMillis
        } else {
            0L
        }

        val periodTxs = transactions
            .filter { it.dateMillis >= periodStartMillis }
            .sortedByDescending { it.dateMillis }

        val incomeTxs = periodTxs.filter {
            it.type == TransactionType.INPUT.name || it.type == TransactionType.FUND_YIELD.name
        }
        val expenseTxs = periodTxs.filter {
            it.type == TransactionType.EXPENSE.name
        }

        val totalIncome = CurrencyUtils.round2(incomeTxs.sumOf { it.amount })
        val totalExpense = CurrencyUtils.round2(expenseTxs.sumOf { it.amount })
        val netCashflow = CurrencyUtils.round2(totalIncome - totalExpense)
        val savingsRatePercent = if (totalIncome > 0.01) {
            CurrencyUtils.round2(((netCashflow / totalIncome) * 100.0).coerceIn(-100.0, 100.0))
        } else {
            0.0
        }

        val incomeCategories = buildCategoryStats(
            txs = incomeTxs,
            totalAmount = totalIncome,
            normalizeLabel = { raw -> raw.ifBlank { "Diğer Gelir" } }
        )

        val expenseCategories = buildCategoryStats(
            txs = expenseTxs,
            totalAmount = totalExpense,
            normalizeLabel = { raw ->
                val cleaned = raw.substringAfter("•", raw).trim()
                cleaned.ifBlank { "Diğer Gider" }
            }
        )

        // Last 6 calendar months comparison bars
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val monthlyBars = (5 downTo 0).map { offset ->
            val startCal = (cal.clone() as Calendar).apply {
                add(Calendar.MONTH, -offset)
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val endCal = (startCal.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            }
            val startMs = startCal.timeInMillis
            val endMs = endCal.timeInMillis
            val monthSlice = transactions.filter { it.dateMillis in startMs..endMs }
            val monthInc = CurrencyUtils.round2(
                monthSlice.filter { it.type == TransactionType.INPUT.name || it.type == TransactionType.FUND_YIELD.name }
                    .sumOf { it.amount }
            )
            val monthExp = CurrencyUtils.round2(
                monthSlice.filter { it.type == TransactionType.EXPENSE.name }
                    .sumOf { it.amount }
            )
            MonthlyCashflowBar(
                label = CurrencyUtils.monthShortName(startMs),
                income = monthInc,
                expense = monthExp
            )
        }

        return IncomeExpenseReport(
            period = period,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            netCashflow = netCashflow,
            savingsRatePercent = savingsRatePercent,
            incomeCount = incomeTxs.size,
            expenseCount = expenseTxs.size,
            incomeCategories = incomeCategories,
            expenseCategories = expenseCategories,
            monthlyBars = monthlyBars,
            periodTransactions = periodTxs
        )
    }

    private fun buildCategoryStats(
        txs: List<TransactionEntity>,
        totalAmount: Double,
        normalizeLabel: (String) -> String
    ): List<CashflowCategoryStat> {
        if (txs.isEmpty() || totalAmount <= 0.0) return emptyList()
        return txs.groupBy { normalizeLabel(it.sourceOrCategory) }
            .map { (cat, list) ->
                val sum = CurrencyUtils.round2(list.sumOf { it.amount })
                val pct = CurrencyUtils.round2((sum / totalAmount) * 100.0)
                CashflowCategoryStat(
                    category = cat,
                    amount = sum,
                    sharePercent = pct,
                    count = list.size
                )
            }
            .sortedByDescending { it.amount }
    }

    fun sortLiveAssetQuotes(
        quotes: List<LiveAssetQuote>,
        sortOption: InvestmentSortOption
    ): List<LiveAssetQuote> {
        if (quotes.size <= 1 || sortOption == InvestmentSortOption.DEFAULT) return quotes
        val trCollator = Collator.getInstance(Locale.forLanguageTag("tr-TR")).apply {
            strength = Collator.PRIMARY
        }
        val nameComparator = Comparator<LiveAssetQuote> { a, b -> trCollator.compare(a.name, b.name) }
        return when (sortOption) {
            InvestmentSortOption.DEFAULT -> quotes
            InvestmentSortOption.TOP_GAINERS -> quotes.sortedWith(
                compareByDescending<LiveAssetQuote> { it.changePercent24h ?: Double.NEGATIVE_INFINITY }
                    .thenComparing(nameComparator)
            )
            InvestmentSortOption.TOP_LOSERS -> quotes.sortedWith(
                compareBy<LiveAssetQuote> { it.changePercent24h ?: Double.POSITIVE_INFINITY }
                    .thenComparing(nameComparator)
            )
            InvestmentSortOption.PRICE_DESC -> quotes.sortedByDescending { it.price }
            InvestmentSortOption.PRICE_ASC -> quotes.sortedBy { it.price }
            InvestmentSortOption.NAME_ASC -> quotes.sortedWith(nameComparator)
        }
    }

    fun sortComputedFunds(
        funds: List<ComputedFund>,
        sortOption: InvestmentSortOption
    ): List<ComputedFund> {
        if (funds.size <= 1 || sortOption == InvestmentSortOption.DEFAULT) return funds
        val trCollator = Collator.getInstance(Locale.forLanguageTag("tr-TR")).apply {
            strength = Collator.PRIMARY
        }
        return when (sortOption) {
            InvestmentSortOption.DEFAULT -> funds
            InvestmentSortOption.TOP_GAINERS -> funds.sortedByDescending { it.profitPercent }
            InvestmentSortOption.TOP_LOSERS -> funds.sortedBy { it.profitPercent }
            InvestmentSortOption.PRICE_DESC -> funds.sortedByDescending { it.currentValue }
            InvestmentSortOption.PRICE_ASC -> funds.sortedBy { it.currentValue }
            InvestmentSortOption.NAME_ASC -> funds.sortedWith { a, b -> trCollator.compare(a.entity.fundType, b.entity.fundType) }
        }
    }

    fun sortFundOptionSpecs(
        options: List<FundOptionSpec>,
        sortOption: InvestmentSortOption
    ): List<FundOptionSpec> {
        if (options.size <= 1 || sortOption == InvestmentSortOption.DEFAULT) return options
        val trCollator = Collator.getInstance(Locale.forLanguageTag("tr-TR")).apply {
            strength = Collator.PRIMARY
        }
        return when (sortOption) {
            InvestmentSortOption.DEFAULT -> options
            InvestmentSortOption.TOP_GAINERS,
            InvestmentSortOption.PRICE_DESC -> options.sortedByDescending { it.defaultMonthlyReturnPercent }
            InvestmentSortOption.TOP_LOSERS,
            InvestmentSortOption.PRICE_ASC -> options.sortedBy { it.defaultMonthlyReturnPercent }
            InvestmentSortOption.NAME_ASC -> options.sortedWith { a, b -> trCollator.compare(a.name, b.name) }
        }
    }
}
