package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SermayeDatabase
import com.example.data.local.UserPreferencesDataStore
import com.example.data.local.VaultType
import com.example.data.repo.FirebaseAiAdvisorRepository
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.SermayeRepository
import com.example.domain.ComputedFund
import com.example.ui.HomeModalSheet
import com.example.ui.MainTab
import com.example.ui.SermayeUiState
import com.example.ui.SermayeViewModel
import com.example.ui.components.TopToastBanner
import com.example.ui.screens.AddIncomeBottomSheet
import com.example.ui.screens.AiAdvisorScreen
import com.example.ui.screens.AllTransactionsScreen
import com.example.ui.screens.AssetDetailModal
import com.example.ui.screens.FundsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IncomeExpenseScreen
import com.example.ui.screens.MarketAndSettingsScreen
import com.example.ui.screens.SellFundConfirmDialog
import com.example.ui.screens.SetupScreen
import com.example.ui.screens.SimulationScreen
import com.example.ui.screens.TransferBottomSheet
import com.example.ui.screens.UpdateFundValueDialog
import com.example.ui.screens.WithdrawBottomSheet
import com.example.ui.theme.LocalSermayeColors
import com.example.ui.theme.SermayeTheme
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: SermayeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI, ViewModel, or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val db = SermayeDatabase.getInstance(applicationContext)
        val prefs = UserPreferencesDataStore(applicationContext)
        val repo = SermayeRepository(db, prefs)
        val aiRepo = FirebaseAiAdvisorRepository()
        val liveMarketRepo = LiveMarketRepository()
        viewModel = ViewModelProvider(
            this,
            SermayeViewModel.Factory(applicationContext, repo, aiRepo, liveMarketRepo)
        )[SermayeViewModel::class.java]

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            SermayeTheme(darkTheme = uiState.profile.isDarkMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(LocalSermayeColors.current.background)
                ) {
                    if (!uiState.isLoaded) {
                        Box(modifier = Modifier.fillMaxSize())
                    } else if (!uiState.profile.isSetupDone) {
                        SetupScreen(
                            onCompleteSetup = { name, email, store, fund, self, income, sR, fR, kR, tAmt, tDate ->
                                viewModel.completeSetup(
                                    name, email, store, fund, self, income, sR, fR, kR, tAmt, tDate
                                )
                            }
                        )
                    } else {
                        SermayeMainShell(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .align(Alignment.TopCenter)
                    ) {
                        TopToastBanner(toast = uiState.toastMessage)
                    }
                }
            }
        }
    }
}

private data class NavTabSpec(
    val tab: MainTab,
    val label: String,
    val icon: ImageVector
)

private val MAIN_NAV_TABS = listOf(
    NavTabSpec(MainTab.HOME, "Ana Sayfa", Icons.Default.Home),
    NavTabSpec(MainTab.FUNDS, "Yatırım", Icons.AutoMirrored.Filled.TrendingUp),
    NavTabSpec(MainTab.AI_ADVISOR, "AI Danışman", Icons.Default.AutoAwesome),
    NavTabSpec(MainTab.SIMULATION, "Simülasyon", Icons.AutoMirrored.Filled.ShowChart),
    NavTabSpec(MainTab.MARKET_SETTINGS, "Piyasa", Icons.Default.Tune)
)

@Composable
private fun SermayeMainShell(
    uiState: SermayeUiState,
    viewModel: SermayeViewModel
) {
    val colors = LocalSermayeColors.current

    if (uiState.showAllTransactions) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = colors.background,
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                val monthNetCashflow = uiState.summary.thisMonthIncome - uiState.summary.thisMonthExpense
                AllTransactionsScreen(
                    transactions = uiState.transactions,
                    monthNetCashflow = monthNetCashflow,
                    onBack = { viewModel.closeAllTransactions() },
                    onOpenIncomeExpense = { viewModel.openIncomeExpense() },
                    onDeleteTransaction = { viewModel.deleteTransaction(it) }
                )
            }
        }
    } else if (uiState.showIncomeExpense) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = colors.background,
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                val monthNetCashflow = uiState.summary.thisMonthIncome - uiState.summary.thisMonthExpense
                IncomeExpenseScreen(
                    transactions = uiState.transactions,
                    monthNetCashflow = monthNetCashflow,
                    onBack = { viewModel.closeIncomeExpense() },
                    onOpenAllTransactions = { viewModel.openAllTransactions() },
                    onAddIncome = { viewModel.openHomeSheet(HomeModalSheet.ADD_INCOME) },
                    onAddExpense = { viewModel.openHomeSheet(HomeModalSheet.WITHDRAW) },
                    onDeleteTransaction = { viewModel.deleteTransaction(it) }
                )
            }
        }
    } else {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 840.dp

        if (useRail) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(colors.background)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .border(1.dp, colors.borderColor),
                    containerColor = colors.cardBackground
                ) {
                    MAIN_NAV_TABS.forEach { spec ->
                        val selected = uiState.currentTab == spec.tab
                        NavigationRailItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(spec.tab) },
                            icon = {
                                Icon(
                                    imageVector = spec.icon,
                                    contentDescription = spec.label
                                )
                            },
                            label = {
                                Text(
                                    text = spec.label,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = colors.cardBackground,
                                selectedTextColor = colors.textPrimary,
                                indicatorColor = colors.textPrimary,
                                unselectedIconColor = colors.textPrimary,
                                unselectedTextColor = colors.textPrimary
                            )
                        )
                    }
                }
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    TabBodyContent(uiState = uiState, viewModel = viewModel)
                }
            }
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = colors.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        HorizontalDivider(thickness = 1.dp, color = colors.borderColor)
                        NavigationBar(
                            containerColor = colors.cardBackground,
                            contentColor = colors.textPrimary,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            MAIN_NAV_TABS.forEach { spec ->
                                val selected = uiState.currentTab == spec.tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(spec.tab) },
                                    modifier = Modifier.testTag("nav_tab_${spec.tab.name}"),
                                    icon = {
                                        Icon(
                                            imageVector = spec.icon,
                                            contentDescription = spec.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = spec.label,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = colors.cardBackground,
                                        selectedTextColor = colors.textPrimary,
                                        indicatorColor = colors.textPrimary,
                                        unselectedIconColor = colors.textPrimary,
                                        unselectedTextColor = colors.textPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    TabBodyContent(uiState = uiState, viewModel = viewModel)
                }
            }
        }
        }
    }

    when (uiState.activeHomeSheet) {
        HomeModalSheet.ADD_INCOME -> {
            AddIncomeBottomSheet(
                uiState = uiState,
                onDismiss = { viewModel.closeHomeSheet() },
                onSubmit = { amount, source, note, date, sR, fR, kR ->
                    viewModel.addIncome(amount, source, note, date, sR, fR, kR) {}
                }
            )
        }
        HomeModalSheet.WITHDRAW -> {
            WithdrawBottomSheet(
                uiState = uiState,
                onDismiss = { viewModel.closeHomeSheet() },
                onSubmit = { vault, amount, category, note, date ->
                    viewModel.withdrawFromVault(vault, amount, category, note, date) {}
                }
            )
        }
        HomeModalSheet.TRANSFER -> {
            TransferBottomSheet(
                uiState = uiState,
                onDismiss = { viewModel.closeHomeSheet() },
                onSubmit = { from, to, amount ->
                    viewModel.transferBetweenVaults(from, to, amount) {}
                }
            )
        }
        null -> Unit
    }

    var modalFundToUpdate by remember { mutableStateOf<ComputedFund?>(null) }
    var modalFundToSell by remember { mutableStateOf<ComputedFund?>(null) }

    val selectedAssetDetail = uiState.selectedAssetDetail
    if (selectedAssetDetail != null) {
        AssetDetailModal(
            state = selectedAssetDetail,
            isFavorite = selectedAssetDetail.id in uiState.profile.favoriteAssetIds,
            activeAlertRule = uiState.profile.assetAlerts[selectedAssetDetail.id],
            onDismiss = { viewModel.closeAssetDetail() },
            onSelectRange = { viewModel.selectAssetChartRange(it) },
            onRefreshLive = {
                val hasAlerts = uiState.profile.marketAlertsEnabled ||
                    uiState.profile.assetAlerts.values.any { it.enabled }
                viewModel.refreshLiveMarketAndNews(triggerAlertCheck = hasAlerts)
            },
            onRegenerateAiForecast = { viewModel.regenerateSelectedAssetAiForecast() },
            onQuickInvestSuggestedFund = { suggestedType ->
                viewModel.openFundsToInvest(suggestedType)
            },
            onUpdateOwnedFund = { owned -> modalFundToUpdate = owned },
            onSellOwnedFund = { owned ->
                viewModel.closeAssetDetail()
                modalFundToSell = owned
            },
            onToggleFavorite = {
                viewModel.toggleFavoriteAsset(selectedAssetDetail.id, selectedAssetDetail.name)
            },
            onEnableAlert = { pct ->
                viewModel.enableAssetPriceAlert(
                    assetId = selectedAssetDetail.id,
                    assetName = selectedAssetDetail.name,
                    symbol = selectedAssetDetail.symbol,
                    currentPrice = selectedAssetDetail.currentPrice,
                    currency = selectedAssetDetail.currency,
                    thresholdPercent = pct
                )
            },
            onDisableAlert = {
                viewModel.disableAssetPriceAlert(selectedAssetDetail.id, selectedAssetDetail.name)
            },
            onShowError = { msg -> viewModel.showToast(msg, isError = true) }
        )
    }

    if (modalFundToUpdate != null) {
        UpdateFundValueDialog(
            target = modalFundToUpdate!!,
            onDismiss = { modalFundToUpdate = null },
            onConfirm = { newVal ->
                viewModel.updateFundValue(modalFundToUpdate!!.entity, newVal)
                modalFundToUpdate = null
            }
        )
    }

    if (modalFundToSell != null) {
        SellFundConfirmDialog(
            target = modalFundToSell!!,
            onDismiss = { modalFundToSell = null },
            onConfirm = {
                viewModel.sellFund(modalFundToSell!!.entity, modalFundToSell!!.currentValue)
                modalFundToSell = null
            }
        )
    }
}

@Composable
private fun TabBodyContent(
    uiState: SermayeUiState,
    viewModel: SermayeViewModel
) {
    Crossfade(
        targetState = uiState.currentTab,
        animationSpec = tween(durationMillis = 200),
        label = "SermayeTabTransition"
    ) { tab ->
        when (tab) {
            MainTab.HOME -> {
                HomeScreen(
                    uiState = uiState,
                    onToggleDarkMode = { viewModel.toggleDarkMode(it) },
                    onOpenSettings = { viewModel.openSettings() },
                    onOpenVaultDetail = { vault ->
                        if (vault == VaultType.FUND) {
                            viewModel.selectTab(MainTab.FUNDS)
                        } else {
                            viewModel.openAllTransactions()
                        }
                    },
                    onOpenSheet = { viewModel.openHomeSheet(it) },
                    onOpenLiveAssetDetail = { viewModel.openLiveAssetDetail(it) },
                    onToggleFavoriteAsset = { id, name -> viewModel.toggleFavoriteAsset(id, name) },
                    onOpenMarketPopular30 = { viewModel.openMarketPopular30() },
                    onOpenIncomeExpense = { viewModel.openIncomeExpense() },
                    onOpenAllTransactions = { viewModel.openAllTransactions() },
                    onDeleteTransaction = { viewModel.deleteTransaction(it) },
                    onDismissWeeklyReminder = { viewModel.dismissWeeklyReminder() }
                )
            }
            MainTab.FUNDS -> {
                FundsScreen(
                    uiState = uiState,
                    onInvestInFund = { type, risk, amount, ret, date, onSuccess ->
                        viewModel.investInFund(type, risk, amount, ret, date, onSuccess)
                    },
                    onUpdateFundValue = { fund, newVal -> viewModel.updateFundValue(fund, newVal) },
                    onSellFund = { fund, curVal -> viewModel.sellFund(fund, curVal) },
                    onAddMonthlyYield = { viewModel.addMonthlyFundYield() },
                    onRefreshLiveMarket = {
                        val hasAlerts = uiState.profile.marketAlertsEnabled ||
                            uiState.profile.assetAlerts.values.any { it.enabled }
                        viewModel.refreshLiveMarketAndNews(triggerAlertCheck = hasAlerts)
                    },
                    onOpenLiveAssetDetail = { viewModel.openLiveAssetDetail(it) },
                    onOpenFundOptionSetDetail = { viewModel.openFundOptionSetDetail(it) },
                    onOpenUserFundDetail = { viewModel.openUserFundDetail(it) },
                    onToggleFavoriteAsset = { id, name -> viewModel.toggleFavoriteAsset(id, name) },
                    onEnableAssetAlert = { quote, pct ->
                        viewModel.enableAssetPriceAlert(
                            assetId = quote.id,
                            assetName = quote.name,
                            symbol = quote.symbol,
                            currentPrice = quote.price,
                            currency = quote.currency,
                            thresholdPercent = pct
                        )
                    },
                    onDisableAssetAlert = { id, name -> viewModel.disableAssetPriceAlert(id, name) },
                    onShowToast = { msg, err -> viewModel.showToast(msg, err) },
                    onRemoteSearch = { viewModel.searchRemoteMarket(it) },
                    onClearRemoteSearch = { viewModel.clearRemoteMarketSearch() },
                    onConsumePendingInvestFundType = { viewModel.consumePendingInvestFundType() }
                )
            }
            MainTab.AI_ADVISOR -> {
                AiAdvisorScreen(
                    uiState = uiState,
                    onSelectRiskMode = { viewModel.selectRiskMode(it) },
                    onApplyRiskAllocation = { sellFirst -> viewModel.applyAiRiskAllocation(sellFirst) },
                    onApplySmartProfitPlan = { sellFirst -> viewModel.applySmartProfitPlan(sellFirst) },
                    onRequestGeminiAdvice = { viewModel.requestGeminiAdvice() }
                )
            }
            MainTab.SIMULATION -> {
                SimulationScreen(
                    uiState = uiState,
                    onUpdateParams = { inc, ret, months -> viewModel.updateSimulationParams(inc, ret, months) },
                    onFindBestScenario = { viewModel.findBestSimulationScenario() }
                )
            }
            MainTab.MARKET_SETTINGS -> {
                MarketAndSettingsScreen(
                    uiState = uiState,
                    onSelectSubTab = { viewModel.selectMarketSettingsSubTab(it) },
                    onRefreshLiveMarket = { viewModel.refreshLiveMarketAndNews(triggerAlertCheck = true) },
                    onOpenLiveAssetDetail = { viewModel.openLiveAssetDetail(it) },
                    onToggleFavoriteAsset = { id, name -> viewModel.toggleFavoriteAsset(id, name) },
                    onEnableAssetAlert = { quote, pct ->
                        viewModel.enableAssetPriceAlert(
                            assetId = quote.id,
                            assetName = quote.name,
                            symbol = quote.symbol,
                            currentPrice = quote.price,
                            currency = quote.currency,
                            thresholdPercent = pct
                        )
                    },
                    onDisableAssetAlert = { id, name -> viewModel.disableAssetPriceAlert(id, name) },
                    onRemoteSearch = { viewModel.searchRemoteMarket(it) },
                    onClearRemoteSearch = { viewModel.clearRemoteMarketSearch() },
                    onSendLiveNotification = {
                        viewModel.refreshLiveMarketAndNews(sendImmediateSnapshotNotice = true)
                    },
                    onSummarizeAgendaWithAi = { viewModel.summarizeMarketAgendaWithAi() },
                    onOpenNewsArticle = { viewModel.openNewsArticle(it) },
                    onCloseNewsArticle = { viewModel.closeNewsArticle() },
                    onToggleMarketAlerts = { viewModel.setMarketAlertsEnabled(it) },
                    onSelectAlertThreshold = { viewModel.setAlertThresholdPercent(it) },
                    onAddMarketTag = { raw, ok -> viewModel.addMarketTag(raw, ok) },
                    onDeleteMarketTag = { viewModel.deleteMarketTag(it) },
                    onAddTagPrice = { id, price, ok -> viewModel.addTagPrice(id, price, ok) },
                    onAddMarketNote = { content, ok -> viewModel.addMarketNote(content, ok) },
                    onDeleteMarketNote = { viewModel.deleteMarketNote(it) },
                    onSaveSettings = { n, e, inc, sR, fR, kR, tAmt, tDate ->
                        viewModel.saveSettings(n, e, inc, sR, fR, kR, tAmt, tDate)
                    },
                    onToggleWeeklyReminder = { viewModel.setWeeklyReminderEnabled(it) },
                    onShowToast = { msg, err -> viewModel.showToast(msg, err) },
                    onClearAllData = { viewModel.clearAllData() }
                )
            }
        }
    }
}
