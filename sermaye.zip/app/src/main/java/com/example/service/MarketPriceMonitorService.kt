package com.example.service

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.util.Log
import com.example.data.local.UserPreferencesDataStore
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.LiveMarketSnapshot
import com.example.util.CurrencyUtils
import com.example.util.MarketNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val TAG = "MarketPriceMonitor"

class MarketPriceMonitorService : JobService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartJob(params: JobParameters?): Boolean {
        scope.launch {
            try {
                val prefs = UserPreferencesDataStore(applicationContext)
                val profile = prefs.userProfileFlow.first()
                val hasCustomAlerts = profile.assetAlerts.values.any { it.enabled }
                if (!profile.marketAlertsEnabled && !hasCustomAlerts) {
                    jobFinished(params, false)
                    return@launch
                }

                val repo = LiveMarketRepository()
                val res = repo.fetchLiveMarket()
                val snapshot = res.getOrNull()
                if (snapshot != null) {
                    evaluateAndNotify(
                        context = applicationContext,
                        prefs = prefs,
                        snapshot = snapshot,
                        globalEnabled = profile.marketAlertsEnabled,
                        thresholdPercent = profile.alertThresholdPercent,
                        lastGold = profile.lastAlertGoldPrice,
                        lastBtc = profile.lastAlertBtcPrice,
                        lastTopFund = profile.lastAlertTopFundPrice,
                        customRules = profile.assetAlerts.values.toList()
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Background market check failed", e)
            } finally {
                jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        scope.cancel()
        return true
    }

    companion object {
        private const val JOB_ID = 4109

        fun schedule(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
            val component = ComponentName(context, MarketPriceMonitorService::class.java)
            val info = JobInfo.Builder(JOB_ID, component)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(30L * 60L * 1000L)
                .setPersisted(false)
                .build()
            scheduler.schedule(info)
            Log.d(TAG, "Scheduled periodic market price monitor job.")
        }

        fun cancel(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
            scheduler.cancel(JOB_ID)
            Log.d(TAG, "Cancelled market price monitor job.")
        }

        suspend fun evaluateAndNotify(
            context: Context,
            prefs: UserPreferencesDataStore,
            snapshot: LiveMarketSnapshot,
            thresholdPercent: Double,
            lastGold: Double,
            lastBtc: Double,
            lastTopFund: Double,
            globalEnabled: Boolean = true,
            customRules: List<com.example.data.local.AssetPriceAlertRule> = emptyList()
        ): Int {
            var sentCount = 0
            val gold = snapshot.assets.firstOrNull { it.id == "gram_altin" }
            val btc = snapshot.assets.firstOrNull { it.id == "bitcoin" }
            val topFund = snapshot.topFunds.firstOrNull { it.symbol == "GLD" }
                ?: snapshot.topFunds.firstOrNull { it.symbol == "SPY" }
                ?: snapshot.topFunds.firstOrNull()

            if (globalEnabled) {
                if (gold != null && lastGold > 0.0) {
                    val pct = ((gold.price - lastGold) / lastGold) * 100.0
                    if (abs(pct) >= thresholdPercent) {
                        val dir = if (pct > 0) "Yükseldi 📈" else "Düştü 📉"
                        if (MarketNotificationHelper.postMarketNotification(
                                context = context,
                                notificationId = 1001,
                                title = "Gram Altın $dir (${CurrencyUtils.formatSignedPercent(pct)})",
                                body = "Güncel Gram Altın fiyatı: ${CurrencyUtils.formatTL(gold.price)}"
                            )
                        ) sentCount++
                    }
                }

                if (btc != null && lastBtc > 0.0) {
                    val pct = ((btc.price - lastBtc) / lastBtc) * 100.0
                    if (abs(pct) >= thresholdPercent) {
                        val dir = if (pct > 0) "Yükseldi 📈" else "Düştü 📉"
                        if (MarketNotificationHelper.postMarketNotification(
                                context = context,
                                notificationId = 1002,
                                title = "Bitcoin $dir (${CurrencyUtils.formatSignedPercent(pct)})",
                                body = "Güncel Bitcoin fiyatı: ${CurrencyUtils.formatTL(btc.price)}"
                            )
                        ) sentCount++
                    }
                }

                if (topFund != null && lastTopFund > 0.0) {
                    val pct = ((topFund.price - lastTopFund) / lastTopFund) * 100.0
                    if (abs(pct) >= thresholdPercent) {
                        val dir = if (pct > 0) "Yükseldi 📈" else "Düştü 📉"
                        if (MarketNotificationHelper.postMarketNotification(
                                context = context,
                                notificationId = 1003,
                                title = "${topFund.symbol} Fonu $dir (${CurrencyUtils.formatSignedPercent(pct)})",
                                body = "${topFund.name}: ${CurrencyUtils.formatMoneyByCurrency(topFund.price, topFund.currency)}"
                            )
                        ) sentCount++
                    }
                }

                prefs.saveLastAlertPrices(
                    goldPrice = gold?.price ?: 0.0,
                    btcPrice = btc?.price ?: 0.0,
                    topFundPrice = topFund?.price ?: 0.0
                )
            }

            if (customRules.isNotEmpty()) {
                val quoteMap = (snapshot.assets + snapshot.topFunds).associateBy { it.id }
                val updatedBaselines = mutableMapOf<String, Double>()
                customRules.filter { it.enabled && it.thresholdPercent > 0.0 }.forEach { rule ->
                    val live = quoteMap[rule.assetId] ?: return@forEach
                    if (live.price <= 0.0) return@forEach
                    if (rule.baselinePrice <= 0.0) {
                        updatedBaselines[rule.assetId] = live.price
                        return@forEach
                    }
                    val pct = ((live.price - rule.baselinePrice) / rule.baselinePrice) * 100.0
                    if (abs(pct) >= rule.thresholdPercent) {
                        val dir = if (pct > 0) "Yükseldi 📈" else "Düştü 📉"
                        val notifId = 2000 + (rule.assetId.hashCode() and 0x7FFF)
                        if (MarketNotificationHelper.postMarketNotification(
                                context = context,
                                notificationId = notifId,
                                title = "${rule.assetName} $dir (${CurrencyUtils.formatSignedPercent(pct)})",
                                body = "Hedef ±${CurrencyUtils.formatPercent(rule.thresholdPercent)} aşıldı • " +
                                    "Güncel: ${CurrencyUtils.formatMoneyByCurrency(live.price, live.currency)}"
                            )
                        ) {
                            sentCount++
                        }
                        updatedBaselines[rule.assetId] = live.price
                    }
                }
                if (updatedBaselines.isNotEmpty()) {
                    prefs.updateAssetAlertBaselines(updatedBaselines)
                }
            }

            return sentCount
        }
    }
}
