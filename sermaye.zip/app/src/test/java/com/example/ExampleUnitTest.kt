package com.example

import com.example.data.local.AssetPriceAlertRule
import com.example.data.local.FundEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.TransactionType
import com.example.data.local.UserProfile
import com.example.data.local.VaultBalancesEntity
import com.example.data.repo.ImpactDirection
import com.example.data.repo.LiveAssetQuote
import com.example.data.repo.LiveMarketRepository
import com.example.data.repo.MarketCategory
import com.example.data.repo.MarketNewsItem
import com.example.domain.AVAILABLE_FUND_OPTIONS
import com.example.domain.CashflowPeriod
import com.example.domain.FinanceEngine
import com.example.domain.InvestmentSortOption
import com.example.domain.PricePoint
import com.example.domain.RiskProfileMode
import com.example.util.CurrencyUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun zeroInitialStateProducesZeroTotalsAndEmptyCharts() {
        val summary = FinanceEngine.buildPortfolioSummary(
            profile = UserProfile(isSetupDone = true, userName = "Mehmet"),
            balances = VaultBalancesEntity(storeBalance = 0.0, idleFundCash = 0.0, selfBalance = 0.0),
            transactions = emptyList(),
            funds = emptyList(),
            snapshots = emptyList()
        )
        assertEquals(0.0, summary.totalWealth, 0.001)
        assertEquals(0.0, summary.totalFundVault, 0.001)
        assertTrue(summary.growthSeries.isEmpty())
    }

    @Test
    fun compoundInterestFundFormulaIsAccurate() {
        val sixtyDaysAgo = System.currentTimeMillis() - (60L * 24L * 60L * 60L * 1000L) - 1000L
        val fund = FundEntity(
            id = 1,
            fundType = "Altın Fonu",
            riskLabel = "Orta Risk",
            investedAmount = 2000.0,
            monthlyReturnPercent = 5.0,
            purchaseDateMillis = sixtyDaysAgo
        )
        val computed = FinanceEngine.computeFundMetrics(fund)
        // 2000 * (1.05)^2 = 2205.00
        assertEquals(2, computed.monthsElapsedFromPurchase)
        assertEquals(2205.0, computed.currentValue, 0.01)
        assertEquals(205.0, computed.profitTL, 0.01)
        assertEquals(10.25, computed.profitPercent, 0.01)
    }

    @Test
    fun threeSlidersAlwaysTotal100() {
        val balanced = FinanceEngine.rebalanceRatios(0, 73, Triple(50, 40, 10))
        assertEquals(100, balanced.first + balanced.second + balanced.third)
        assertEquals(73, balanced.first)
    }

    @Test
    fun simulationCompoundFormulaAndBestScenarioWork() {
        // With 1000 TL/month over 12 months at 3.5% return (50% fund, 50% other), minimum is 12,000 TL + interest
        val sim1000 = FinanceEngine.simulateFutureValue(
            currentWealth = 0.0,
            currentFundVault = 0.0,
            monthlyIncome = 1000.0,
            fundRatioPercent = 50,
            monthlyReturnPercent = 3.5,
            months = 12,
            storeTargetAmount = 0.0,
            storeBalance = 0.0,
            storeRatioPercent = 50
        )
        assertTrue(sim1000.futureValue >= 12000.0)
        // 500 * ((1.035^12 - 1) / 0.035) + 500 * 12 = 7300.98 + 6000 = 13300.98
        assertEquals(13300.98, sim1000.futureValue, 0.5)
        assertEquals(12000.0, sim1000.totalPrincipal, 0.01)

        // High income scenario (25,000 TL/month) stays strictly >= 300,000 TL principal + interest
        val simHigh = FinanceEngine.simulateFutureValue(
            currentWealth = 50000.0,
            currentFundVault = 20000.0,
            monthlyIncome = 25000.0,
            fundRatioPercent = 40,
            monthlyReturnPercent = 4.0,
            months = 12,
            storeTargetAmount = 200000.0,
            storeBalance = 30000.0,
            storeRatioPercent = 50
        )
        assertEquals(350000.0, simHigh.totalPrincipal, 0.01)
        assertTrue(simHigh.futureValue > 350000.0)
        assertEquals(13.6, simHigh.monthsToGoal!!, 0.01)

        val sim = FinanceEngine.simulateFutureValue(
            currentWealth = 1000.0,
            currentFundVault = 1000.0,
            monthlyIncome = 2000.0,
            fundRatioPercent = 50,
            monthlyReturnPercent = 5.0,
            months = 12,
            storeTargetAmount = 20000.0,
            storeBalance = 5000.0,
            storeRatioPercent = 50
        )
        // Fund: 1000 * (((1.05^12 - 1)/0.05)) + 1000 * 1.05^12 = 17712.98; Other: 1000 * 12 = 12000 -> Total = 29712.98
        assertEquals(29712.98, sim.futureValue, 0.5)
        assertEquals(15.0, sim.monthsToGoal!!, 0.01)

        val best = FinanceEngine.findBestScenario(
            currentWealth = 1000.0,
            currentFundVault = 1000.0,
            monthlyIncome = 2000.0,
            months = 12
        )
        assertEquals(60, best.fundRatioPercent)
        assertEquals(10.0, best.monthlyReturnPercent, 0.01)
        assertTrue(best.projectedTotal > sim.futureValue)
    }

    @Test
    fun aiProfitPlanComputesIdleLossAndFullAllocation100() {
        val summary = FinanceEngine.buildPortfolioSummary(
            profile = UserProfile(isSetupDone = true, userName = "Ali", monthlyIncome = 10000.0),
            balances = VaultBalancesEntity(storeBalance = 5000.0, idleFundCash = 10000.0, selfBalance = 2000.0),
            transactions = emptyList(),
            funds = emptyList(),
            snapshots = emptyList()
        )
        val plan = FinanceEngine.buildAiProfitPlan(
            summary = summary,
            selectedRisk = RiskProfileMode.BALANCED,
            fundSignalScores = mapOf("Altın Fonu" to 3, "Hisse Senedi Fonu" to 1),
            marketAssetChanges = mapOf("gram_altin" to 1.4)
        )
        assertEquals(100, plan.smartAllocations.sumOf { it.second })
        assertEquals(320.0, plan.idleCashOpportunityMonthlyTL, 0.01)
        assertTrue(plan.monthlyProfitBoostTL > 300.0)
        assertTrue(plan.yearlyCompoundBoostTL > 3600.0)
        assertTrue(plan.actionableSteps.isNotEmpty())
    }

    @Test
    fun editableNumberAndNewsFundImpactWorkCleanly() {
        assertEquals("", CurrencyUtils.formatEditableNumber(0.0))
        assertEquals("10000", CurrencyUtils.formatEditableNumber(10000.0))
        assertEquals("3,5", CurrencyUtils.formatEditableNumber(3.5))
        assertEquals("6", CurrencyUtils.formatEditableNumber(AVAILABLE_FUND_OPTIONS.last().defaultMonthlyReturnPercent))

        val goldImpact = LiveMarketRepository.analyzeNewsFundImpact(
            title = "Gram altın tarihi zirveye yükseldi",
            summary = "Ons altındaki güçlü ralli güvenli liman talebini artırdı."
        )
        assertEquals(ImpactDirection.POSITIVE, goldImpact.direction)
        assertTrue(goldImpact.affectedFunds.any { it.contains("Altın") })

        val signals = LiveMarketRepository.aggregateFundSignals(
            listOf(
                MarketNewsItem(
                    title = "Altın rekor kırdı",
                    summary = "",
                    source = "Ekonomi",
                    publishedAt = "16 Kas • 13:15",
                    publishedAtMillis = 1L,
                    link = "",
                    fundImpact = goldImpact
                )
            )
        )
        assertEquals(1, signals.first { it.fundName == "Altın Fonu" }.positiveCount)
    }

    @Test
    fun statisticalForecastAndBenchmarkHelpersWork() {
        val dayMs = 24L * 60L * 60L * 1000L
        val now = 1_760_000_000_000L
        // Build 365 days rising cleanly ~0.1% per day -> positive 1M, 3M, 6M, 12M forecast
        val series = (0..364).map { idx ->
            val ts = now - (364 - idx) * dayMs
            val price = 1000.0 + idx * 1.5
            PricePoint(ts, CurrencyUtils.formatDayMonth(ts), price)
        }
        val current = series.last().price
        val forecast = FinanceEngine.buildAssetForecast(
            points = series,
            currentPrice = current,
            currency = "TL"
        )
        assertEquals(4, forecast.horizons.size)
        assertEquals(listOf(1, 3, 6, 12), forecast.horizons.map { it.months })
        assertTrue(forecast.realizedMonthlyDriftPercent > 0.0)
        assertTrue(forecast.horizons[0].projectedPrice > current)
        assertTrue(forecast.horizons[2].projectedPrice > forecast.horizons[0].projectedPrice)
        assertTrue(forecast.horizons[3].projectedPrice > forecast.horizons[2].projectedPrice)
        assertTrue(forecast.horizons[0].optimisticPercent > forecast.horizons[0].conservativePercent)

        assertEquals("gram_altin", LiveMarketRepository.resolveBenchmarkQuoteIdForFundName("Altın Fonu"))
        assertEquals("bitcoin", LiveMarketRepository.resolveBenchmarkQuoteIdForFundName("Bitcoin Fonu"))
        assertEquals("254,30 USD", CurrencyUtils.formatMoneyByCurrency(254.3, "USD"))
        assertEquals("3.200,00 TL", CurrencyUtils.formatMoneyByCurrency(3200.0, "TL"))
    }

    @Test
    fun rssDateParsesIntoIstanbulTime() {
        val (millis, formatted) = CurrencyUtils.parseRssPubDateToIstanbul("Mon, 16 Nov 2026 10:15:00 GMT")
        assertTrue(millis > 0L)
        assertTrue(formatted.contains("13:15"))
    }

    @Test
    fun microPriceFormattingPreservesPrecision() {
        assertEquals("0,00 TL", CurrencyUtils.formatTL(0.0))
        assertEquals("0,0412 TL", CurrencyUtils.formatTL(0.0412))
        assertEquals("0,000450 TL", CurrencyUtils.formatTL(0.00045))
    }

    @Test
    fun popular30MixedCapsAt30AndMixesCategories() {
        val sampleQuotes = buildList {
            add(LiveAssetQuote("gram_altin", "Gram Altın", "XAU/TRY", 3200.0, "TL", 1.2, MarketCategory.METAL, "Test"))
            add(LiveAssetQuote("bitcoin", "Bitcoin", "BTC/TRY", 3100000.0, "TL", 2.5, MarketCategory.CRYPTO, "Test"))
            add(LiveAssetQuote("fund_XU100.IS", "BIST 100", "XU100.IS", 9500.0, "TL", 0.8, MarketCategory.FUND, "Test"))
            for (i in 1..15) {
                add(LiveAssetQuote("tefas_F$i", "Fon $i", "F$i", 1.5 + i, "TL", 0.4, MarketCategory.FUND, "TEFAS"))
                add(LiveAssetQuote("cg_coin$i", "Coin $i", "C$i/TRY", 10.0 + i, "TL", 1.5, MarketCategory.CRYPTO, "CoinGecko"))
                add(LiveAssetQuote("metal_m$i", "Maden $i", "M$i/TRY", 500.0 + i, "TL", -0.3, MarketCategory.METAL, "Truncgil"))
            }
        }
        val top30 = LiveMarketRepository.resolvePopular30Mixed(sampleQuotes)
        assertEquals(30, top30.size)
        assertEquals(30, top30.map { it.id }.distinct().size)
        assertTrue(top30.any { it.category == MarketCategory.FUND })
        assertTrue(top30.any { it.category == MarketCategory.METAL })
        assertTrue(top30.any { it.category == MarketCategory.CRYPTO })
        // Priority leaders come first
        assertEquals("gram_altin", top30[0].id)
        assertEquals("bitcoin", top30[1].id)
        assertEquals("fund_XU100.IS", top30[2].id)
    }

    @Test
    fun customAssetAlertRuleDetectsPercentageThresholdBreach() {
        val rule = AssetPriceAlertRule(
            assetId = "bitcoin",
            assetName = "Bitcoin",
            symbol = "BTC/TRY",
            currency = "TL",
            thresholdPercent = 3.0,
            baselinePrice = 3_000_000.0,
            enabled = true
        )
        val smallMovePct = kotlin.math.abs((3_050_000.0 - rule.baselinePrice) / rule.baselinePrice) * 100.0
        val largeDropPct = kotlin.math.abs((2_890_000.0 - rule.baselinePrice) / rule.baselinePrice) * 100.0
        assertTrue(smallMovePct < rule.thresholdPercent)
        assertTrue(largeDropPct >= rule.thresholdPercent)
    }

    @Test
    fun incomeExpenseReportComputesCashflowCategoriesAndSavingsRate() {
        val now = System.currentTimeMillis()
        val txs = listOf(
            TransactionEntity(
                id = 1,
                dateMillis = now,
                amount = 40_000.0,
                sourceOrCategory = "Maaş",
                note = "Aylık maaş",
                storeDelta = 20_000.0,
                fundDelta = 12_000.0,
                selfDelta = 8_000.0,
                type = TransactionType.INPUT.name
            ),
            TransactionEntity(
                id = 2,
                dateMillis = now,
                amount = 10_000.0,
                sourceOrCategory = "Mağaza Satışı",
                note = "Ek satış",
                storeDelta = 5_000.0,
                fundDelta = 3_000.0,
                selfDelta = 2_000.0,
                type = TransactionType.INPUT.name
            ),
            TransactionEntity(
                id = 3,
                dateMillis = now,
                amount = 15_000.0,
                sourceOrCategory = "Mağaza Kasası • Kira",
                note = "Dükkan kirası",
                storeDelta = -15_000.0,
                fundDelta = 0.0,
                selfDelta = 0.0,
                type = TransactionType.EXPENSE.name
            ),
            TransactionEntity(
                id = 4,
                dateMillis = now,
                amount = 5_000.0,
                sourceOrCategory = "Kendine Kasası • Market & Gıda",
                note = "Mutfak",
                storeDelta = 0.0,
                fundDelta = 0.0,
                selfDelta = -5_000.0,
                type = TransactionType.EXPENSE.name
            )
        )
        val report = FinanceEngine.buildIncomeExpenseReport(txs, CashflowPeriod.THIS_MONTH, nowMillis = now)
        assertEquals(50_000.0, report.totalIncome, 0.01)
        assertEquals(20_000.0, report.totalExpense, 0.01)
        assertEquals(30_000.0, report.netCashflow, 0.01)
        assertEquals(60.0, report.savingsRatePercent, 0.01)
        assertEquals("Kira", report.expenseCategories.first().category)
        assertEquals(75.0, report.expenseCategories.first().sharePercent, 0.01)
        assertEquals(6, report.monthlyBars.size)
    }

    @Test
    fun investmentSortingOrdersByGainersPriceAndAlphabetically() {
        val sample = listOf(
            LiveAssetQuote("z", "Ziraat Altın", "ZGOLD", 350.0, "TL", 0.5, MarketCategory.FUND, "Yahoo"),
            LiveAssetQuote("b", "Bitcoin", "BTC", 3_100_000.0, "TL", 4.2, MarketCategory.CRYPTO, "CoinGecko"),
            LiveAssetQuote("a", "Altın", "XAU", 3_200.0, "TL", -1.1, MarketCategory.METAL, "Truncgil")
        )
        val byGainer = FinanceEngine.sortLiveAssetQuotes(sample, InvestmentSortOption.TOP_GAINERS)
        assertEquals(listOf("b", "z", "a"), byGainer.map { it.id })

        val byLoser = FinanceEngine.sortLiveAssetQuotes(sample, InvestmentSortOption.TOP_LOSERS)
        assertEquals(listOf("a", "z", "b"), byLoser.map { it.id })

        val byPriceDesc = FinanceEngine.sortLiveAssetQuotes(sample, InvestmentSortOption.PRICE_DESC)
        assertEquals(listOf("b", "a", "z"), byPriceDesc.map { it.id })

        val byName = FinanceEngine.sortLiveAssetQuotes(sample, InvestmentSortOption.NAME_ASC)
        assertEquals(listOf("a", "b", "z"), byName.map { it.id })

        val sortedPresets = FinanceEngine.sortFundOptionSpecs(AVAILABLE_FUND_OPTIONS, InvestmentSortOption.TOP_GAINERS)
        assertTrue(sortedPresets.first().defaultMonthlyReturnPercent >= sortedPresets.last().defaultMonthlyReturnPercent)
    }
}
